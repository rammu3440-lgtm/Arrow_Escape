export type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

export interface Cell {
  x: number;
  y: number;
}

export interface Arrow {
  id: string;
  head: Cell;
  direction: Direction;
  // body is ordered from head (index 0) to tail (index N-1)
  body: Cell[];
  isSnake: boolean;
  colorIndex: number;
}

export interface Board {
  width: number;
  height: number;
  arrows: Arrow[];
  // Map of "x,y" => arrowId
  grid: Map<string, string>;
}

export interface BoardSnapshot {
  board: Board;
  lives: number;
  removedArrowIds: string[];
}

export interface SolverResult {
  solvable: boolean;
  removalOrder: string[];
  averageBranching: number;
  longestChain: number;
  decoyCount: number;
  difficultyScore: number;
}

export type GameMode = 'CAMPAIGN' | 'INFINITE' | 'DAILY';

export interface LevelConfig {
  levelNumber: number;
  width: number;
  height: number;
  arrowCount: number;
  minLength: number;
  maxLength: number;
  bentChance: number;
  seed: number;
  isBoss?: boolean;
  title?: string;
  tutorialTip?: string;
}

export interface LevelProgress {
  unlocked: boolean;
  stars: number; // 0, 1, 2, 3
  bestTimeSec?: number;
  completedAt?: number;
}

export type PaletteName = 'pastel' | 'forest' | 'ocean' | 'contrast' | 'amethyst' | 'sunset';

export type SkinName = 'ribbon' | 'neon' | 'minimal' | 'bamboo';

export type AmbientSoundscape = 'none' | 'forest' | 'ocean' | 'city';

export interface GameSettings {
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  reduceMotion: boolean;
  darkMode: boolean;
  palette: PaletteName;
  skin: SkinName;
  ambientSoundscape: AmbientSoundscape;
  ambientVolume: number;
}

export type ShopItemType = 'BOOSTER' | 'THEME' | 'SKIN' | 'COIN_PACK';

export interface ShopItem {
  id: string;
  type: ShopItemType;
  name: string;
  description: string;
  price: number;
  currency: 'COINS' | 'USD' | 'AD';
  amount?: number;
  targetId?: string; // e.g. theme or skin name
  rarity?: 'common' | 'rare' | 'epic';
}

export interface EconomyState {
  version: number;
  coins: number;
  hints: number;
  undos: number;
  extraLives: number;
  ownedThemes: string[];
  ownedSkins: string[];
  equippedTheme: PaletteName;
  equippedSkin: SkinName;
  loginStreak: number;
  lastLoginDate: string;
  dailyAdsWatched: number;
  dailyAdsResetDate: string;
  checksum: string;
}

export interface CoinEarnBreakdown {
  base: number;
  starsBonus: number;
  bossBonus: number;
  firstTimeBonus: number;
  total: number;
}
