import { Arrow, Board, Cell, Direction, LevelConfig } from './types';
import { cellKey, createBoard, getDelta, getOppositeDirection } from './core';
import { solve } from './solver';

/**
 * Deterministic pseudo-random number generator (Mulberry32)
 */
export class PRNG {
  private state: number;

  constructor(seed: number) {
    this.state = seed >>> 0;
  }

  next(): number {
    let t = (this.state += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min;
  }

  pick<T>(array: T[]): T {
    return array[Math.floor(this.next() * array.length)];
  }

  shuffle<T>(array: T[]): T[] {
    const copy = [...array];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }
}

const ALL_DIRECTIONS: Direction[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];

/**
 * Checks if a ray from (hx, hy) in direction `dir` to the board edge is
 * completely empty in the given occupied cells set.
 */
function isExitRayFree(
  hx: number,
  hy: number,
  dir: Direction,
  width: number,
  height: number,
  occupied: Set<string>
): boolean {
  const { dx, dy } = getDelta(dir);
  let cx = hx + dx;
  let cy = hy + dy;

  while (cx >= 0 && cx < width && cy >= 0 && cy < height) {
    if (occupied.has(cellKey(cx, cy))) {
      return false;
    }
    cx += dx;
    cy += dy;
  }
  return true;
}

/**
 * Generates all cells in front of (hx, hy) in direction `dir` to board edge.
 */
function getExitRayCells(
  hx: number,
  hy: number,
  dir: Direction,
  width: number,
  height: number
): Set<string> {
  const ray = new Set<string>();
  const { dx, dy } = getDelta(dir);
  let cx = hx + dx;
  let cy = hy + dy;
  while (cx >= 0 && cx < width && cy >= 0 && cy < height) {
    ray.add(cellKey(cx, cy));
    cx += dx;
    cy += dy;
  }
  return ray;
}

/**
 * Attempt to generate a single board using Reverse Construction.
 */
function tryGenerateBoard(config: LevelConfig, rng: PRNG): Board | null {
  const { width, height, arrowCount, minLength, maxLength, bentChance } = config;
  const occupied = new Set<string>();
  const arrows: Arrow[] = [];

  // Adapt attempts proportionally to grid area so larger boards have sufficient exploration room
  const maxAttempts = Math.max(180, width * height * 4);
  let attempts = 0;

  while (arrows.length < arrowCount && attempts < maxAttempts) {
    attempts++;

    // Find all empty cells as potential heads
    const emptyCells: Cell[] = [];
    for (let x = 0; x < width; x++) {
      for (let y = 0; y < height; y++) {
        if (!occupied.has(cellKey(x, y))) {
          emptyCells.push({ x, y });
        }
      }
    }

    if (emptyCells.length === 0) break;

    const head = rng.pick(emptyCells);
    const shuffledDirs = rng.shuffle(ALL_DIRECTIONS);

    let placed = false;

    for (const dir of shuffledDirs) {
      // Exit ray must be free of all currently placed arrows
      if (!isExitRayFree(head.x, head.y, dir, width, height, occupied)) {
        continue;
      }

      const exitRay = getExitRayCells(head.x, head.y, dir, width, height);

      // Determine length of this arrow
      const targetLength = rng.nextInt(minLength, maxLength);
      const isSnake = rng.next() < bentChance;

      // Build body starting with head
      const body: Cell[] = [head];
      const bodySet = new Set<string>([cellKey(head.x, head.y)]);

      if (!isSnake) {
        // Straight arrow: extends in opposite direction
        const oppDir = getOppositeDirection(dir);
        const { dx, dy } = getDelta(oppDir);
        let cx = head.x;
        let cy = head.y;
        let straightOk = true;

        for (let step = 1; step < targetLength; step++) {
          cx += dx;
          cy += dy;
          const key = cellKey(cx, cy);

          if (
            cx < 0 ||
            cx >= width ||
            cy < 0 ||
            cy >= height ||
            occupied.has(key) ||
            exitRay.has(key)
          ) {
            straightOk = false;
            break;
          }
          body.push({ x: cx, y: cy });
          bodySet.add(key);
        }

        if (straightOk && body.length >= minLength) {
          // Valid straight arrow
          const arrowId = `a_${arrows.length + 1}`;
          const arrow: Arrow = {
            id: arrowId,
            head,
            direction: dir,
            body,
            isSnake: false,
            colorIndex: arrows.length % 6,
          };
          for (const c of body) {
            occupied.add(cellKey(c.x, c.y));
          }
          arrows.push(arrow);
          placed = true;
          break;
        }
      } else {
        // Snake / Bent arrow: body grows step-by-step
        let currentCell = head;
        let prevDir = getOppositeDirection(dir);

        for (let step = 1; step < targetLength; step++) {
          const neighbors: { cell: Cell; dir: Direction }[] = [];

          // Bias towards continuing in previous direction, but permit turns
          const candidateDirs = rng.shuffle(ALL_DIRECTIONS);
          for (const candDir of candidateDirs) {
            const { dx, dy } = getDelta(candDir);
            const nx = currentCell.x + dx;
            const ny = currentCell.y + dy;
            const nKey = cellKey(nx, ny);

            if (
              nx >= 0 &&
              nx < width &&
              ny >= 0 &&
              ny < height &&
              !occupied.has(nKey) &&
              !bodySet.has(nKey) &&
              !exitRay.has(nKey)
            ) {
              neighbors.push({ cell: { x: nx, y: ny }, dir: candDir });
            }
          }

          if (neighbors.length === 0) break;

          // Pick next cell; prefer continuing straight 50% of the time if available
          let chosen = neighbors[0];
          const straightCandidate = neighbors.find((n) => n.dir === prevDir);
          if (straightCandidate && rng.next() < 0.5) {
            chosen = straightCandidate;
          } else {
            chosen = rng.pick(neighbors);
          }

          body.push(chosen.cell);
          bodySet.add(cellKey(chosen.cell.x, chosen.cell.y));
          currentCell = chosen.cell;
          prevDir = chosen.dir;
        }

        // Did we meet minimum length requirement?
        if (body.length >= minLength) {
          // Check if snake has at least one turn to be considered snake
          let hasTurn = false;
          if (body.length >= 3) {
            const d1x = body[1].x - body[0].x;
            const d1y = body[1].y - body[0].y;
            const d2x = body[2].x - body[1].x;
            const d2y = body[2].y - body[1].y;
            if (d1x !== d2x || d1y !== d2y) hasTurn = true;
          }

          const arrowId = `a_${arrows.length + 1}`;
          const arrow: Arrow = {
            id: arrowId,
            head,
            direction: dir,
            body,
            isSnake: hasTurn,
            colorIndex: arrows.length % 6,
          };
          for (const c of body) {
            occupied.add(cellKey(c.x, c.y));
          }
          arrows.push(arrow);
          placed = true;
          break;
        }
      }
    }

    if (placed) {
      attempts = 0; // Reset attempts on successful placement
    }
  }

  if (arrows.length < Math.max(3, Math.floor(arrowCount * 0.75))) {
    return null;
  }

  // Reverse construction gives arrows in reverse order of removal:
  // arrows[0] was placed first, so it will be removed LAST.
  // arrows[arrows.length - 1] was placed last, so its exit path is currently completely clear!
  // In the board array, we keep all arrows.
  return createBoard(width, height, arrows);
}

/**
 * Generates a validated solvable board matching the level configuration.
 * Uses seed-based deterministic PRNG and validates with the solver.
 */
export function generateLevel(config: LevelConfig): { board: Board; score: number } {
  const seedAttempt = config.seed;

  // Primary attempt loop: test up to 20 deterministic seeds for the exact parameters
  for (let trial = 0; trial < 20; trial++) {
    const rng = new PRNG(seedAttempt + trial * 7919);
    const candidateBoard = tryGenerateBoard(config, rng);

    if (candidateBoard) {
      const solverResult = solve(candidateBoard);
      if (solverResult.solvable && solverResult.removalOrder.length === candidateBoard.arrows.length) {
        return {
          board: candidateBoard,
          score: solverResult.difficultyScore,
        };
      }
    }
  }

  // Adaptive relaxation fallback: if extreme density didn't converge within 20 trials,
  // gradually relax arrowCount by 1 or 2 to guarantee a verified solvable board
  for (let reduction = 1; reduction <= 4; reduction++) {
    const relaxedConfig: LevelConfig = {
      ...config,
      arrowCount: Math.max(3, config.arrowCount - reduction),
      maxLength: reduction >= 2 ? Math.max(2, config.maxLength - 1) : config.maxLength,
    };

    for (let trial = 0; trial < 8; trial++) {
      const rng = new PRNG(seedAttempt + 70000 + reduction * 1000 + trial * 7919);
      const candidateBoard = tryGenerateBoard(relaxedConfig, rng);

      if (candidateBoard) {
        const solverResult = solve(candidateBoard);
        if (solverResult.solvable && solverResult.removalOrder.length === candidateBoard.arrows.length) {
          return {
            board: candidateBoard,
            score: solverResult.difficultyScore,
          };
        }
      }
    }
  }

  // Ultimate safe fallback
  const fallbackRng = new PRNG(config.seed);
  const fallbackBoard = tryGenerateBoard(
    {
      ...config,
      arrowCount: Math.max(3, Math.floor(config.arrowCount * 0.7)),
      maxLength: Math.max(2, config.maxLength - 1),
    },
    fallbackRng
  ) || createBoard(config.width, config.height, []);

  return {
    board: fallbackBoard,
    score: solve(fallbackBoard).difficultyScore,
  };
}
