import {
  EconomyState,
  ShopItem,
  CoinEarnBreakdown,
  PaletteName,
  SkinName,
} from './types';

export type { EconomyState, ShopItem, CoinEarnBreakdown, PaletteName, SkinName };

export const ECONOMY_CONFIG = {
  STARTING_COINS: 100,
  STARTING_HINTS: 3,
  STARTING_UNDOS: 3,
  WIN_BASE_COINS: 10,
  WIN_PER_STAR_COINS: 5,
  WIN_BOSS_BONUS_COINS: 20,
  FIRST_TIME_3STAR_BONUS: 15,
  REPLAY_FARM_FACTOR: 0.2,
  AD_REWARD_COINS: 50,
  MAX_DAILY_ADS: 5,
  SPEND_HINT_PRICE: 30,
  SPEND_UNDO_PRICE: 20,
  SPEND_REVIVE_PRICE: 60,
  STREAK_SAVER_COINS: 50,
};

export interface DailyRewardDay {
  day: number;
  type: 'COINS' | 'HINTS' | 'UNDOS' | 'GRAND_PRIZE';
  amount: number;
  themeId?: PaletteName;
  skinId?: SkinName;
  title: string;
}

export const DAILY_REWARD_CALENDAR: DailyRewardDay[] = [
  { day: 1, type: 'COINS', amount: 20, title: '20 Coins' },
  { day: 2, type: 'HINTS', amount: 1, title: '1 Hint' },
  { day: 3, type: 'COINS', amount: 40, title: '40 Coins' },
  { day: 4, type: 'UNDOS', amount: 1, title: '1 Undo' },
  { day: 5, type: 'COINS', amount: 60, title: '60 Coins' },
  { day: 6, type: 'HINTS', amount: 2, title: '2 Hints' },
  {
    day: 7,
    type: 'GRAND_PRIZE',
    amount: 100,
    themeId: 'amethyst',
    skinId: 'neon',
    title: '100 Coins + Epic Loot',
  },
];

const STORAGE_KEY_ECONOMY = 'arrow_escape_economy_v2';

export const SHOP_CATALOG: ShopItem[] = [
  // --- Boosters ---
  {
    id: 'booster_hint_1',
    type: 'BOOSTER',
    name: '1 Hint',
    description: 'Spotlights the safest, most strategic arrow to free.',
    price: 30,
    currency: 'COINS',
    amount: 1,
    targetId: 'hint',
    rarity: 'common',
  },
  {
    id: 'booster_hint_3',
    type: 'BOOSTER',
    name: '3 Hints Pack',
    description: '3 Strategic hints at a 15-coin savings.',
    price: 75,
    currency: 'COINS',
    amount: 3,
    targetId: 'hint',
    rarity: 'rare',
  },
  {
    id: 'booster_undo_1',
    type: 'BOOSTER',
    name: '1 Undo',
    description: 'Reverses your last arrow escape move.',
    price: 20,
    currency: 'COINS',
    amount: 1,
    targetId: 'undo',
    rarity: 'common',
  },
  {
    id: 'booster_undo_3',
    type: 'BOOSTER',
    name: '3 Undos Pack',
    description: '3 Rewind moves at a 10-coin bundle savings.',
    price: 50,
    currency: 'COINS',
    amount: 3,
    targetId: 'undo',
    rarity: 'rare',
  },

  // --- Themes ---
  {
    id: 'theme_pastel',
    type: 'THEME',
    name: 'Calm Pastel',
    description: 'The soothing, classic pastel palette.',
    price: 0,
    currency: 'COINS',
    targetId: 'pastel',
    rarity: 'common',
  },
  {
    id: 'theme_forest',
    type: 'THEME',
    name: 'Zen Forest',
    description: 'Earthy bamboo greens, warm moss and jade.',
    price: 250,
    currency: 'COINS',
    targetId: 'forest',
    rarity: 'rare',
  },
  {
    id: 'theme_ocean',
    type: 'THEME',
    name: 'Ocean Breeze',
    description: 'Cool aquas, seafoam, and deep cyan.',
    price: 350,
    currency: 'COINS',
    targetId: 'ocean',
    rarity: 'rare',
  },
  {
    id: 'theme_contrast',
    type: 'THEME',
    name: 'High Contrast',
    description: 'Accessible colorblind-safe optical harmony.',
    price: 200,
    currency: 'COINS',
    targetId: 'contrast',
    rarity: 'common',
  },
  {
    id: 'theme_amethyst',
    type: 'THEME',
    name: 'Midnight Amethyst',
    description: 'Deep royal purple and luminous lavender.',
    price: 500,
    currency: 'COINS',
    targetId: 'amethyst',
    rarity: 'epic',
  },
  {
    id: 'theme_sunset',
    type: 'THEME',
    name: 'Sunset Horizon',
    description: 'Warm terracotta, coral rose, and golden dusk.',
    price: 650,
    currency: 'COINS',
    targetId: 'sunset',
    rarity: 'epic',
  },

  // --- Arrow Skins ---
  {
    id: 'skin_ribbon',
    type: 'SKIN',
    name: 'Classic Capsule',
    description: 'Smooth, tactile rounded arrow capsules.',
    price: 0,
    currency: 'COINS',
    targetId: 'ribbon',
    rarity: 'common',
  },
  {
    id: 'skin_neon',
    type: 'SKIN',
    name: 'Cyber Neon',
    description: 'Luminous glowing energy beams with bright trails.',
    price: 250,
    currency: 'COINS',
    targetId: 'neon',
    rarity: 'rare',
  },
  {
    id: 'skin_minimal',
    type: 'SKIN',
    name: 'Minimal Chevron',
    description: 'Ultra-thin, elegant geometric arrows.',
    price: 200,
    currency: 'COINS',
    targetId: 'minimal',
    rarity: 'common',
  },
  {
    id: 'skin_bamboo',
    type: 'SKIN',
    name: 'Zen Bamboo',
    description: 'Segmented organic bamboo reeds with leaf caps.',
    price: 450,
    currency: 'COINS',
    targetId: 'bamboo',
    rarity: 'epic',
  },

  // --- Coin Packs / Rewarded Ad ---
  {
    id: 'coins_ad',
    type: 'COIN_PACK',
    name: 'Watch Serene Ad',
    description: 'Watch a quick 3-second calm demo to earn 50 coins.',
    price: 0,
    currency: 'AD',
    amount: 50,
    rarity: 'common',
  },
  {
    id: 'coins_small',
    type: 'COIN_PACK',
    name: 'Pouch of Coins',
    description: '200 Coins for quick booster refills.',
    price: 0.99,
    currency: 'USD',
    amount: 200,
    rarity: 'common',
  },
  {
    id: 'coins_medium',
    type: 'COIN_PACK',
    name: 'Chest of Coins',
    description: '600 Coins — Unlock premium themes immediately.',
    price: 1.99,
    currency: 'USD',
    amount: 600,
    rarity: 'rare',
  },
  {
    id: 'coins_large',
    type: 'COIN_PACK',
    name: 'Vault of Coins',
    description: '1,800 Coins — 3x Best Value pack.',
    price: 3.99,
    currency: 'USD',
    amount: 1800,
    rarity: 'epic',
  },
];

function generateChecksum(coins: number, hints: number, undos: number): string {
  return `${(coins * 31 + hints * 17 + undos * 13) ^ 0x5a5a}`;
}

export function createDefaultEconomy(): EconomyState {
  const coins = ECONOMY_CONFIG.STARTING_COINS;
  const hints = ECONOMY_CONFIG.STARTING_HINTS;
  const undos = ECONOMY_CONFIG.STARTING_UNDOS;
  return {
    version: 2,
    coins,
    hints,
    undos,
    extraLives: 0,
    ownedThemes: ['pastel'],
    ownedSkins: ['ribbon'],
    equippedTheme: 'pastel',
    equippedSkin: 'ribbon',
    loginStreak: 1,
    lastLoginDate: '', // Empty so first claim is available immediately
    dailyAdsWatched: 0,
    dailyAdsResetDate: new Date().toISOString().slice(0, 10),
    checksum: generateChecksum(coins, hints, undos),
  };
}

export function loadEconomy(): EconomyState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ECONOMY);
    if (!raw) return createDefaultEconomy();
    const data: EconomyState = JSON.parse(raw);

    // Tamper check verification
    const expected = generateChecksum(data.coins, data.hints, data.undos);
    if (data.checksum && data.checksum !== expected) {
      console.warn('Economy checksum mismatch; repairing state.');
      data.coins = Math.max(0, Math.min(data.coins, 10000));
      data.checksum = generateChecksum(data.coins, data.hints, data.undos);
    }

    if (!data.ownedThemes.includes('pastel')) data.ownedThemes.push('pastel');
    if (!data.ownedSkins.includes('ribbon')) data.ownedSkins.push('ribbon');

    return data;
  } catch {
    return createDefaultEconomy();
  }
}

export function saveEconomy(state: EconomyState) {
  try {
    const updated = {
      ...state,
      checksum: generateChecksum(state.coins, state.hints, state.undos),
    };
    localStorage.setItem(STORAGE_KEY_ECONOMY, JSON.stringify(updated));
  } catch {
    // Ignore
  }
}

/**
 * Computes coins rewarded upon winning a level.
 */
export function computeWinEarnings(
  stars: number,
  isBoss: boolean,
  isFirstTime3Stars: boolean,
  isReplay: boolean
): CoinEarnBreakdown {
  const base = ECONOMY_CONFIG.WIN_BASE_COINS;
  const starsBonus = stars * ECONOMY_CONFIG.WIN_PER_STAR_COINS;
  const bossBonus = isBoss ? ECONOMY_CONFIG.WIN_BOSS_BONUS_COINS : 0;
  const firstTimeBonus = isFirstTime3Stars ? ECONOMY_CONFIG.FIRST_TIME_3STAR_BONUS : 0;

  const rawTotal = base + starsBonus + bossBonus + firstTimeBonus;
  const total = isReplay ? Math.max(2, Math.round(rawTotal * ECONOMY_CONFIG.REPLAY_FARM_FACTOR)) : rawTotal;

  return {
    base,
    starsBonus,
    bossBonus,
    firstTimeBonus,
    total,
  };
}

/**
 * Purchases an item from the shop catalog.
 */
export function purchaseShopItem(
  state: EconomyState,
  item: ShopItem
): { success: boolean; state: EconomyState; message?: string } {
  if (item.currency === 'USD') {
    const addedCoins = item.amount || 0;
    const newState: EconomyState = {
      ...state,
      coins: state.coins + addedCoins,
    };
    saveEconomy(newState);
    return { success: true, state: newState, message: `Purchased ${item.name}! Added ${addedCoins} coins.` };
  }

  if (item.currency === 'AD') {
    const today = new Date().toISOString().slice(0, 10);
    const adsWatched = state.dailyAdsResetDate === today ? state.dailyAdsWatched : 0;
    if (adsWatched >= ECONOMY_CONFIG.MAX_DAILY_ADS) {
      return { success: false, state, message: 'Daily ad limit reached. Come back tomorrow!' };
    }
    const reward = item.amount || ECONOMY_CONFIG.AD_REWARD_COINS;
    const newState: EconomyState = {
      ...state,
      coins: state.coins + reward,
      dailyAdsWatched: adsWatched + 1,
      dailyAdsResetDate: today,
    };
    saveEconomy(newState);
    return { success: true, state: newState, message: `Reward granted! +${reward} coins.` };
  }

  // Coin Purchase
  if (state.coins < item.price) {
    return { success: false, state, message: 'Insufficient coins.' };
  }

  const newCoins = state.coins - item.price;
  let newState: EconomyState = { ...state, coins: newCoins };

  if (item.type === 'BOOSTER') {
    if (item.targetId === 'hint') {
      newState.hints = newState.hints + (item.amount || 1);
    } else if (item.targetId === 'undo') {
      newState.undos = newState.undos + (item.amount || 1);
    }
  } else if (item.type === 'THEME' && item.targetId) {
    if (!newState.ownedThemes.includes(item.targetId)) {
      newState.ownedThemes = [...newState.ownedThemes, item.targetId];
    }
    newState.equippedTheme = item.targetId as PaletteName;
  } else if (item.type === 'SKIN' && item.targetId) {
    if (!newState.ownedSkins.includes(item.targetId)) {
      newState.ownedSkins = [...newState.ownedSkins, item.targetId];
    }
    newState.equippedSkin = item.targetId as SkinName;
  }

  saveEconomy(newState);
  return { success: true, state: newState, message: `Acquired ${item.name}!` };
}

/**
 * Equips an owned theme or skin.
 */
export function equipItem(
  state: EconomyState,
  type: 'THEME' | 'SKIN',
  id: string
): EconomyState {
  const newState = { ...state };
  if (type === 'THEME') {
    if (newState.ownedThemes.includes(id)) {
      newState.equippedTheme = id as PaletteName;
    }
  } else if (type === 'SKIN') {
    if (newState.ownedSkins.includes(id)) {
      newState.equippedSkin = id as SkinName;
    }
  }
  saveEconomy(newState);
  return newState;
}

export type DailyClaimStatus = 'CLAIMABLE' | 'ALREADY_CLAIMED' | 'STREAK_BROKEN';

/**
 * Checks status of today's Daily Reward.
 */
export function getDailyRewardStatus(state: EconomyState): {
  status: DailyClaimStatus;
  currentDay: number;
  cycleCount: number;
  reward: DailyRewardDay;
} {
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

  const cycleCount = Math.floor((state.loginStreak - 1) / 7) + 1;
  const currentDayIndex = ((state.loginStreak - 1) % 7);
  const currentDay = currentDayIndex + 1;
  const reward = DAILY_REWARD_CALENDAR[currentDayIndex];

  if (state.lastLoginDate === today) {
    return {
      status: 'ALREADY_CLAIMED',
      currentDay,
      cycleCount,
      reward,
    };
  }

  // If claimed yesterday or never claimed before: CLAIMABLE!
  if (!state.lastLoginDate || state.lastLoginDate === yesterday) {
    return {
      status: 'CLAIMABLE',
      currentDay,
      cycleCount,
      reward,
    };
  }

  // Missed a day! Streak is broken
  return {
    status: 'STREAK_BROKEN',
    currentDay: 1,
    cycleCount: 1,
    reward: DAILY_REWARD_CALENDAR[0],
  };
}

/**
 * Claims today's daily reward.
 */
export function claimDailyReward(
  state: EconomyState,
  doubleWithAd: boolean = false
): {
  state: EconomyState;
  rewardGranted: { coins: number; hints: number; undos: number; itemUnlocked?: string };
} {
  const today = new Date().toISOString().slice(0, 10);
  const { status, currentDay, cycleCount, reward } = getDailyRewardStatus(state);

  let newStreak = state.loginStreak;
  if (status === 'STREAK_BROKEN') {
    newStreak = 1;
  }

  // Cycle multiplier: cycle 1 = 1x, cycle 2 = 1.25x, cycle 3 = 1.5x up to 2x cap
  const cycleMult = Math.min(2.0, 1.0 + (cycleCount - 1) * 0.25);
  const adMult = doubleWithAd ? 2 : 1;

  let grantedCoins = 0;
  let grantedHints = 0;
  let grantedUndos = 0;
  let itemUnlocked: string | undefined;

  let ownedThemes = [...state.ownedThemes];
  let ownedSkins = [...state.ownedSkins];

  if (reward.type === 'COINS') {
    grantedCoins = Math.round(reward.amount * cycleMult * adMult);
  } else if (reward.type === 'HINTS') {
    grantedHints = reward.amount * adMult;
  } else if (reward.type === 'UNDOS') {
    grantedUndos = reward.amount * adMult;
  } else if (reward.type === 'GRAND_PRIZE') {
    grantedCoins = Math.round(reward.amount * cycleMult * adMult);
    grantedHints += 1;
    grantedUndos += 1;
    if (reward.themeId && !ownedThemes.includes(reward.themeId)) {
      ownedThemes.push(reward.themeId);
      itemUnlocked = 'Theme: Midnight Amethyst';
    } else if (reward.skinId && !ownedSkins.includes(reward.skinId)) {
      ownedSkins.push(reward.skinId);
      itemUnlocked = 'Skin: Cyber Neon';
    }
  }

  const newState: EconomyState = {
    ...state,
    coins: state.coins + grantedCoins,
    hints: state.hints + grantedHints,
    undos: state.undos + grantedUndos,
    ownedThemes,
    ownedSkins,
    loginStreak: newStreak + 1,
    lastLoginDate: today,
  };

  saveEconomy(newState);
  return {
    state: newState,
    rewardGranted: {
      coins: grantedCoins,
      hints: grantedHints,
      undos: grantedUndos,
      itemUnlocked,
    },
  };
}

/**
 * Restores a broken streak using coins or ad.
 */
export function restoreStreak(state: EconomyState, costCoins: number = 0): {
  success: boolean;
  state: EconomyState;
} {
  if (costCoins > 0 && state.coins < costCoins) {
    return { success: false, state };
  }

  const newState: EconomyState = {
    ...state,
    coins: Math.max(0, state.coins - costCoins),
    // Reset lastLoginDate to yesterday so streak continues from current day
    lastLoginDate: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
  };

  saveEconomy(newState);
  return { success: true, state: newState };
}
