import { Arrow, Board, BoardSnapshot, GameMode, LevelConfig } from './types';
import { createBoard } from './core';

/**
 * Configuration and constants for GameSnapshot persistence
 */
export const SaveConfig = {
  SCHEMA_VERSION: 1,
  SLOT_A_KEY: 'arrow_escape_snapshot_slot_a',
  SLOT_B_KEY: 'arrow_escape_snapshot_slot_b',
  META_KEY: 'arrow_escape_snapshot_meta',
  DEBOUNCE_MS: 300,
  MAX_UNDO_ITEMS: 15,
} as const;

export interface SerializedBoard {
  width: number;
  height: number;
  arrows: Arrow[];
}

export interface SerializedUndoItem {
  board: SerializedBoard;
  lives: number;
  removedArrowIds: string[];
}

export interface GameSnapshot {
  schemaVersion: number;
  gameMode: GameMode;
  levelNumber: number;
  seed: number;
  levelConfig?: LevelConfig;
  board: SerializedBoard;
  totalArrowsInLevel: number;
  removedArrowIds: string[];
  moveHistory: string[];
  undoStack: SerializedUndoItem[];
  lives: number;
  hintsUsedInLevel: number;
  movesCount: number;
  timeElapsed: number; // in seconds
  savedAt: number; // Unix timestamp in ms
  checksum: string;
}

export interface SnapshotSlotEnvelope {
  slot: 'A' | 'B';
  sequence: number;
  timestamp: number;
  checksum: string;
  data: GameSnapshot;
}

export interface SnapshotMetadata {
  activeSlot: 'A' | 'B';
  sequence: number;
  lastSavedAt: number;
}

/**
 * High-performance 32-bit FNV-1a hash algorithm.
 * Formats as an 8-character hex string.
 */
export function computeFNV1a(str: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/**
 * Calculates a tamper-evident checksum for the snapshot's core state.
 */
export function computeSnapshotChecksum(snapshot: Omit<GameSnapshot, 'checksum'>): string {
  const keyData = JSON.stringify({
    v: snapshot.schemaVersion,
    m: snapshot.gameMode,
    l: snapshot.levelNumber,
    s: snapshot.seed,
    w: snapshot.board.width,
    h: snapshot.board.height,
    a: snapshot.board.arrows.map(
      (a) => `${a.id}:${a.head.x},${a.head.y}:${a.direction}:${a.colorIndex}:${a.body.length}`
    ),
    rem: snapshot.removedArrowIds,
    mov: snapshot.moveHistory,
    lives: snapshot.lives,
    hints: snapshot.hintsUsedInLevel,
    moves: snapshot.movesCount,
    time: Math.round(snapshot.timeElapsed),
  });
  return computeFNV1a(keyData);
}

/**
 * Serializes a Board object by stripping the transient `grid` Map.
 */
export function serializeBoard(board: Board): SerializedBoard {
  return {
    width: board.width,
    height: board.height,
    arrows: board.arrows.map((a) => ({
      id: a.id,
      head: { x: a.head.x, y: a.head.y },
      direction: a.direction,
      body: a.body.map((c) => ({ x: c.x, y: c.y })),
      isSnake: a.isSnake,
      colorIndex: a.colorIndex,
    })),
  };
}

/**
 * Reconstructs a full playable Board with its spatial grid Map from serialized state.
 */
export function deserializeBoard(serialized: SerializedBoard): Board {
  return createBoard(serialized.width, serialized.height, serialized.arrows);
}

/**
 * Serializes an undo stack to a capped list of serialized snapshots.
 */
export function serializeUndoStack(stack: BoardSnapshot[]): SerializedUndoItem[] {
  const capped = stack.slice(-SaveConfig.MAX_UNDO_ITEMS);
  return capped.map((item) => ({
    board: serializeBoard(item.board),
    lives: item.lives,
    removedArrowIds: [...item.removedArrowIds],
  }));
}

/**
 * Restores an undo stack back into BoardSnapshot array.
 */
export function deserializeUndoStack(items: SerializedUndoItem[]): BoardSnapshot[] {
  return items.map((item) => ({
    board: deserializeBoard(item.board),
    lives: item.lives,
    removedArrowIds: [...item.removedArrowIds],
  }));
}

/**
 * Factory to build a validated, timestamped, and checksummed GameSnapshot.
 */
export function createGameSnapshot(params: {
  gameMode: GameMode;
  levelNumber: number;
  seed: number;
  levelConfig?: LevelConfig;
  board: Board;
  totalArrowsInLevel: number;
  removedArrowIds: string[];
  moveHistory: string[];
  undoStack: BoardSnapshot[];
  lives: number;
  hintsUsedInLevel: number;
  movesCount: number;
  timeElapsed: number;
}): GameSnapshot {
  const base = {
    schemaVersion: SaveConfig.SCHEMA_VERSION,
    gameMode: params.gameMode,
    levelNumber: params.levelNumber,
    seed: params.seed,
    levelConfig: params.levelConfig,
    board: serializeBoard(params.board),
    totalArrowsInLevel: params.totalArrowsInLevel,
    removedArrowIds: [...params.removedArrowIds],
    moveHistory: [...params.moveHistory],
    undoStack: serializeUndoStack(params.undoStack),
    lives: params.lives,
    hintsUsedInLevel: params.hintsUsedInLevel,
    movesCount: params.movesCount,
    timeElapsed: params.timeElapsed,
    savedAt: Date.now(),
  };

  const checksum = computeSnapshotChecksum(base);
  return {
    ...base,
    checksum,
  };
}

/**
 * Validates a raw envelope string from localStorage, ensuring valid JSON,
 * matching envelope checksum, valid schema version, and matching data checksum.
 */
export function validateSnapshotEnvelope(raw: string | null): SnapshotSlotEnvelope | null {
  if (!raw) return null;
  try {
    const envelope: SnapshotSlotEnvelope = JSON.parse(raw);
    if (!envelope || (envelope.slot !== 'A' && envelope.slot !== 'B')) return null;
    if (typeof envelope.sequence !== 'number' || typeof envelope.timestamp !== 'number') return null;
    if (!envelope.data || typeof envelope.data !== 'object') return null;

    const data = envelope.data;
    if (data.schemaVersion !== SaveConfig.SCHEMA_VERSION) return null;
    if (!data.board || typeof data.board.width !== 'number' || !Array.isArray(data.board.arrows)) {
      return null;
    }

    // 1. Envelope checksum verification
    const calculatedEnvelopeChecksum = computeFNV1a(JSON.stringify(data));
    if (envelope.checksum !== calculatedEnvelopeChecksum) {
      console.warn(`[Snapshot] Envelope checksum mismatch in slot ${envelope.slot}`);
      return null;
    }

    // 2. Core snapshot data checksum verification
    const calculatedDataChecksum = computeSnapshotChecksum(data);
    if (data.checksum !== calculatedDataChecksum) {
      console.warn(`[Snapshot] Data checksum mismatch in slot ${envelope.slot}`);
      return null;
    }

    return envelope;
  } catch (err) {
    console.warn('[Snapshot] Failed to parse slot envelope JSON', err);
    return null;
  }
}

/**
 * Reads both Slot A and Slot B, verifies integrity/checksums of each,
 * and returns the freshest valid snapshot. Falls back safely if one slot is corrupt.
 */
export function loadGameSnapshot(): GameSnapshot | null {
  if (typeof window === 'undefined' || !window.localStorage) return null;

  try {
    const rawA = localStorage.getItem(SaveConfig.SLOT_A_KEY);
    const rawB = localStorage.getItem(SaveConfig.SLOT_B_KEY);

    const validA = validateSnapshotEnvelope(rawA);
    const validB = validateSnapshotEnvelope(rawB);

    if (validA && validB) {
      // Both valid: choose highest sequence number, or newer timestamp if equal
      if (validA.sequence > validB.sequence) {
        return validA.data;
      } else if (validB.sequence > validA.sequence) {
        return validB.data;
      } else {
        return validA.timestamp >= validB.timestamp ? validA.data : validB.data;
      }
    }

    if (validA) return validA.data;
    if (validB) return validB.data;

    return null;
  } catch (err) {
    console.warn('[Snapshot] Error while loading snapshot', err);
    return null;
  }
}

/**
 * Checks whether a valid resumable snapshot exists in localStorage.
 */
export function hasGameSnapshot(): boolean {
  return loadGameSnapshot() !== null;
}

/**
 * Persists snapshot into localStorage using atomic two-slot rotation.
 * 
 * Algorithm:
 * 1. Read existing valid slots to discover current sequence number and active slot.
 * 2. Write the new snapshot to the ALTERNATE (inactive) slot with sequence + 1.
 * 3. Update the metadata pointer.
 * 
 * In the event of a sudden power loss, process termination, or brownout during
 * writing, the other slot remains fully intact and uncorrupted.
 */
export function saveGameSnapshot(snapshot: GameSnapshot): boolean {
  if (typeof window === 'undefined' || !window.localStorage) return false;

  try {
    const rawA = localStorage.getItem(SaveConfig.SLOT_A_KEY);
    const rawB = localStorage.getItem(SaveConfig.SLOT_B_KEY);

    const validA = validateSnapshotEnvelope(rawA);
    const validB = validateSnapshotEnvelope(rawB);

    let currentSeq = 0;
    let lastSlot: 'A' | 'B' | null = null;

    if (validA && validB) {
      if (validA.sequence >= validB.sequence) {
        currentSeq = validA.sequence;
        lastSlot = 'A';
      } else {
        currentSeq = validB.sequence;
        lastSlot = 'B';
      }
    } else if (validA) {
      currentSeq = validA.sequence;
      lastSlot = 'A';
    } else if (validB) {
      currentSeq = validB.sequence;
      lastSlot = 'B';
    }

    // Target the alternate slot
    const targetSlot: 'A' | 'B' = lastSlot === 'A' ? 'B' : 'A';
    const targetKey = targetSlot === 'A' ? SaveConfig.SLOT_A_KEY : SaveConfig.SLOT_B_KEY;
    const newSeq = currentSeq + 1;
    const now = Date.now();

    const envelope: SnapshotSlotEnvelope = {
      slot: targetSlot,
      sequence: newSeq,
      timestamp: now,
      checksum: computeFNV1a(JSON.stringify(snapshot)),
      data: snapshot,
    };

    const serializedEnvelope = JSON.stringify(envelope);

    // Step 1: Write target slot atomically
    localStorage.setItem(targetKey, serializedEnvelope);

    // Step 2: Write metadata pointer
    const meta: SnapshotMetadata = {
      activeSlot: targetSlot,
      sequence: newSeq,
      lastSavedAt: now,
    };
    localStorage.setItem(SaveConfig.META_KEY, JSON.stringify(meta));

    return true;
  } catch (err) {
    console.error('[Snapshot] Failed to save snapshot', err);
    return false;
  }
}

/**
 * Clears both snapshot slots and metadata when a level is completed, abandoned, or reset.
 */
export function clearGameSnapshot(): void {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    localStorage.removeItem(SaveConfig.SLOT_A_KEY);
    localStorage.removeItem(SaveConfig.SLOT_B_KEY);
    localStorage.removeItem(SaveConfig.META_KEY);
  } catch (err) {
    console.error('[Snapshot] Failed to clear snapshot slots', err);
  }
}
