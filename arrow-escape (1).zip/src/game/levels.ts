import { LevelConfig } from './types';

export const BASE_CAMPAIGN_LEVELS = 60;
export const TOTAL_CAMPAIGN_LEVELS = 60;

/**
 * High-entropy 32-bit avalanche hash for deterministic level generation across runs.
 */
export function hashLevelSeed(lvl: number, salt: number = 0): number {
  let h = (lvl * 0x9e3779b9 + salt) >>> 0;
  h ^= h >>> 16;
  h = Math.imul(h, 0x85ebca6b) >>> 0;
  h ^= h >>> 13;
  h = Math.imul(h, 0xc2b2ae35) >>> 0;
  h ^= h >>> 16;
  return h >>> 0;
}

export interface CampaignTierInfo {
  tierNumber: number;
  name: string;
  badge: string;
  description: string;
}

/**
 * Returns the thematic mastery tier for any level from 1 to infinity.
 */
export function getCampaignTier(level: number): CampaignTierInfo {
  const lvl = Math.max(1, Math.floor(level));

  if (lvl <= 5) return { tierNumber: 1, name: 'Novice', badge: '🌱', description: 'Foundations & First Steps' };
  if (lvl <= 20) return { tierNumber: 2, name: 'Apprentice', badge: '🔷', description: 'Expanding Corridors' };
  if (lvl <= 40) return { tierNumber: 3, name: 'Adept', badge: '🔶', description: 'Serpentine Turns' };
  if (lvl <= 60) return { tierNumber: 4, name: 'Expert', badge: '💠', description: 'Master Labyrinths' };
  if (lvl <= 80) return { tierNumber: 5, name: 'Master I', badge: '👑', description: 'Dense Entanglement' };
  if (lvl <= 100) return { tierNumber: 6, name: 'Master II', badge: '👑', description: 'Apex Chambers' };
  if (lvl <= 130) return { tierNumber: 7, name: 'Grandmaster I', badge: '💎', description: 'Infinite Horizon' };
  if (lvl <= 160) return { tierNumber: 8, name: 'Grandmaster II', badge: '💎', description: 'Deep Convergence' };
  if (lvl <= 200) return { tierNumber: 9, name: 'Mythic I', badge: '🔥', description: 'Chrono-Labyrinths' };
  if (lvl <= 250) return { tierNumber: 10, name: 'Mythic II', badge: '🔥', description: 'Nexus Pathways' };
  if (lvl <= 320) return { tierNumber: 11, name: 'Paragon', badge: '⚡', description: 'Tactical Zenith' };
  if (lvl <= 400) return { tierNumber: 12, name: 'Ascendant', badge: '🌟', description: 'Transcendent Flow' };
  if (lvl <= 500) return { tierNumber: 13, name: 'Celestial', badge: '🌌', description: 'Cosmic Constellations' };
  if (lvl <= 650) return { tierNumber: 14, name: 'Astral', badge: '✨', description: 'Astral Weave' };
  if (lvl <= 800) return { tierNumber: 15, name: 'Transcendent', badge: '🔮', description: 'Dimensional Warp' };
  if (lvl <= 1000) return { tierNumber: 16, name: 'Cosmic', badge: '🪐', description: 'Infinite Singularity' };

  const infiniteTier = Math.floor((lvl - 1000) / 100) + 17;
  return {
    tierNumber: infiniteTier,
    name: `Infinite Sovereign ${infiniteTier - 16}`,
    badge: '♾️',
    description: 'Boundless Procedural Mastery',
  };
}

/**
 * Returns parameters for any campaign level (Level 1 to infinity).
 * Preserves handcrafted curves for levels 1-60 and dynamically scales
 * difficulty procedurally for all levels beyond 60.
 */
export function getCampaignLevelConfig(level: number): LevelConfig {
  const lvl = Math.max(1, Math.floor(level));

  // Level 1-5: 4x4 tutorial & gentle start
  if (lvl <= 5) {
    return {
      levelNumber: lvl,
      width: 4,
      height: 4,
      arrowCount: 3 + lvl, // 4 to 8 arrows
      minLength: 2,
      maxLength: 3,
      bentChance: lvl === 1 ? 0.2 : 0.45,
      seed: 1000 + lvl * 137,
      isBoss: false,
      title: lvl === 1 ? 'First Steps' : `Level ${lvl}`,
      tutorialTip:
        lvl === 1
          ? 'Tap an arrow pointing towards an unobstructed board edge to let it escape.'
          : undefined,
    };
  }

  // Boss levels up to 60 (10, 20, 30, 40, 50, 60)
  if (lvl <= 60 && lvl % 10 === 0) {
    const bossIndex = lvl / 10;
    const size = Math.min(8, 5 + bossIndex); // 6x6 up to 8x8
    return {
      levelNumber: lvl,
      width: size,
      height: size,
      arrowCount: 10 + bossIndex * 3,
      minLength: 2,
      maxLength: Math.min(5, 3 + Math.floor(bossIndex / 2)),
      bentChance: 0.7,
      seed: 8888 + lvl * 313,
      isBoss: true,
      title: `Boss Challenge ${bossIndex}`,
      tutorialTip: undefined,
    };
  }

  // Levels 6-20: 5x5 to 6x6
  if (lvl <= 20) {
    const progress = (lvl - 5) / 15;
    const size = progress < 0.5 ? 5 : 6;
    return {
      levelNumber: lvl,
      width: size,
      height: size,
      arrowCount: Math.round(7 + progress * 5),
      minLength: 2,
      maxLength: 4,
      bentChance: 0.55,
      seed: 2000 + lvl * 239,
      isBoss: false,
      title: `Level ${lvl}`,
      tutorialTip: undefined,
    };
  }

  // Levels 21-40: 6x6 to 7x7
  if (lvl <= 40) {
    const progress = (lvl - 20) / 20;
    const size = progress < 0.5 ? 6 : 7;
    return {
      levelNumber: lvl,
      width: size,
      height: size,
      arrowCount: Math.round(11 + progress * 6),
      minLength: 2,
      maxLength: 4,
      bentChance: 0.65,
      seed: 4000 + lvl * 373,
      isBoss: false,
      title: `Level ${lvl}`,
      tutorialTip: undefined,
    };
  }

  // Levels 41-60: 7x7 to 8x8
  if (lvl <= 60) {
    const progress = (lvl - 40) / 20;
    const size = progress < 0.6 ? 7 : 8;
    return {
      levelNumber: lvl,
      width: size,
      height: size,
      arrowCount: Math.round(16 + progress * 8),
      minLength: 2,
      maxLength: 5,
      bentChance: 0.75,
      seed: 6000 + lvl * 521,
      isBoss: false,
      title: `Level ${lvl}`,
      tutorialTip: undefined,
    };
  }

  // =========================================================================
  // Infinite Procedural Progression beyond Level 60
  // Consistent difficulty scaling with progressive parameters & boss climaxes
  // =========================================================================
  const tier = getCampaignTier(lvl);
  const isBoss = lvl % 10 === 0;
  const isGrandBoss = lvl % 50 === 0;
  const isApexBoss = lvl % 100 === 0;

  const stepInCycle = (lvl - 1) % 10; // 0 (start) to 9 (boss)
  const infiniteOffset = lvl - 60; // 1, 2, ... into infinite territory

  // Macro difficulty factor that steadily increases with level depth
  const macroBonus = Math.floor(Math.sqrt(infiniteOffset) * 0.85);

  // Grid dimensions with rhythmic pacing:
  // - 61-90: 7x7 warmups, 8x8 standard & bosses
  // - 91-160: 8x8 standard, with 7x7 first breathers
  // - 161-260: 8x8 standard, 9x9 bosses
  // - 261+: 8x8 breathers, 9x9 standard & bosses (10x10 on 100-level Apex Bosses)
  let size = 8;
  if (lvl <= 90) {
    size = stepInCycle <= 1 ? 7 : 8;
  } else if (lvl <= 160) {
    size = stepInCycle === 0 ? 7 : 8;
  } else if (lvl <= 260) {
    size = isBoss ? 9 : 8;
  } else {
    if (stepInCycle <= 1) {
      size = 8;
    } else if (isApexBoss && lvl >= 400) {
      size = 10;
    } else {
      size = 9;
    }
  }

  // Arrow Count Scaling:
  // Scales smoothly according to grid size, level depth, and cycle position
  const cycleRatio = stepInCycle / 9; // 0.0 to 1.0 (1.0 at boss)
  const intraCycleBonus = isBoss ? 7 : Math.round(cycleRatio * 5);
  const milestoneBonus = isApexBoss ? 3 : isGrandBoss ? 2 : 0;

  let count: number;
  if (size === 7) {
    count = Math.min(22, 16 + Math.floor(macroBonus * 0.4) + Math.floor(stepInCycle * 0.5));
  } else if (size === 8) {
    count = Math.min(28, 19 + macroBonus + intraCycleBonus + milestoneBonus);
  } else if (size === 9) {
    count = Math.min(36, 26 + Math.floor(macroBonus * 0.8) + intraCycleBonus + milestoneBonus);
  } else {
    // 10x10 grand milestone
    count = Math.min(42, 33 + macroBonus + intraCycleBonus + milestoneBonus);
  }

  // Serpentine bent arrow probability:
  // Escalates from 0.68 at Level 61 up towards 0.88 at high tiers
  const baseBent = 0.68 + Math.min(0.14, (infiniteOffset / 200) * 0.14);
  const cycleBent = (stepInCycle / 9) * 0.08;
  const bentChance = Math.min(0.88, Number((baseBent + cycleBent).toFixed(3)));

  // Arrow lengths:
  // Larger grids and higher levels allow longer winding snake arrows
  let maxLength = 4;
  if (size === 7) {
    maxLength = isBoss ? 5 : 4;
  } else if (size === 8) {
    maxLength = stepInCycle >= 5 || isBoss ? 5 : 4;
  } else if (size === 9) {
    maxLength = isBoss ? 6 : 5;
  } else {
    maxLength = 7;
  }

  // Deterministic seed generated with 32-bit hash
  const seed = hashLevelSeed(lvl, 42);

  // Evocative procedural level title
  let title = `Level ${lvl} · ${tier.name}`;
  if (isApexBoss) {
    title = `Level ${lvl} · ${tier.name} Apex Boss`;
  } else if (isGrandBoss) {
    title = `Level ${lvl} · ${tier.name} Grand Boss`;
  } else if (isBoss) {
    title = `Level ${lvl} · ${tier.name} Boss Trial`;
  }

  return {
    levelNumber: lvl,
    width: size,
    height: size,
    arrowCount: count,
    minLength: 2,
    maxLength,
    bentChance,
    seed,
    isBoss,
    title,
    tutorialTip: undefined,
  };
}

/**
 * Returns configuration for an Infinite mode puzzle.
 * Scales difficulty consistently across endless streaks with boss milestones.
 */
export function getInfiniteLevelConfig(streak: number): LevelConfig {
  const currentStreak = Math.max(1, Math.floor(streak));
  const isBossMilestone = currentStreak % 5 === 0;
  const isGrandMilestone = currentStreak % 25 === 0;

  // Grid dimensions scale progressively
  let size = 5;
  if (currentStreak <= 3) {
    size = 4;
  } else if (currentStreak <= 10) {
    size = 5;
  } else if (currentStreak <= 22) {
    size = 6;
  } else if (currentStreak <= 40) {
    size = 7;
  } else if (currentStreak <= 80) {
    size = isBossMilestone ? 9 : 8;
  } else {
    size = 9;
  }

  // Arrow count scaling with streak
  const streakFactor = Math.floor(Math.sqrt(currentStreak) * 1.8);
  const bossBonus = isGrandMilestone ? 4 : isBossMilestone ? 2 : 0;
  let count: number;

  if (size === 4) {
    count = Math.min(8, 4 + currentStreak);
  } else if (size === 5) {
    count = Math.min(12, 7 + streakFactor + bossBonus);
  } else if (size === 6) {
    count = Math.min(16, 10 + streakFactor + bossBonus);
  } else if (size === 7) {
    count = Math.min(22, 14 + streakFactor + bossBonus);
  } else if (size === 8) {
    count = Math.min(28, 18 + streakFactor + bossBonus);
  } else {
    count = Math.min(35, 24 + streakFactor + bossBonus);
  }

  // Bent snake probability
  const bentChance = Math.min(
    0.88,
    Number((0.45 + Math.min(0.4, (currentStreak / 60) * 0.4)).toFixed(3))
  );

  const maxLength = size <= 5 ? 3 : size <= 7 ? 4 : isBossMilestone ? 6 : 5;
  const seed = hashLevelSeed(currentStreak, 9973);

  let title = `Endless #${currentStreak}`;
  if (isGrandMilestone) {
    title = `Endless Grand Boss #${currentStreak}`;
  } else if (isBossMilestone) {
    title = `Endless Boss #${currentStreak}`;
  }

  return {
    levelNumber: currentStreak,
    width: size,
    height: size,
    arrowCount: count,
    minLength: 2,
    maxLength,
    bentChance,
    seed,
    isBoss: isBossMilestone,
    title,
  };
}

/**
 * Returns configuration for today's Daily Puzzle.
 */
export function getDailyLevelConfig(dateString?: string): LevelConfig {
  const today = dateString || new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const numericSeed = today.split('-').reduce((acc, part) => acc * 100 + Number(part), 0);

  return {
    levelNumber: 0,
    width: 6,
    height: 6,
    arrowCount: 14,
    minLength: 2,
    maxLength: 4,
    bentChance: 0.7,
    seed: numericSeed,
    isBoss: false,
    title: `Daily Puzzle · ${today}`,
  };
}
