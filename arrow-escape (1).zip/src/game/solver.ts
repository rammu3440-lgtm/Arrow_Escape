import { Arrow, Board, SolverResult } from './types';
import { isBlocked, removeArrow, safeArrows } from './core';

/**
 * Solves a board to find a valid removal sequence, branching metrics,
 * and difficulty score.
 */
export function solve(board: Board): SolverResult {
  let currentBoard = board;
  const removalOrder: string[] = [];
  const branchingCounts: number[] = [];
  let decoyCount = 0;

  while (currentBoard.arrows.length > 0) {
    const safe = safeArrows(currentBoard);
    branchingCounts.push(safe.length);

    if (safe.length === 0) {
      // Deadlock: board cannot be solved
      return {
        solvable: false,
        removalOrder: [],
        averageBranching: 0,
        longestChain: 0,
        decoyCount: 0,
        difficultyScore: 9999,
      };
    }

    // Measure decoys: if more than 2 safe moves exist, alternative choices exist
    if (safe.length > 2) {
      decoyCount += safe.length - 1;
    }

    // Pick the most impactful arrow to advance solver predictably
    // Score each safe arrow by how many new arrows it unblocks
    let bestArrow = safe[0];
    let maxUnblocked = -1;

    for (const arrow of safe) {
      const simulatedBoard = removeArrow(currentBoard, arrow.id);
      const nextSafe = safeArrows(simulatedBoard);
      const unblocked = nextSafe.length;
      if (unblocked > maxUnblocked) {
        maxUnblocked = unblocked;
        bestArrow = arrow;
      }
    }

    removalOrder.push(bestArrow.id);
    currentBoard = removeArrow(currentBoard, bestArrow.id);
  }

  const averageBranching =
    branchingCounts.length > 0
      ? branchingCounts.reduce((a, b) => a + b, 0) / branchingCounts.length
      : 1;

  // Approximate longest dependency chain
  const longestChain = Math.max(1, removalOrder.length - Math.floor(averageBranching));

  // Difficulty score: higher when board is larger, more arrows, and lower branching factor (more tight choke points)
  const baseSize = board.width * board.height;
  const tightChokeFactor = Math.max(1, 4 - averageBranching);
  const difficultyScore = Math.round(
    removalOrder.length * 10 + tightChokeFactor * 15 + longestChain * 5 + baseSize * 0.5
  );

  return {
    solvable: true,
    removalOrder,
    averageBranching: Number(averageBranching.toFixed(2)),
    longestChain,
    decoyCount,
    difficultyScore,
  };
}

/**
 * Finds the single best hint arrow to highlight for the player.
 * Prioritizes safe arrows that immediately unblock the most other arrows.
 */
export function findBestHint(board: Board): Arrow | null {
  const safe = safeArrows(board);
  if (safe.length === 0) return null;
  if (safe.length === 1) return safe[0];

  let bestArrow = safe[0];
  let maxUnblocked = -1;

  for (const arrow of safe) {
    const nextBoard = removeArrow(board, arrow.id);
    const nextSafe = safeArrows(nextBoard);
    // Score based on how many previously blocked arrows are now safe
    const newlySafeCount = nextSafe.filter(
      (candidate) => isBlocked(board, candidate)
    ).length;

    if (newlySafeCount > maxUnblocked) {
      maxUnblocked = newlySafeCount;
      bestArrow = arrow;
    }
  }

  return bestArrow;
}
