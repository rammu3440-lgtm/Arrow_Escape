import { PaletteName } from './types';

export interface ArrowColorSpec {
  fill: string;
  stroke: string;
  head: string;
  glow: string;
}

export interface ThemeColors {
  name: string;
  bgBoard: string;
  gridLine: string;
  cellEmpty: string;
  shadow: string;
  arrowPalette: ArrowColorSpec[];
}

export const THEME_PALETTES: Record<PaletteName, { light: ThemeColors; dark: ThemeColors }> = {
  pastel: {
    light: {
      name: 'Calm Pastel',
      bgBoard: '#F8FAFC',
      gridLine: '#E2E8F0',
      cellEmpty: '#FFFFFF',
      shadow: 'rgba(15, 23, 42, 0.08)',
      arrowPalette: [
        { fill: '#60A5FA', stroke: '#3B82F6', head: '#1D4ED8', glow: 'rgba(59, 130, 246, 0.35)' }, // Blue
        { fill: '#34D399', stroke: '#10B981', head: '#047857', glow: 'rgba(16, 185, 129, 0.35)' }, // Emerald
        { fill: '#F472B6', stroke: '#EC4899', head: '#BE185D', glow: 'rgba(236, 72, 153, 0.35)' }, // Pink
        { fill: '#A78BFA', stroke: '#8B5CF6', head: '#6D28D9', glow: 'rgba(139, 92, 246, 0.35)' }, // Purple
        { fill: '#FBBF24', stroke: '#F59E0B', head: '#B45309', glow: 'rgba(245, 158, 11, 0.35)' }, // Amber
        { fill: '#2DD4BF', stroke: '#14B8A6', head: '#0F766E', glow: 'rgba(20, 184, 166, 0.35)' }, // Teal
      ],
    },
    dark: {
      name: 'Calm Pastel (Dark)',
      bgBoard: '#0F172A',
      gridLine: '#1E293B',
      cellEmpty: '#1E293B',
      shadow: 'rgba(0, 0, 0, 0.4)',
      arrowPalette: [
        { fill: '#3B82F6', stroke: '#60A5FA', head: '#93C5FD', glow: 'rgba(96, 165, 250, 0.4)' },
        { fill: '#10B981', stroke: '#34D399', head: '#6EE7B7', glow: 'rgba(52, 211, 153, 0.4)' },
        { fill: '#EC4899', stroke: '#F472B6', head: '#F9A8D4', glow: 'rgba(244, 114, 182, 0.4)' },
        { fill: '#8B5CF6', stroke: '#A78BFA', head: '#C4B5FD', glow: 'rgba(167, 139, 250, 0.4)' },
        { fill: '#F59E0B', stroke: '#FBBF24', head: '#FDE68A', glow: 'rgba(251, 191, 36, 0.4)' },
        { fill: '#14B8A6', stroke: '#2DD4BF', head: '#5EEAD4', glow: 'rgba(45, 212, 191, 0.4)' },
      ],
    },
  },
  forest: {
    light: {
      name: 'Zen Forest',
      bgBoard: '#F4F7F4',
      gridLine: '#E1E8E1',
      cellEmpty: '#FFFFFF',
      shadow: 'rgba(27, 43, 27, 0.08)',
      arrowPalette: [
        { fill: '#48BB78', stroke: '#38A169', head: '#22543D', glow: 'rgba(56, 161, 105, 0.35)' },
        { fill: '#319795', stroke: '#285E61', head: '#1D4044', glow: 'rgba(49, 151, 149, 0.35)' },
        { fill: '#D69E2E', stroke: '#B7791F', head: '#744210', glow: 'rgba(183, 121, 31, 0.35)' },
        { fill: '#ED8936', stroke: '#DD6B20', head: '#7B341E', glow: 'rgba(221, 107, 32, 0.35)' },
        { fill: '#38B2AC', stroke: '#2C7A7B', head: '#234E52', glow: 'rgba(56, 178, 172, 0.35)' },
        { fill: '#805AD5', stroke: '#6B46C1', head: '#44337A', glow: 'rgba(107, 70, 193, 0.35)' },
      ],
    },
    dark: {
      name: 'Zen Forest (Dark)',
      bgBoard: '#0D1A14',
      gridLine: '#162E23',
      cellEmpty: '#14291F',
      shadow: 'rgba(0, 0, 0, 0.4)',
      arrowPalette: [
        { fill: '#38A169', stroke: '#68D391', head: '#9AE6B4', glow: 'rgba(104, 211, 145, 0.4)' },
        { fill: '#285E61', stroke: '#4FD1C5', head: '#81E6D9', glow: 'rgba(79, 209, 197, 0.4)' },
        { fill: '#B7791F', stroke: '#F6E05E', head: '#FAF089', glow: 'rgba(246, 224, 94, 0.4)' },
        { fill: '#DD6B20', stroke: '#FBD38D', head: '#FEEBC8', glow: 'rgba(251, 211, 141, 0.4)' },
        { fill: '#2C7A7B', stroke: '#38B2AC', head: '#81E6D9', glow: 'rgba(56, 178, 172, 0.4)' },
        { fill: '#6B46C1', stroke: '#B794F4', head: '#D6BCFA', glow: 'rgba(183, 148, 244, 0.4)' },
      ],
    },
  },
  ocean: {
    light: {
      name: 'Ocean Breeze',
      bgBoard: '#F0F9FF',
      gridLine: '#E0F2FE',
      cellEmpty: '#FFFFFF',
      shadow: 'rgba(12, 74, 110, 0.08)',
      arrowPalette: [
        { fill: '#0EA5E9', stroke: '#0284C7', head: '#0369A1', glow: 'rgba(2, 132, 199, 0.35)' },
        { fill: '#06B6D4', stroke: '#0891B2', head: '#155E75', glow: 'rgba(8, 145, 178, 0.35)' },
        { fill: '#6366F1', stroke: '#4F46E5', head: '#3730A3', glow: 'rgba(79, 70, 229, 0.35)' },
        { fill: '#14B8A6', stroke: '#0D9488', head: '#115E59', glow: 'rgba(13, 148, 136, 0.35)' },
        { fill: '#3B82F6', stroke: '#2563EB', head: '#1E40AF', glow: 'rgba(37, 99, 235, 0.35)' },
        { fill: '#8B5CF6', stroke: '#7C3AED', head: '#5B21B6', glow: 'rgba(124, 58, 237, 0.35)' },
      ],
    },
    dark: {
      name: 'Ocean Breeze (Dark)',
      bgBoard: '#081726',
      gridLine: '#0F2942',
      cellEmpty: '#0C2033',
      shadow: 'rgba(0, 0, 0, 0.4)',
      arrowPalette: [
        { fill: '#0284C7', stroke: '#38BDF8', head: '#7DD3FC', glow: 'rgba(56, 189, 248, 0.4)' },
        { fill: '#0891B2', stroke: '#22D3EE', head: '#67E8F9', glow: 'rgba(34, 211, 238, 0.4)' },
        { fill: '#4F46E5', stroke: '#818CF8', head: '#A5B4FC', glow: 'rgba(129, 140, 248, 0.4)' },
        { fill: '#0D9488', stroke: '#2DD4BF', head: '#5EEAD4', glow: 'rgba(45, 212, 191, 0.4)' },
        { fill: '#2563EB', stroke: '#60A5FA', head: '#93C5FD', glow: 'rgba(96, 165, 250, 0.4)' },
        { fill: '#7C3AED', stroke: '#A78BFA', head: '#C4B5FD', glow: 'rgba(167, 139, 250, 0.4)' },
      ],
    },
  },
  contrast: {
    light: {
      name: 'High Contrast (Accessible)',
      bgBoard: '#FFFFFF',
      gridLine: '#CBD5E1',
      cellEmpty: '#F8FAFC',
      shadow: 'rgba(0, 0, 0, 0.15)',
      arrowPalette: [
        { fill: '#0072B2', stroke: '#004975', head: '#002E4A', glow: 'rgba(0, 114, 178, 0.4)' }, // Blue
        { fill: '#E69F00', stroke: '#B27B00', head: '#7D5700', glow: 'rgba(230, 159, 0, 0.4)' }, // Orange
        { fill: '#009E73', stroke: '#006E50', head: '#004734', glow: 'rgba(0, 158, 115, 0.4)' }, // Green
        { fill: '#CC79A7', stroke: '#9A4F79', head: '#6E2D53', glow: 'rgba(204, 121, 167, 0.4)' }, // Reddish purple
        { fill: '#56B4E9', stroke: '#2688BD', head: '#13597D', glow: 'rgba(86, 180, 233, 0.4)' }, // Sky blue
        { fill: '#D55E00', stroke: '#9B4400', head: '#682D00', glow: 'rgba(213, 94, 0, 0.4)' }, // Vermillion
      ],
    },
    dark: {
      name: 'High Contrast (Dark)',
      bgBoard: '#090D16',
      gridLine: '#334155',
      cellEmpty: '#1E293B',
      shadow: 'rgba(0, 0, 0, 0.6)',
      arrowPalette: [
        { fill: '#0072B2', stroke: '#56B4E9', head: '#A3D9F8', glow: 'rgba(86, 180, 233, 0.5)' },
        { fill: '#E69F00', stroke: '#F0C968', head: '#F8E2A7', glow: 'rgba(240, 201, 104, 0.5)' },
        { fill: '#009E73', stroke: '#33D4A8', head: '#85E9CD', glow: 'rgba(51, 212, 168, 0.5)' },
        { fill: '#CC79A7', stroke: '#E3A3C7', head: '#F1CCE1', glow: 'rgba(227, 163, 199, 0.5)' },
        { fill: '#56B4E9', stroke: '#A3D9F8', head: '#D6EFFF', glow: 'rgba(163, 217, 248, 0.5)' },
        { fill: '#D55E00', stroke: '#FF944D', head: '#FFC299', glow: 'rgba(255, 148, 77, 0.5)' },
      ],
    },
  },
  amethyst: {
    light: {
      name: 'Midnight Amethyst',
      bgBoard: '#FBF8FF',
      gridLine: '#EDE4F7',
      cellEmpty: '#FFFFFF',
      shadow: 'rgba(59, 7, 100, 0.08)',
      arrowPalette: [
        { fill: '#9333EA', stroke: '#7E22CE', head: '#581C87', glow: 'rgba(147, 51, 234, 0.35)' },
        { fill: '#C084FC', stroke: '#A855F7', head: '#7E22CE', glow: 'rgba(192, 132, 252, 0.35)' },
        { fill: '#F472B6', stroke: '#DB2777', head: '#9D174D', glow: 'rgba(244, 114, 182, 0.35)' },
        { fill: '#6366F1', stroke: '#4F46E5', head: '#3730A3', glow: 'rgba(99, 102, 241, 0.35)' },
        { fill: '#E879F9', stroke: '#D946EF', head: '#A21CAF', glow: 'rgba(232, 121, 249, 0.35)' },
        { fill: '#818CF8', stroke: '#6366F1', head: '#4338CA', glow: 'rgba(129, 140, 248, 0.35)' },
      ],
    },
    dark: {
      name: 'Midnight Amethyst (Dark)',
      bgBoard: '#150A21',
      gridLine: '#2B1645',
      cellEmpty: '#201033',
      shadow: 'rgba(0, 0, 0, 0.5)',
      arrowPalette: [
        { fill: '#A855F7', stroke: '#C084FC', head: '#E9D5FF', glow: 'rgba(168, 85, 247, 0.45)' },
        { fill: '#D946EF', stroke: '#F0ABFC', head: '#FAE8FF', glow: 'rgba(217, 70, 239, 0.45)' },
        { fill: '#818CF8', stroke: '#A5B4FC', head: '#E0E7FF', glow: 'rgba(129, 140, 248, 0.45)' },
        { fill: '#F472B6', stroke: '#FBCFE8', head: '#FDF2F8', glow: 'rgba(244, 114, 182, 0.45)' },
        { fill: '#C084FC', stroke: '#DDD6FE', head: '#F5F3FF', glow: 'rgba(192, 132, 252, 0.45)' },
        { fill: '#E879F9', stroke: '#F5D0FE', head: '#FDF4FF', glow: 'rgba(232, 121, 249, 0.45)' },
      ],
    },
  },
  sunset: {
    light: {
      name: 'Sunset Horizon',
      bgBoard: '#FFF7ED',
      gridLine: '#FFEDD5',
      cellEmpty: '#FFFFFF',
      shadow: 'rgba(124, 45, 18, 0.08)',
      arrowPalette: [
        { fill: '#F97316', stroke: '#EA580C', head: '#9A3412', glow: 'rgba(249, 115, 22, 0.35)' },
        { fill: '#FB923C', stroke: '#F97316', head: '#C2410C', glow: 'rgba(251, 146, 60, 0.35)' },
        { fill: '#F43F5E', stroke: '#E11D48', head: '#9F1239', glow: 'rgba(244, 63, 94, 0.35)' },
        { fill: '#FBBF24', stroke: '#F59E0B', head: '#B45309', glow: 'rgba(251, 191, 36, 0.35)' },
        { fill: '#FB7185', stroke: '#F43F5E', head: '#BE123C', glow: 'rgba(251, 113, 133, 0.35)' },
        { fill: '#E11D48', stroke: '#BE123C', head: '#881337', glow: 'rgba(225, 29, 72, 0.35)' },
      ],
    },
    dark: {
      name: 'Sunset Horizon (Dark)',
      bgBoard: '#1F0C06',
      gridLine: '#3F190D',
      cellEmpty: '#2B1209',
      shadow: 'rgba(0, 0, 0, 0.5)',
      arrowPalette: [
        { fill: '#EA580C', stroke: '#FB923C', head: '#FFEDD5', glow: 'rgba(234, 88, 12, 0.45)' },
        { fill: '#E11D48', stroke: '#FB7185', head: '#FFE4E6', glow: 'rgba(225, 29, 72, 0.45)' },
        { fill: '#F59E0B', stroke: '#FCD34D', head: '#FEF3C7', glow: 'rgba(245, 158, 11, 0.45)' },
        { fill: '#F97316', stroke: '#FDBA74', head: '#FFEDD5', glow: 'rgba(249, 115, 22, 0.45)' },
        { fill: '#BE123C', stroke: '#FDA4AF', head: '#FFF1F2', glow: 'rgba(190, 18, 60, 0.45)' },
        { fill: '#D97706', stroke: '#FBBF24', head: '#FEF3C7', glow: 'rgba(217, 119, 6, 0.45)' },
      ],
    },
  },
};
