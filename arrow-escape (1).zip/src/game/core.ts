import { Arrow, Board, Cell, Direction, BoardSnapshot } from './types';

export function cellKey(x: number, y: number): string {
  return `${x},${y}`;
}

export function parseCellKey(key: string): Cell {
  const [x, y] = key.split(',').map(Number);
  return { x, y };
}

export function getDelta(direction: Direction): { dx: number; dy: number } {
  switch (direction) {
    case 'UP':
      return { dx: 0, dy: -1 };
    case 'DOWN':
      return { dx: 0, dy: 1 };
    case 'LEFT':
      return { dx: -1, dy: 0 };
    case 'RIGHT':
      return { dx: 1, dy: 0 };
  }
}

export function getOppositeDirection(direction: Direction): Direction {
  switch (direction) {
    case 'UP':
      return 'DOWN';
    case 'DOWN':
      return 'UP';
    case 'LEFT':
      return 'RIGHT';
    case 'RIGHT':
      return 'LEFT';
  }
}

export function createBoard(width: number, height: number, arrows: Arrow[]): Board {
  const grid = new Map<string, string>();
  for (const arrow of arrows) {
    for (const cell of arrow.body) {
      grid.set(cellKey(cell.x, cell.y), arrow.id);
    }
  }
  return { width, height, arrows: [...arrows], grid };
}

/**
 * Ray-casts from head cell in the arrow's direction to the edge.
 * If any cell along this ray is occupied, the arrow is blocked.
 */
export function isBlocked(board: Board, arrow: Arrow): boolean {
  const { dx, dy } = getDelta(arrow.direction);
  let cx = arrow.head.x + dx;
  let cy = arrow.head.y + dy;

  while (cx >= 0 && cx < board.width && cy >= 0 && cy < board.height) {
    const key = cellKey(cx, cy);
    if (board.grid.has(key)) {
      return true; // Occupied by an arrow
    }
    cx += dx;
    cy += dy;
  }

  return false;
}

/**
 * Returns all arrows currently safe to slide out.
 */
export function safeArrows(board: Board): Arrow[] {
  return board.arrows.filter((arrow) => !isBlocked(board, arrow));
}

/**
 * Removes an arrow from the board and returns a new Board state.
 */
export function removeArrow(board: Board, arrowId: string): Board {
  const target = board.arrows.find((a) => a.id === arrowId);
  if (!target) return board;

  const newGrid = new Map(board.grid);
  for (const cell of target.body) {
    newGrid.delete(cellKey(cell.x, cell.y));
  }

  const newArrows = board.arrows.filter((a) => a.id !== arrowId);
  return {
    width: board.width,
    height: board.height,
    arrows: newArrows,
    grid: newGrid,
  };
}

/**
 * Checks if all arrows have been cleared.
 */
export function isCleared(board: Board): boolean {
  return board.arrows.length === 0;
}

/**
 * Clone board for snapshots/undo.
 */
export function cloneBoard(board: Board): Board {
  return {
    width: board.width,
    height: board.height,
    arrows: board.arrows.map((a) => ({
      ...a,
      head: { ...a.head },
      body: a.body.map((c) => ({ ...c })),
    })),
    grid: new Map(board.grid),
  };
}

export function createSnapshot(
  board: Board,
  lives: number,
  removedArrowIds: string[]
): BoardSnapshot {
  return {
    board: cloneBoard(board),
    lives,
    removedArrowIds: [...removedArrowIds],
  };
}
