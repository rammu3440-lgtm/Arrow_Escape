import { AmbientSoundscape } from './types';

// Web Audio API Synthesizer, Ambient Soundscapes, and Haptics

let audioCtx: AudioContext | null = null;
let masterAmbientGain: GainNode | null = null;
let activeAmbientNodes: {
  sources: (AudioNode & { stop?: () => void })[];
  intervals: number[];
} | null = null;
let currentAmbientSoundscape: AmbientSoundscape = 'none';

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

function getMasterAmbientGain(ctx: AudioContext): GainNode {
  if (!masterAmbientGain) {
    masterAmbientGain = ctx.createGain();
    masterAmbientGain.gain.setValueAtTime(0, ctx.currentTime);
    masterAmbientGain.connect(ctx.destination);
  }
  return masterAmbientGain;
}

function createPinkNoiseBuffer(ctx: AudioContext): AudioBuffer {
  const bufferSize = ctx.sampleRate * 4;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    b0 = 0.99886 * b0 + white * 0.0555179;
    b1 = 0.99332 * b1 + white * 0.0750759;
    b2 = 0.96900 * b2 + white * 0.1538520;
    b3 = 0.86650 * b3 + white * 0.3104856;
    b4 = 0.55000 * b4 + white * 0.5329522;
    b5 = -0.7616 * b5 - white * 0.0168980;
    data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
    b6 = white * 0.115926;
  }
  return buffer;
}

function stopCurrentAmbient() {
  if (activeAmbientNodes) {
    activeAmbientNodes.intervals.forEach((id) => window.clearInterval(id));
    activeAmbientNodes.sources.forEach((node) => {
      try {
        if ('stop' in node && typeof node.stop === 'function') {
          node.stop();
        }
        node.disconnect();
      } catch {
        // Ignore
      }
    });
    activeAmbientNodes = null;
  }
}

export const soundManager = {
  playTap(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(140, ctx.currentTime + 0.04);

      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.05);
    } catch {
      // AudioContext policy suppression
    }
  },

  playWhoosh(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      // Calming whoosh chord
      const freqs = [330, 440, 660];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq * 0.9, now);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.25, now + 0.22);

        const vol = 0.08 / (idx + 1);
        gain.gain.setValueAtTime(0.001, now);
        gain.gain.linearRampToValueAtTime(vol, now + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now);
        osc.stop(now + 0.26);
      });
    } catch {
      // Ignore
    }
  },

  playBlocked(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(130, now);
      osc.frequency.exponentialRampToValueAtTime(75, now + 0.15);

      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.16);
    } catch {
      // Ignore
    }
  },

  playHint(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6

      notes.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.05);

        gain.gain.setValueAtTime(0.001, now + i * 0.05);
        gain.gain.linearRampToValueAtTime(0.12, now + i * 0.05 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.05 + 0.28);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + i * 0.05);
        osc.stop(now + i * 0.05 + 0.3);
      });
    } catch {
      // Ignore
    }
  },

  playUndo(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(520, now);
      osc.frequency.exponentialRampToValueAtTime(260, now + 0.12);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.13);
    } catch {
      // Ignore
    }
  },

  playWin(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const arpeggio = [440, 554.37, 659.25, 880, 1108.73]; // A major pentatonic sparkle

      arpeggio.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.07);

        gain.gain.setValueAtTime(0.001, now + idx * 0.07);
        gain.gain.linearRampToValueAtTime(0.15, now + idx * 0.07 + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.07 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.07);
        osc.stop(now + idx * 0.07 + 0.52);
      });
    } catch {
      // Ignore
    }
  },

  playLose(enabled: boolean) {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const notes = [293.66, 261.63, 220.0]; // D4, C4, A3

      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);

        gain.gain.setValueAtTime(0.12, now + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.36);
      });
    } catch {
      // Ignore
    }
  },

  triggerHaptic(type: 'light' | 'error' | 'success', enabled: boolean) {
    if (!enabled || typeof navigator === 'undefined' || !navigator.vibrate) return;
    try {
      if (type === 'light') {
        navigator.vibrate(15);
      } else if (type === 'error') {
        navigator.vibrate([30, 40, 30]);
      } else if (type === 'success') {
        navigator.vibrate([25, 45, 50]);
      }
    } catch {
      // Ignore
    }
  },

  setAmbientVolume(volume: number) {
    const ctx = getAudioContext();
    if (!ctx) return;
    const masterGain = getMasterAmbientGain(ctx);
    const target = Math.max(0, Math.min(1, volume));
    masterGain.gain.cancelScheduledValues(ctx.currentTime);
    masterGain.gain.linearRampToValueAtTime(target, ctx.currentTime + 0.15);
  },

  setAmbientSoundscape(soundscape: AmbientSoundscape, volume: number, enabled: boolean) {
    currentAmbientSoundscape = soundscape;
    const ctx = getAudioContext();
    if (!ctx) return;
    const masterGain = getMasterAmbientGain(ctx);

    if (!enabled || soundscape === 'none' || volume <= 0) {
      masterGain.gain.cancelScheduledValues(ctx.currentTime);
      masterGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.35);
      setTimeout(() => {
        if (currentAmbientSoundscape === 'none' || !enabled) {
          stopCurrentAmbient();
        }
      }, 400);
      return;
    }

    stopCurrentAmbient();

    const now = ctx.currentTime;
    const targetVol = Math.max(0, Math.min(1, volume));
    masterGain.gain.cancelScheduledValues(now);
    masterGain.gain.setValueAtTime(0, now);
    masterGain.gain.linearRampToValueAtTime(targetVol, now + 0.8);

    const pinkNoise = createPinkNoiseBuffer(ctx);
    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = pinkNoise;
    noiseSource.loop = true;

    const sources: (AudioNode & { stop?: () => void })[] = [noiseSource];
    const intervals: number[] = [];

    if (soundscape === 'forest') {
      // Wind through trees (lowpass modulated pink noise)
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(420, now);
      filter.Q.setValueAtTime(1.2, now);

      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.setValueAtTime(0.08, now);
      lfoGain.gain.setValueAtTime(140, now);
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start(now);
      sources.push(lfo);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.35, now);

      noiseSource.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(masterGain);

      // Random gentle bird chirps / breeze chimes
      const birdInterval = window.setInterval(() => {
        if (Math.random() < 0.6) {
          try {
            const birdNow = ctx.currentTime;
            const chirpOsc = ctx.createOscillator();
            const chirpGain = ctx.createGain();
            const baseFreq = 1800 + Math.random() * 800;

            chirpOsc.type = 'sine';
            chirpOsc.frequency.setValueAtTime(baseFreq, birdNow);
            chirpOsc.frequency.exponentialRampToValueAtTime(baseFreq * 1.3, birdNow + 0.08);
            chirpOsc.frequency.exponentialRampToValueAtTime(baseFreq * 0.9, birdNow + 0.16);

            chirpGain.gain.setValueAtTime(0.0001, birdNow);
            chirpGain.gain.linearRampToValueAtTime(0.05, birdNow + 0.03);
            chirpGain.gain.exponentialRampToValueAtTime(0.0001, birdNow + 0.22);

            chirpOsc.connect(chirpGain);
            chirpGain.connect(masterGain);

            chirpOsc.start(birdNow);
            chirpOsc.stop(birdNow + 0.25);
          } catch {
            // Ignore
          }
        }
      }, 4500);
      intervals.push(birdInterval);

    } else if (soundscape === 'ocean') {
      // Rolling ocean waves (resonant lowpass swept by smooth wave LFO)
      const waveFilter = ctx.createBiquadFilter();
      waveFilter.type = 'lowpass';
      waveFilter.frequency.setValueAtTime(260, now);
      waveFilter.Q.setValueAtTime(2.2, now);

      const waveLfo = ctx.createOscillator();
      const waveLfoGain = ctx.createGain();
      waveLfo.type = 'sine';
      waveLfo.frequency.setValueAtTime(0.1, now); // ~10 second wave cycle
      waveLfoGain.gain.setValueAtTime(220, now);
      waveLfo.connect(waveLfoGain);
      waveLfoGain.connect(waveFilter.frequency);
      waveLfo.start(now);
      sources.push(waveLfo);

      const waveGain = ctx.createGain();
      waveGain.gain.setValueAtTime(0.38, now);

      // Secondary foam layer
      const foamFilter = ctx.createBiquadFilter();
      foamFilter.type = 'bandpass';
      foamFilter.frequency.setValueAtTime(1400, now);
      foamFilter.Q.setValueAtTime(0.8, now);
      const foamGain = ctx.createGain();
      foamGain.gain.setValueAtTime(0.05, now);

      noiseSource.connect(waveFilter);
      waveFilter.connect(waveGain);
      waveGain.connect(masterGain);

      noiseSource.connect(foamFilter);
      foamFilter.connect(foamGain);
      foamGain.connect(masterGain);

    } else if (soundscape === 'city') {
      // Serene warm city rain + distant gentle night hum
      const rainFilter = ctx.createBiquadFilter();
      rainFilter.type = 'bandpass';
      rainFilter.frequency.setValueAtTime(1100, now);
      rainFilter.Q.setValueAtTime(0.7, now);

      const rainGain = ctx.createGain();
      rainGain.gain.setValueAtTime(0.28, now);

      noiseSource.connect(rainFilter);
      rainFilter.connect(rainGain);
      rainGain.connect(masterGain);

      // Cozy distant drone
      const droneOsc1 = ctx.createOscillator();
      droneOsc1.type = 'sine';
      droneOsc1.frequency.setValueAtTime(65.4, now); // C2

      const droneOsc2 = ctx.createOscillator();
      droneOsc2.type = 'sine';
      droneOsc2.frequency.setValueAtTime(98.0, now); // G2

      const droneGain = ctx.createGain();
      droneGain.gain.setValueAtTime(0.07, now);

      droneOsc1.connect(droneGain);
      droneOsc2.connect(droneGain);
      droneGain.connect(masterGain);

      droneOsc1.start(now);
      droneOsc2.start(now);
      sources.push(droneOsc1, droneOsc2);
    }

    noiseSource.start(now);
    activeAmbientNodes = { sources, intervals };
  },
};
