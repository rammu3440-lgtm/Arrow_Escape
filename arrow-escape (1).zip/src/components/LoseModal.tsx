import React from 'react';
import { RotateCcw, HeartHandshake, Grid, AlertCircle, Coins, Film } from 'lucide-react';
import { ECONOMY_CONFIG } from '../game/economy';

interface LoseModalProps {
  isOpen: boolean;
  coins: number;
  onRestart: () => void;
  onReviveCoins: () => void;
  onReviveAd: () => void;
  onLevelSelect: () => void;
}

export const LoseModal: React.FC<LoseModalProps> = ({
  isOpen,
  coins,
  onRestart,
  onReviveCoins,
  onReviveAd,
  onLevelSelect,
}) => {
  if (!isOpen) return null;

  const canAffordCoinRevive = coins >= ECONOMY_CONFIG.SPEND_REVIVE_PRICE;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col items-center text-center">
        {/* Heartbreak Icon */}
        <div className="w-16 h-16 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-500 flex items-center justify-center mb-3">
          <AlertCircle className="w-8 h-8" />
        </div>

        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
          No Lives Left
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs leading-relaxed">
          The path was blocked. Use a revive to keep your current puzzle progress!
        </p>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2 mt-5">
          {/* Coin Revive */}
          <button
            onClick={onReviveCoins}
            disabled={!canAffordCoinRevive}
            className={`w-full py-3 px-4 rounded-2xl font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-[0.98] ${
              canAffordCoinRevive
                ? 'bg-amber-500 hover:bg-amber-600 text-white'
                : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'
            }`}
          >
            <Coins className="w-4 h-4 fill-white" />
            <span>Revive (+2 Lives) · {ECONOMY_CONFIG.SPEND_REVIVE_PRICE} Coins</span>
          </button>

          {/* Ad Revive */}
          <button
            onClick={onReviveAd}
            className="w-full py-3 px-4 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-[0.98]"
          >
            <Film className="w-4 h-4" />
            <span>Revive Free (+2 Lives) · Watch 3s Ad</span>
          </button>

          <button
            onClick={onRestart}
            className="w-full py-2.5 px-4 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors mt-1"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restart Level</span>
          </button>

          <button
            onClick={onLevelSelect}
            className="w-full py-2 px-4 rounded-2xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Select Different Level</span>
          </button>
        </div>
      </div>
    </div>
  );
};
