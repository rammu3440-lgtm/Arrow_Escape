import React, { useState, useEffect } from 'react';
import { Sparkles, Trophy, Lightbulb } from 'lucide-react';
import { LevelConfig } from '../game/types';

interface LevelTransitionLoaderProps {
  levelConfig: LevelConfig;
  isVisible: boolean;
  onFinish: () => void;
}

const TIPS = [
  'Look for arrows pointing directly toward an open edge first.',
  'Snake arrows follow their curved track out through the head.',
  'Strategic hints prioritize the arrow that unblocks the most others.',
  'Reversing an accidental tap with Undo preserves your lives.',
  'Every 10th level is a Boss Challenge with greater grid complexity.',
];

export const LevelTransitionLoader: React.FC<LevelTransitionLoaderProps> = ({
  levelConfig,
  isVisible,
  onFinish,
}) => {
  const [tipIndex, setTipIndex] = useState(0);

  useEffect(() => {
    if (isVisible) {
      setTipIndex(Math.floor(Math.random() * TIPS.length));
      const timer = setTimeout(() => {
        onFinish();
      }, 420);
      return () => clearTimeout(timer);
    }
  }, [isVisible, onFinish]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center p-6 bg-slate-900/40 backdrop-blur-xs animate-in fade-in duration-150 select-none pointer-events-none">
      <div className="flex flex-col items-center text-center p-6 rounded-3xl bg-white/90 dark:bg-slate-900/90 shadow-2xl border border-slate-200/60 dark:border-slate-800/60 max-w-xs animate-in zoom-in-95 duration-200">
        <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-500 flex items-center justify-center mb-2">
          {levelConfig.isBoss ? (
            <Trophy className="w-6 h-6 text-amber-500" />
          ) : (
            <Sparkles className="w-6 h-6" />
          )}
        </div>

        <h3 className="text-xl font-extrabold text-slate-900 dark:text-slate-50">
          {levelConfig.title || `Level ${levelConfig.levelNumber}`}
        </h3>
        <span className="text-xs font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mt-0.5">
          {levelConfig.width}×{levelConfig.height} Grid · {levelConfig.arrowCount} Arrows
        </span>

        {/* Tip */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-start gap-2 text-left">
          <Lightbulb className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-tight">
            {TIPS[tipIndex]}
          </p>
        </div>
      </div>
    </div>
  );
};
