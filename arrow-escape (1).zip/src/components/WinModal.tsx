import React, { useEffect } from 'react';
import { Star, RotateCcw, ArrowRight, Grid, Award, Coins, Film, Check } from 'lucide-react';
import { DailyCountdownBadge } from './DailyCountdown';

interface WinModalProps {
  isOpen: boolean;
  stars: number; // 1, 2, 3
  timeSeconds: number;
  moveCount: number;
  coinsEarned?: number;
  hasDoubledCoins?: boolean;
  onDoubleCoinsWithAd?: () => void;
  isBoss?: boolean;
  isDaily?: boolean;
  levelTitle?: string;
  hasNextLevel: boolean;
  onNextLevel: () => void;
  onReplay: () => void;
  onLevelSelect: () => void;
}

export const WinModal: React.FC<WinModalProps> = ({
  isOpen,
  stars,
  timeSeconds,
  moveCount,
  coinsEarned = 0,
  hasDoubledCoins = false,
  onDoubleCoinsWithAd,
  isBoss,
  isDaily,
  levelTitle,
  hasNextLevel,
  onNextLevel,
  onReplay,
  onLevelSelect,
}) => {
  useEffect(() => {
    // Escape key closes/advances
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        if (hasNextLevel) onNextLevel();
        else onReplay();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, hasNextLevel, onNextLevel, onReplay]);

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col items-center text-center">
        {/* Header Icon */}
        <div className="w-16 h-16 rounded-2xl bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center mb-3">
          <Award className="w-8 h-8" />
        </div>

        <h2 className="text-2xl font-bold text-slate-900 dark:text-slate-50">
          {isBoss ? 'Boss Defeated!' : 'Level Cleared!'}
        </h2>
        <p className="text-xs font-medium text-indigo-600 dark:text-indigo-400 mt-0.5">
          {levelTitle || 'Board cleared with serene precision'}
        </p>

        {/* Star Rating Display */}
        <div className="flex items-center justify-center gap-2 my-5">
          {[1, 2, 3].map((starIdx) => {
            const isEarned = starIdx <= stars;
            return (
              <div
                key={starIdx}
                className="transform transition-transform duration-300"
                style={{
                  transitionDelay: `${starIdx * 120}ms`,
                }}
              >
                <Star
                  className={`w-9 h-9 ${
                    isEarned
                      ? 'fill-amber-400 text-amber-500 scale-105 drop-shadow-sm'
                      : 'fill-slate-100 text-slate-300 dark:fill-slate-800 dark:text-slate-700'
                  }`}
                />
              </div>
            );
          })}
        </div>

        {/* Stats Grid */}
        <div className="w-full grid grid-cols-3 gap-2 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl mb-4 text-xs">
          <div>
            <div className="text-slate-400 dark:text-slate-500 font-medium">Time Taken</div>
            <div className="text-base font-bold text-slate-800 dark:text-slate-200 tabular-nums">
              {formatTime(timeSeconds)}
            </div>
          </div>
          <div>
            <div className="text-slate-400 dark:text-slate-500 font-medium">Freed</div>
            <div className="text-base font-bold text-slate-800 dark:text-slate-200 tabular-nums">
              {moveCount}
            </div>
          </div>
          <div>
            <div className="text-slate-400 dark:text-slate-500 font-medium">Earned</div>
            <div className="text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums flex items-center justify-center gap-1">
              <Coins className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
              <span>+{coinsEarned}</span>
            </div>
          </div>
        </div>

        {/* 2x Double Reward with Ad Button */}
        {coinsEarned > 0 && onDoubleCoinsWithAd && !hasDoubledCoins && (
          <button
            onClick={onDoubleCoinsWithAd}
            className="w-full mb-3 py-2.5 px-3 rounded-2xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-950/60 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-100 font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-transform active:scale-95"
          >
            <Film className="w-3.5 h-3.5 text-amber-600" />
            <span>Double Rewards (+{coinsEarned} 🪙 with 3s Ad)</span>
          </button>
        )}

        {hasDoubledCoins && (
          <div className="w-full mb-3 py-1.5 px-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 text-xs font-semibold flex items-center justify-center gap-1.5">
            <Check className="w-3.5 h-3.5" />
            <span>Reward Doubled!</span>
          </div>
        )}

        {/* Daily Mode Countdown Callout */}
        {isDaily && (
          <div className="w-full mb-4">
            <DailyCountdownBadge />
          </div>
        )}

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          {hasNextLevel && (
            <button
              onClick={onNextLevel}
              className="w-full py-3.5 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-semibold text-sm flex items-center justify-center gap-2 shadow-sm transition-transform active:scale-[0.98]"
            >
              <span>Next Level</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}

          <div className="flex items-center gap-2 w-full">
            <button
              onClick={onReplay}
              className="flex-1 py-3 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Replay</span>
            </button>
            <button
              onClick={onLevelSelect}
              className="flex-1 py-3 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-medium text-xs flex items-center justify-center gap-1.5 transition-colors"
            >
              <Grid className="w-3.5 h-3.5" />
              <span>All Levels</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
