import React, { useState, useEffect } from 'react';
import { Clock, Sparkles } from 'lucide-react';

export function getSecondsUntilNextDaily(): number {
  const now = new Date();
  const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 0);
  const diffMs = nextMidnight.getTime() - now.getTime();
  return Math.max(0, Math.floor(diffMs / 1000));
}

export function useDailyCountdown() {
  const [secondsRemaining, setSecondsRemaining] = useState<number>(getSecondsUntilNextDaily);

  useEffect(() => {
    // Initial sync
    setSecondsRemaining(getSecondsUntilNextDaily());

    const interval = setInterval(() => {
      setSecondsRemaining(getSecondsUntilNextDaily());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const hours = Math.floor(secondsRemaining / 3600);
  const minutes = Math.floor((secondsRemaining % 3600) / 60);
  const seconds = secondsRemaining % 60;

  // Percentage of the 24-hour day that has elapsed
  const totalDaySeconds = 86400;
  const elapsedDaySeconds = totalDaySeconds - secondsRemaining;
  const progressPercent = Math.min(100, Math.max(0, (elapsedDaySeconds / totalDaySeconds) * 100));

  const pad = (n: number) => n.toString().padStart(2, '0');

  return {
    hours,
    minutes,
    seconds,
    padHours: pad(hours),
    padMinutes: pad(minutes),
    padSeconds: pad(seconds),
    totalSeconds: secondsRemaining,
    progressPercent,
  };
}

interface DailyCountdownBadgeProps {
  compact?: boolean;
  className?: string;
}

export const DailyCountdownBadge: React.FC<DailyCountdownBadgeProps> = ({ compact = false, className = '' }) => {
  const { padHours, padMinutes, padSeconds } = useDailyCountdown();

  if (compact) {
    return (
      <div
        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200/60 dark:border-indigo-800/60 text-indigo-700 dark:text-indigo-300 text-[11px] font-medium tabular-nums ${className}`}
      >
        <div className="relative flex items-center justify-center">
          <Clock className="w-3 h-3 text-indigo-600 dark:text-indigo-400 animate-spin [animation-duration:12s]" />
          <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-indigo-500 animate-ping opacity-75" />
        </div>
        <span>Next:</span>
        <span className="font-semibold tracking-tight">
          {padHours}:{padMinutes}:
          <span className="inline-block transition-transform duration-150 motion-safe:animate-pulse">
            {padSeconds}
          </span>
        </span>
      </div>
    );
  }

  return (
    <div
      className={`flex items-center gap-2 p-2.5 rounded-xl bg-indigo-50/80 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 ${className}`}
    >
      {/* Animated Glowing Clock Icon */}
      <div className="relative w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs overflow-hidden shrink-0">
        <Clock className="w-4 h-4 animate-spin [animation-duration:14s]" />
        {/* Soft breathing light ring */}
        <div className="absolute inset-0 bg-white/20 rounded-lg animate-pulse" />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between text-[11px] text-indigo-900/70 dark:text-indigo-300 font-medium">
          <span className="flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-indigo-500" />
            <span>Next Daily Puzzle</span>
          </span>
          <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Resets at 00:00</span>
        </div>

        {/* Animated Digits Display */}
        <div className="flex items-baseline gap-1 mt-0.5 font-bold tabular-nums text-indigo-950 dark:text-indigo-100">
          <div className="flex items-center gap-0.5 text-sm">
            <span className="px-1 py-0.5 bg-white dark:bg-slate-900 rounded-md border border-indigo-100 dark:border-indigo-950">
              {padHours}
            </span>
            <span className="text-indigo-400 dark:text-indigo-500 font-normal animate-pulse">:</span>
            <span className="px-1 py-0.5 bg-white dark:bg-slate-900 rounded-md border border-indigo-100 dark:border-indigo-950">
              {padMinutes}
            </span>
            <span className="text-indigo-400 dark:text-indigo-500 font-normal animate-pulse">:</span>
            <span className="px-1 py-0.5 bg-white dark:bg-slate-900 rounded-md border border-indigo-100 dark:border-indigo-950 text-indigo-600 dark:text-indigo-400">
              {padSeconds}
            </span>
          </div>
          <span className="text-[10px] text-indigo-600/70 dark:text-indigo-400/80 font-medium ml-1">
            remaining
          </span>
        </div>
      </div>
    </div>
  );
};
