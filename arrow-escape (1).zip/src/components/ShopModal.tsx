import React, { useState } from 'react';
import {
  X,
  Coins,
  Sparkles,
  Palette,
  Check,
  Lock,
  Layers,
  Zap,
  ShoppingBag,
  Film,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import {
  EconomyState,
  ShopItem,
  PaletteName,
  SkinName,
} from '../game/types';
import {
  SHOP_CATALOG,
  purchaseShopItem,
  equipItem,
} from '../game/economy';
import { THEME_PALETTES, ArrowColorSpec } from '../game/palettes';
import { soundManager } from '../game/sound';

interface ShopModalProps {
  isOpen: boolean;
  onClose: () => void;
  economy: EconomyState;
  onUpdateEconomy: (newEconomy: EconomyState) => void;
  onTriggerRewardedAd: (rewardAmount: number, onReward: () => void) => void;
  soundEnabled: boolean;
  initialTab?: 'BOOSTER' | 'THEME' | 'SKIN' | 'COIN_PACK';
}

export const ShopModal: React.FC<ShopModalProps> = ({
  isOpen,
  onClose,
  economy,
  onUpdateEconomy,
  onTriggerRewardedAd,
  soundEnabled,
  initialTab = 'BOOSTER',
}) => {
  const [activeTab, setActiveTab] = useState<'BOOSTER' | 'THEME' | 'SKIN' | 'COIN_PACK'>(initialTab);
  const [previewTheme, setPreviewTheme] = useState<PaletteName>(economy.equippedTheme);
  const [previewSkin, setPreviewSkin] = useState<SkinName>(economy.equippedSkin);
  const [confirmItem, setConfirmItem] = useState<ShopItem | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<{ text: string; error?: boolean } | null>(null);

  if (!isOpen) return null;

  const showFeedback = (text: string, error: boolean = false) => {
    setFeedbackMsg({ text, error });
    setTimeout(() => setFeedbackMsg(null), 3000);
  };

  const handleBuy = (item: ShopItem) => {
    // If expensive item (> 300 coins), show confirmation
    if (item.currency === 'COINS' && item.price >= 300 && !confirmItem) {
      setConfirmItem(item);
      return;
    }

    if (item.currency === 'AD') {
      onTriggerRewardedAd(item.amount || 50, () => {
        const res = purchaseShopItem(economy, item);
        if (res.success) {
          onUpdateEconomy(res.state);
          soundManager.playWin(soundEnabled);
          showFeedback(`+${item.amount || 50} Coins added!`);
        }
      });
      return;
    }

    const res = purchaseShopItem(economy, item);
    setConfirmItem(null);

    if (res.success) {
      onUpdateEconomy(res.state);
      soundManager.playWin(soundEnabled);
      showFeedback(res.message || 'Purchased successfully!');
    } else {
      soundManager.playBlocked(soundEnabled);
      showFeedback(res.message || 'Insufficient coins!', true);
    }
  };

  const handleEquip = (type: 'THEME' | 'SKIN', id: string) => {
    const updated = equipItem(economy, type, id);
    onUpdateEconomy(updated);
    if (type === 'THEME') setPreviewTheme(id as PaletteName);
    if (type === 'SKIN') setPreviewSkin(id as SkinName);
    soundManager.playTap(soundEnabled);
    showFeedback(`Equipped ${id}!`);
  };

  const currentTabItems = SHOP_CATALOG.filter((i) => i.type === activeTab);

  // Theme preview colors
  const activePaletteColors = (THEME_PALETTES[previewTheme] || THEME_PALETTES.pastel).light;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col max-h-[88vh] overflow-hidden">
        {/* Header: Title & Coin Balance */}
        <div className="p-5 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-50">Shop</h2>
              <div className="text-xs text-slate-500">Upgrade tools and visual style</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Animated Coin Badge */}
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 text-amber-900 dark:text-amber-100 font-bold text-sm tabular-nums">
              <Coins className="w-4 h-4 fill-amber-400 text-amber-500 animate-bounce [animation-duration:3s]" />
              <span>{economy.coins}</span>
            </div>
            <button
              onClick={onClose}
              className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 pt-3 pb-2 flex gap-1.5 border-b border-slate-100 dark:border-slate-800 overflow-x-auto no-scrollbar">
          {(
            [
              { id: 'BOOSTER', label: 'Boosters' },
              { id: 'THEME', label: 'Themes' },
              { id: 'SKIN', label: 'Skins' },
              { id: 'COIN_PACK', label: 'Get Coins' },
            ] as const
          ).map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors ${
                activeTab === t.id
                  ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Feedback Alert Toast */}
        {feedbackMsg && (
          <div
            className={`mx-5 mt-3 py-2 px-3 rounded-xl text-xs font-medium text-center animate-in fade-in duration-150 ${
              feedbackMsg.error
                ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/50 dark:text-rose-300'
                : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300'
            }`}
          >
            {feedbackMsg.text}
          </div>
        )}

        {/* Content Body */}
        <div className="p-5 overflow-y-auto flex-1 flex flex-col gap-4">
          {/* Live Mini Preview for Themes & Skins */}
          {(activeTab === 'THEME' || activeTab === 'SKIN') && (
            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 flex flex-col items-center">
              <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Live Arrow & Theme Preview</span>
              </div>

              {/* Mini Interactive Preview Box */}
              <div
                className="w-full max-w-xs h-28 rounded-2xl flex items-center justify-around p-3 border shadow-inner relative overflow-hidden transition-all duration-300"
                style={{
                  backgroundColor: activePaletteColors.bgBoard,
                  borderColor: activePaletteColors.gridLine,
                }}
              >
                {/* 3 preview arrows */}
                {activePaletteColors.arrowPalette.slice(0, 3).map((c: ArrowColorSpec, i: number) => (
                  <div
                    key={i}
                    className="flex flex-col items-center justify-center p-2 rounded-xl transition-transform hover:scale-110"
                    style={{
                      boxShadow: previewSkin === 'neon' ? `0 0 14px ${c.head}` : undefined,
                    }}
                  >
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center relative shadow-sm"
                      style={{
                        backgroundColor: c.fill,
                        border: `2px solid ${c.stroke}`,
                      }}
                    >
                      <ArrowRight
                        className="w-5 h-5 transition-transform"
                        style={{
                          color: c.head,
                          transform: `rotate(${i * 90}deg)`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Catalog Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {currentTabItems.map((item) => {
              const isOwned =
                item.type === 'THEME'
                  ? economy.ownedThemes.includes(item.targetId || '')
                  : item.type === 'SKIN'
                  ? economy.ownedSkins.includes(item.targetId || '')
                  : false;

              const isEquipped =
                (item.type === 'THEME' && economy.equippedTheme === item.targetId) ||
                (item.type === 'SKIN' && economy.equippedSkin === item.targetId);

              const canAfford = item.currency === 'COINS' ? economy.coins >= item.price : true;

              return (
                <div
                  key={item.id}
                  onClick={() => {
                    if (item.type === 'THEME' && item.targetId) {
                      setPreviewTheme(item.targetId as PaletteName);
                    } else if (item.type === 'SKIN' && item.targetId) {
                      setPreviewSkin(item.targetId as SkinName);
                    }
                  }}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                    isEquipped
                      ? 'border-emerald-500 bg-emerald-50/40 dark:bg-emerald-950/20'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-850 hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-1 mb-1">
                      <span className="font-bold text-sm text-slate-900 dark:text-slate-100">
                        {item.name}
                      </span>
                      {isEquipped ? (
                        <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                          <Check className="w-3.5 h-3.5" /> Equipped
                        </span>
                      ) : isOwned ? (
                        <span className="text-[11px] font-medium text-slate-500">Owned</span>
                      ) : (
                        <span className="text-xs font-bold text-amber-600 dark:text-amber-400 tabular-nums flex items-center gap-1">
                          {item.currency === 'COINS' ? (
                            <>
                              <Coins className="w-3 h-3 fill-amber-400 text-amber-500" />
                              {item.price}
                            </>
                          ) : item.currency === 'USD' ? (
                            `$${item.price}`
                          ) : (
                            <span className="flex items-center gap-1 text-indigo-600">
                              <Film className="w-3 h-3" /> Free Ad
                            </span>
                          )}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 leading-snug">
                      {item.description}
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                    {isEquipped ? (
                      <div className="w-full py-1.5 text-center text-xs font-medium text-emerald-600">
                        Active In Game
                      </div>
                    ) : isOwned ? (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEquip(item.type as 'THEME' | 'SKIN', item.targetId || '');
                        }}
                        className="w-full py-1.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-semibold transition-colors"
                      >
                        Equip
                      </button>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleBuy(item);
                        }}
                        className={`w-full py-2 px-3 rounded-xl font-semibold text-xs flex items-center justify-center gap-1.5 transition-transform active:scale-95 ${
                          item.currency === 'AD'
                            ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs'
                            : canAfford
                            ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs'
                            : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-600 cursor-not-allowed'
                        }`}
                      >
                        {item.currency === 'AD' ? (
                          <>
                            <Film className="w-3.5 h-3.5" />
                            <span>Watch 3s Ad (+50 🪙)</span>
                          </>
                        ) : item.currency === 'USD' ? (
                          <span>Buy for ${item.price}</span>
                        ) : canAfford ? (
                          <>
                            <Coins className="w-3.5 h-3.5 fill-white text-white" />
                            <span>Buy for {item.price}</span>
                          </>
                        ) : (
                          <>
                            <Lock className="w-3.5 h-3.5" />
                            <span>Need {item.price} Coins</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Confirmation Dialog for High Value Items */}
          {confirmItem && (
            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-center animate-in fade-in duration-200">
              <ShieldAlert className="w-6 h-6 text-amber-600 mx-auto mb-1" />
              <div className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                Confirm Purchase?
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">
                Spend <strong>{confirmItem.price} coins</strong> for{' '}
                <strong>{confirmItem.name}</strong>?
              </p>
              <div className="flex gap-2 justify-center mt-3">
                <button
                  onClick={() => handleBuy(confirmItem)}
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold"
                >
                  Confirm & Buy
                </button>
                <button
                  onClick={() => setConfirmItem(null)}
                  className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
