import React from 'react';
import {
  Heart,
  RotateCcw,
  Lightbulb,
  RotateCw,
  Grid,
  Settings as SettingsIcon,
  HelpCircle,
  Trophy,
  Coins,
  Gift,
  ShoppingBag,
  Plus,
} from 'lucide-react';
import { GameMode, LevelConfig } from '../game/types';
import { DailyCountdownBadge } from './DailyCountdown';
import { PlayGamesLoginButton } from './PlayGamesLoginButton';
import { InstallAppButton } from './InstallAppButton';
import { AuthState, PlayerProfile } from '../platform/types';

interface HUDProps {
  levelConfig: LevelConfig;
  gameMode: GameMode;
  lives: number;
  maxLives: number;
  remainingArrows: number;
  totalArrows: number;
  hintsRemaining: number;
  undoRemaining: number;
  canUndo: boolean;
  coins: number;
  hasUnclaimedDailyReward: boolean;
  playGamesAuth?: {
    authState: AuthState;
    player: PlayerProfile | null;
    signIn: () => Promise<boolean>;
    isDismissed: boolean;
  };
  onUndo: () => void;
  onHint: () => void;
  onRestart: () => void;
  onOpenLevelSelect: () => void;
  onOpenSettings: () => void;
  onOpenHelp: () => void;
  onOpenShop: () => void;
  onOpenDailyRewards: () => void;
  onOpenInstallApk?: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  levelConfig,
  gameMode,
  lives,
  maxLives,
  remainingArrows,
  totalArrows,
  hintsRemaining,
  undoRemaining,
  canUndo,
  coins,
  hasUnclaimedDailyReward,
  playGamesAuth,
  onUndo,
  onHint,
  onRestart,
  onOpenLevelSelect,
  onOpenSettings,
  onOpenHelp,
  onOpenShop,
  onOpenDailyRewards,
  onOpenInstallApk,
}) => {
  return (
    <header className="w-full max-w-xl mx-auto flex flex-col gap-2 px-4 pt-3 pb-1">
      {/* Top Bar: Title & Primary Controls */}
      <div className="flex items-center justify-between">
        {/* Left: Level Select & Level Name */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenLevelSelect}
            className="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors"
            title="Level Select"
            aria-label="Level Select"
          >
            <Grid className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              <span>{gameMode === 'CAMPAIGN' ? 'Campaign' : gameMode === 'DAILY' ? 'Daily' : 'Endless'}</span>
              {gameMode === 'DAILY' && (
                <>
                  <span aria-hidden="true">·</span>
                  <DailyCountdownBadge compact />
                </>
              )}
              {levelConfig.isBoss && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-600 dark:text-amber-400 flex items-center gap-1 font-bold">
                    <Trophy className="w-3.5 h-3.5" /> Boss
                  </span>
                </>
              )}
            </div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-slate-50 leading-tight">
              {levelConfig.title || `Level ${levelConfig.levelNumber}`}
            </h1>
          </div>
        </div>

        {/* Right: Coins, Daily Rewards, Shop, Settings */}
        <div className="flex items-center gap-1.5">
          {/* Play Games sign-in chip (only displayed when signed out) */}
          {playGamesAuth && playGamesAuth.authState !== 'SIGNED_IN' && !playGamesAuth.isDismissed && (
            <PlayGamesLoginButton
              authState={playGamesAuth.authState}
              player={playGamesAuth.player}
              onSignIn={playGamesAuth.signIn}
              variant="chip"
              className="inline-flex"
            />
          )}

          {/* Animated Coin Button */}
          <button
            onClick={onOpenShop}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 dark:hover:bg-amber-950/60 border border-amber-200/70 dark:border-amber-800/60 text-amber-900 dark:text-amber-100 font-bold text-xs tabular-nums shadow-xs transition-transform active:scale-95"
            title="Open Coin Shop"
          >
            <Coins className="w-3.5 h-3.5 fill-amber-400 text-amber-500" />
            <span>{coins}</span>
          </button>

          {/* Daily Reward Button with Notification Dot */}
          <button
            onClick={onOpenDailyRewards}
            className="w-9 h-9 rounded-xl flex items-center justify-center relative bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/40 dark:hover:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 transition-colors"
            title="Daily Rewards"
            aria-label="Daily Rewards"
          >
            <Gift className="w-4.5 h-4.5" />
            {hasUnclaimedDailyReward && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-rose-500 rounded-full ring-2 ring-white dark:ring-slate-900 animate-pulse" />
            )}
          </button>

          {/* Neon Pink Shop Button */}
          <button
            onClick={onOpenShop}
            className="h-9 px-2.5 rounded-xl flex items-center gap-1.5 bg-gradient-to-r from-pink-500 via-rose-500 to-fuchsia-500 hover:from-pink-400 hover:via-rose-400 hover:to-fuchsia-400 text-white font-bold text-xs shadow-md shadow-pink-500/40 hover:shadow-lg hover:shadow-pink-500/60 border border-pink-300/40 transition-all hover:scale-105 active:scale-95 relative overflow-hidden group"
            title="Open Shop"
            aria-label="Shop"
          >
            <ShoppingBag className="w-4 h-4 text-white drop-shadow-xs transition-transform group-hover:rotate-6" />
            <span className="tracking-wider uppercase text-[11px] font-extrabold drop-shadow-xs">
              Shop
            </span>
            {/* Subtle neon sheen accent */}
            <span className="absolute inset-0 bg-white/15 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
          </button>

          {/* Install APK / Native App Button */}
          {onOpenInstallApk && (
            <InstallAppButton
              variant="hud"
              onOpenModal={onOpenInstallApk}
            />
          )}

          <button
            onClick={onOpenSettings}
            className="w-9 h-9 rounded-xl flex items-center justify-center text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Settings"
            aria-label="Settings"
          >
            <SettingsIcon className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>

      {/* Middle Bar: Hearts and Board Progress */}
      <div className="flex items-center justify-between py-1 text-sm border-t border-slate-100 dark:border-slate-800/80">
        {/* Lives / Hearts */}
        <div className="flex items-center gap-1" aria-label={`Lives remaining: ${lives} of ${maxLives}`}>
          {Array.from({ length: maxLives }).map((_, idx) => (
            <Heart
              key={idx}
              className={`w-5 h-5 transition-transform duration-200 ${
                idx < lives
                  ? 'fill-rose-500 text-rose-500 scale-100'
                  : 'fill-slate-200 text-slate-300 dark:fill-slate-800 dark:text-slate-700 scale-90'
              }`}
            />
          ))}
        </div>

        {/* Arrow progress counter */}
        <div className="text-xs font-medium text-slate-500 dark:text-slate-400 tabular-nums">
          Remaining: <span className="text-slate-800 dark:text-slate-200 font-semibold">{remainingArrows}</span> / {totalArrows}
        </div>
      </div>
    </header>
  );
};

interface ActionBarProps {
  onUndo: () => void;
  onHint: () => void;
  onRestart: () => void;
  onOpenShopForBoosters?: () => void;
  undoRemaining: number;
  hintsRemaining: number;
  canUndo: boolean;
}

export const ActionBar: React.FC<ActionBarProps> = ({
  onUndo,
  onHint,
  onRestart,
  onOpenShopForBoosters,
  undoRemaining,
  hintsRemaining,
  canUndo,
}) => {
  return (
    <footer className="w-full max-w-sm mx-auto px-4 pb-4 pt-1 flex items-center justify-center gap-6">
      {/* Undo Button */}
      <button
        onClick={undoRemaining > 0 ? onUndo : onOpenShopForBoosters}
        disabled={undoRemaining === 0 && !canUndo && !onOpenShopForBoosters}
        className="flex flex-col items-center gap-1 group transition-all active:scale-95"
        title={undoRemaining > 0 ? 'Undo move' : 'Refill Undos in Shop'}
        aria-label="Undo move"
      >
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-white dark:bg-slate-800 shadow-sm border border-slate-200 dark:border-slate-700 group-hover:border-slate-300 dark:group-hover:border-slate-600 text-slate-700 dark:text-slate-200 relative">
          <RotateCcw className="w-5 h-5" />
          <span
            className={`absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full text-white text-[10px] font-bold flex items-center justify-center ${
              undoRemaining > 0 ? 'bg-slate-900 dark:bg-slate-100 dark:text-slate-900' : 'bg-amber-500'
            }`}
          >
            {undoRemaining > 0 ? undoRemaining : <Plus className="w-3 h-3" />}
          </span>
        </div>
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Undo</span>
      </button>

      {/* Restart Button */}
      <button
        onClick={onRestart}
        className="flex flex-col items-center gap-1 group transition-all active:scale-95"
        title="Restart level"
        aria-label="Restart level"
      >
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-white dark:bg-slate-800 shadow-sm border border-slate-200 dark:border-slate-700 group-hover:border-slate-300 dark:group-hover:border-slate-600 text-slate-700 dark:text-slate-200">
          <RotateCw className="w-5 h-5" />
        </div>
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Restart</span>
      </button>

      {/* Hint Button */}
      <button
        onClick={hintsRemaining > 0 ? onHint : onOpenShopForBoosters}
        className="flex flex-col items-center gap-1 group transition-all active:scale-95"
        title={hintsRemaining > 0 ? 'Show best safe arrow' : 'Refill Hints in Shop'}
        aria-label="Hint"
      >
        <div className="w-12 h-12 rounded-2xl flex items-center justify-center bg-amber-500 text-white shadow-sm shadow-amber-500/20 hover:bg-amber-600 relative">
          <Lightbulb className="w-5 h-5" />
          <span
            className={`absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full text-white text-[10px] font-bold flex items-center justify-center ${
              hintsRemaining > 0 ? 'bg-slate-900 dark:bg-slate-100 dark:text-slate-900' : 'bg-emerald-600'
            }`}
          >
            {hintsRemaining > 0 ? hintsRemaining : <Plus className="w-3 h-3" />}
          </span>
        </div>
        <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">Hint</span>
      </button>
    </footer>
  );
};
