import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PaletteName, SkinName } from '../game/types';
import { THEME_PALETTES, ThemeColors } from '../game/palettes';
import { soundManager } from '../game/sound';
import { AuthState, PlayerProfile } from '../platform/types';
import {
  ArrowRight,
  Sparkles,
  CheckCircle2,
  Loader2,
  Cloud,
  ShieldCheck,
  Gamepad2,
  User,
} from 'lucide-react';

export interface CinematicLoadingScreenProps {
  palette: PaletteName;
  skin?: SkinName;
  darkMode: boolean;
  reduceMotion: boolean;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onComplete: () => void;
  authState?: AuthState;
  player?: PlayerProfile | null;
  onSignIn?: () => Promise<boolean>;
}

interface DriftingArrow {
  x: number;
  y: number;
  direction: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
  colorIndex: number;
  scale: number;
  speed: number;
  delay: number;
  escaped: boolean;
  escapeProgress: number;
}

export const CinematicLoadingScreen: React.FC<CinematicLoadingScreenProps> = ({
  palette,
  darkMode,
  reduceMotion,
  soundEnabled,
  hapticsEnabled,
  onComplete,
  authState = 'SIGNED_OUT',
  player = null,
  onSignIn,
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | 0>(0);
  const [phase, setPhase] = useState<'ENTERING' | 'REVEAL' | 'READY' | 'EXITING'>('ENTERING');
  const [canSkip, setCanSkip] = useState(false);
  const [isSigningInLocal, setIsSigningInLocal] = useState(false);
  const [progressPercent, setProgressPercent] = useState(0);
  const hasTriggeredChimeRef = useRef(false);
  const hasCompletedRef = useRef(false);

  const isSignedIn = authState === 'SIGNED_IN';
  const isSigningIn = authState === 'SIGNING_IN' || isSigningInLocal;

  const theme: ThemeColors = (THEME_PALETTES[palette] || THEME_PALETTES.pastel)[
    darkMode ? 'dark' : 'light'
  ];

  // Smooth loading progress counter (0 -> 100%)
  useEffect(() => {
    const totalDuration = isSignedIn ? 1900 : 1500;
    const intervalMs = 25;
    const step = 100 / (totalDuration / intervalMs);

    const timer = setInterval(() => {
      setProgressPercent((prev) => {
        const next = Math.min(100, Math.round(prev + step));
        if (next >= 100) {
          clearInterval(timer);
        }
        return next;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isSignedIn]);

  // Handle completion sequence
  const handleExitGame = useCallback(() => {
    if (hasCompletedRef.current) return;
    hasCompletedRef.current = true;
    setPhase('EXITING');
    soundManager.playWhoosh(soundEnabled);
    setTimeout(() => {
      onComplete();
    }, 450);
  }, [soundEnabled, onComplete]);

  // When signed in (reopening the game or after sign-in), automatically complete into the game
  useEffect(() => {
    if (isSignedIn && progressPercent >= 100 && phase !== 'EXITING') {
      const exitTimer = setTimeout(() => {
        handleExitGame();
      }, 550);
      return () => clearTimeout(exitTimer);
    }
  }, [isSignedIn, progressPercent, phase, handleExitGame]);

  // Fast path for reduced motion
  useEffect(() => {
    if (reduceMotion) {
      setPhase('REVEAL');
      setCanSkip(true);
      if (isSignedIn) {
        const timer = setTimeout(() => {
          handleExitGame();
        }, 1100);
        return () => clearTimeout(timer);
      }
    }
  }, [reduceMotion, isSignedIn, handleExitGame]);

  // Canvas visual effects sequence
  useEffect(() => {
    if (reduceMotion) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;
    const startTime = performance.now();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const skipTimer = setTimeout(() => setCanSkip(true), 600);

    // Create 24 choreographed geometric arrows
    const arrowCount = 24;
    const arrows: DriftingArrow[] = [];
    const directions: ('UP' | 'DOWN' | 'LEFT' | 'RIGHT')[] = ['UP', 'DOWN', 'LEFT', 'RIGHT'];

    for (let i = 0; i < arrowCount; i++) {
      const seedAngle = (i / arrowCount) * Math.PI * 2;
      const seedRadius = 0.22 + (Math.sin(i * 1.9) * 0.5 + 0.5) * 0.62;
      const dir = directions[i % 4];

      arrows.push({
        x: 0.5 + Math.cos(seedAngle) * seedRadius * 0.44,
        y: 0.5 + Math.sin(seedAngle) * seedRadius * 0.44,
        direction: dir,
        colorIndex: i % theme.arrowPalette.length,
        scale: 0.72 + (i % 3) * 0.18,
        speed: 1.1 + (i % 4) * 0.35,
        delay: 200 + i * 45,
        escaped: false,
        escapeProgress: 0,
      });
    }

    const render = (now: number) => {
      if (!isRunning) return;

      const elapsed = now - startTime;
      const w = window.innerWidth;
      const h = window.innerHeight;

      if (canvas.width !== Math.round(w * dpr) || canvas.height !== Math.round(h * dpr)) {
        canvas.width = Math.round(w * dpr);
        canvas.height = Math.round(h * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, w, h);

      // Background Canvas Fill
      ctx.fillStyle = theme.bgBoard;
      ctx.fillRect(0, 0, w, h);

      // Radial Vignette
      const grad = ctx.createRadialGradient(
        w / 2,
        h / 2,
        Math.min(w, h) * 0.15,
        w / 2,
        h / 2,
        Math.max(w, h) * 0.7
      );
      grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
      grad.addColorStop(1, darkMode ? 'rgba(0, 0, 0, 0.5)' : 'rgba(15, 23, 42, 0.07)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Sound chime trigger
      if (elapsed >= 800 && !hasTriggeredChimeRef.current) {
        hasTriggeredChimeRef.current = true;
        setPhase('REVEAL');
        soundManager.playHint(soundEnabled);
        soundManager.triggerHaptic('light', hapticsEnabled);
      }

      // Draw Arrows
      const minDimension = Math.min(w, h);
      const baseArrowSize = minDimension * 0.052;

      arrows.forEach((arr) => {
        const arrowElapsed = Math.max(0, elapsed - arr.delay);
        if (arrowElapsed <= 0) return;

        let curX = arr.x * w;
        let curY = arr.y * h;

        // Intro slide
        const entryProgress = Math.min(1, arrowElapsed / 500);
        const entryEase = 1 - Math.pow(1 - entryProgress, 3);

        // Escape bloom phase when exiting
        const escapeStart = 1400 + arr.delay * 0.5;
        if (elapsed > escapeStart || phase === 'EXITING') {
          const escElapsed = Math.max(0, elapsed - escapeStart);
          arr.escapeProgress = Math.min(1, escElapsed / 500);
          const escEase = Math.pow(arr.escapeProgress, 2.2);

          const escapeDistance = minDimension * 1.35 * escEase;
          if (arr.direction === 'UP') curY -= escapeDistance;
          if (arr.direction === 'DOWN') curY += escapeDistance;
          if (arr.direction === 'LEFT') curX -= escapeDistance;
          if (arr.direction === 'RIGHT') curX += escapeDistance;
        }

        const colors = theme.arrowPalette[arr.colorIndex % theme.arrowPalette.length];
        const arrowSize = baseArrowSize * arr.scale * entryEase;
        const alpha = Math.max(0, entryEase - arr.escapeProgress * 1.15);

        ctx.save();
        ctx.translate(curX, curY);
        ctx.globalAlpha = alpha;

        let rotation = 0;
        if (arr.direction === 'UP') rotation = -Math.PI / 2;
        if (arr.direction === 'DOWN') rotation = Math.PI / 2;
        if (arr.direction === 'LEFT') rotation = Math.PI;
        if (arr.direction === 'RIGHT') rotation = 0;
        ctx.rotate(rotation);

        // Arrow capsule body
        ctx.fillStyle = colors.fill;
        ctx.strokeStyle = colors.stroke;
        ctx.lineWidth = 2.4;

        ctx.beginPath();
        ctx.roundRect(
          -arrowSize * 0.8,
          -arrowSize * 0.35,
          arrowSize * 1.2,
          arrowSize * 0.7,
          arrowSize * 0.35
        );
        ctx.fill();
        ctx.stroke();

        // Arrow head tip
        ctx.fillStyle = colors.head;
        ctx.beginPath();
        ctx.moveTo(arrowSize * 0.8, 0);
        ctx.lineTo(arrowSize * 0.2, -arrowSize * 0.45);
        ctx.lineTo(arrowSize * 0.35, 0);
        ctx.lineTo(arrowSize * 0.2, arrowSize * 0.45);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      });

      // Center Ambient Halo Glow
      if (elapsed >= 600) {
        const haloGrad = ctx.createRadialGradient(w / 2, h / 2, 5, w / 2, h / 2, 180);
        haloGrad.addColorStop(
          0,
          darkMode ? 'rgba(99, 102, 241, 0.2)' : 'rgba(99, 102, 241, 0.12)'
        );
        haloGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = haloGrad;
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 180, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      isRunning = false;
      clearTimeout(skipTimer);
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [theme, darkMode, reduceMotion, soundEnabled, hapticsEnabled, phase]);

  const handlePlayGamesSignIn = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!onSignIn || isSigningIn) return;

    setIsSigningInLocal(true);
    try {
      const success = await onSignIn();
      if (success) {
        soundManager.playHint(soundEnabled);
        soundManager.triggerHaptic('success', hapticsEnabled);
      }
    } catch {
      // Ignored
    } finally {
      setIsSigningInLocal(false);
    }
  };

  const getLoadingSubtitle = () => {
    if (isSignedIn) {
      if (progressPercent < 45) return 'Loading puzzle assets…';
      if (progressPercent < 85) return 'Syncing Play Games cloud save…';
      return 'Cloud verified. Welcome back!';
    }
    if (progressPercent < 45) return 'Loading puzzle assets…';
    if (progressPercent < 85) return 'Checking save status…';
    return 'Ready to escape!';
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between p-6 select-none overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Top Bar / Skip Button */}
      <div className="w-full h-10 flex justify-end items-center relative z-10">
        {canSkip && (
          <button
            type="button"
            onClick={handleExitGame}
            className="text-xs font-semibold px-3 py-1.5 rounded-full bg-white/70 dark:bg-slate-900/70 backdrop-blur-md text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 border border-slate-200/50 dark:border-slate-800/50 transition-all cursor-pointer active:scale-95 shadow-xs"
          >
            Skip
          </button>
        )}
      </div>

      {/* Center Wordmark & Status Area */}
      <div
        className={`relative z-10 flex flex-col items-center text-center max-w-sm w-full transition-all duration-500 ${
          phase === 'ENTERING'
            ? 'opacity-0 translate-y-4 scale-95'
            : phase === 'EXITING'
            ? 'opacity-0 -translate-y-3 scale-102'
            : 'opacity-100 translate-y-0 scale-100'
        }`}
      >
        {/* Animated Brand Emblem & App Logo */}
        <div className="relative mb-4 group">
          <div className="absolute -inset-1 rounded-3xl bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 opacity-40 blur-md group-hover:opacity-70 transition duration-500 animate-pulse" />
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 rounded-2xl sm:rounded-3xl bg-white/95 dark:bg-slate-900/95 backdrop-blur-md shadow-2xl border border-white/60 dark:border-slate-700/70 p-1 flex items-center justify-center transition-transform hover:scale-105 overflow-hidden">
            <img
              src="/src/assets/images/app_logo_1791465730824.jpg"
              alt="Arrow Escape Logo"
              referrerPolicy="no-referrer"
              className="w-full h-full rounded-xl sm:rounded-2xl object-cover shadow-inner"
              onError={(e) => {
                const img = e.currentTarget as HTMLImageElement;
                if (!img.src.endsWith('/file_00000000c56081f5b107ea24543b58e5.png')) {
                  img.src = '/file_00000000c56081f5b107ea24543b58e5.png';
                }
              }}
            />
          </div>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900 dark:text-slate-50 drop-shadow-xs">
          Arrow Escape
        </h1>
        <p className="text-xs sm:text-sm font-medium text-slate-500 dark:text-slate-400 mt-1">
          A calm, minimalist logic puzzle
        </p>

        {/* Dynamic Progress Bar */}
        <div className="w-48 flex flex-col items-center mt-6">
          <div className="w-full h-1.5 bg-slate-200/80 dark:bg-slate-800/80 rounded-full overflow-hidden shadow-inner p-0.5">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-500 rounded-full transition-all duration-150 ease-out shadow-xs"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <div className="flex items-center justify-between w-full mt-1.5 px-0.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
            <span className="truncate max-w-[140px] text-left">{getLoadingSubtitle()}</span>
            <span className="tabular-nums">{progressPercent}%</span>
          </div>
        </div>

        {/* ------------------------------------------------------------------ */}
        {/* Play Games Services Authentication Section:                        */}
        {/* - When signed in (reopening game): Shows ONLINE LOADING SCREEN      */}
        {/*   (No sign-in button)                                              */}
        {/* - When signed out: Shows SIGN IN BY PLAY SERVICE BUTTON            */}
        {/* ------------------------------------------------------------------ */}
        {isSignedIn ? (
          // ONLINE LOADING SCREEN (Clean, modern Play Games card without sign-in button)
          <div className="mt-6 flex flex-col items-center w-full max-w-xs animate-in fade-in zoom-in-95 duration-400">
            <div className="w-full p-3 rounded-2xl bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border border-emerald-500/30 shadow-lg flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                {/* Gamer Avatar / Initial */}
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-xs">
                  {player?.avatarUri ? (
                    <img
                      src={player.avatarUri}
                      alt={player.displayName}
                      className="w-full h-full rounded-xl object-cover"
                    />
                  ) : player?.displayName ? (
                    player.displayName.charAt(0).toUpperCase()
                  ) : (
                    <User className="w-4 h-4" />
                  )}
                </div>

                {/* Player Name & Online Tag */}
                <div className="text-left min-w-0">
                  <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {player?.displayName || 'Play Games Player'}
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                    </span>
                    <span>Online</span>
                    <span className="text-slate-300 dark:text-slate-600">•</span>
                    <span className="text-slate-500 dark:text-slate-400 truncate">Cloud Synced</span>
                  </div>
                </div>
              </div>

              {/* Verified Icon */}
              <div className="w-7 h-7 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center shrink-0 text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-2 font-medium flex items-center gap-1.5">
              <Cloud className="w-3.5 h-3.5 text-emerald-500" />
              <span>Synced stars, leaderboards & achievements</span>
            </p>
          </div>
        ) : (
          // SIGN IN BY PLAY SERVICE (When user is signed out)
          <div className="mt-6 flex flex-col items-center gap-2.5 w-full max-w-xs animate-in fade-in duration-300">
            <button
              type="button"
              onClick={handlePlayGamesSignIn}
              disabled={isSigningIn}
              className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-98 text-white font-bold text-xs shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-60"
            >
              {isSigningIn ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin shrink-0" />
                  <span>Connecting to Play Games…</span>
                </>
              ) : (
                <>
                  <Gamepad2 className="w-4 h-4 shrink-0" />
                  <span>Sign in with Google Play Games</span>
                </>
              )}
            </button>

            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Saves stars, scores & streak across devices</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Action Area */}
      <div className="relative z-10 pb-4 flex flex-col items-center gap-2">
        {progressPercent >= 100 && (
          <button
            type="button"
            onClick={handleExitGame}
            className="px-5 py-2.5 rounded-full bg-white/80 dark:bg-slate-900/80 hover:bg-white dark:hover:bg-slate-900 backdrop-blur-md text-xs font-bold text-slate-800 dark:text-slate-100 shadow-md border border-slate-200/60 dark:border-slate-800/60 flex items-center gap-2 transition-all hover:scale-105 active:scale-95 animate-in fade-in duration-300 cursor-pointer"
          >
            <span>{isSignedIn ? 'Start Playing' : 'Play as Guest'}</span>
            <ArrowRight className="w-4 h-4 text-indigo-500" />
          </button>
        )}
      </div>
    </div>
  );
};
