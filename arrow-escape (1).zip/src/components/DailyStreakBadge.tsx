import React from 'react';
import { Flame, Check, Trophy, Sparkles, ShieldCheck } from 'lucide-react';

export interface DailyStreakBadgeProps {
  streak: number;
  compact?: boolean;
  isCompletedToday?: boolean;
  showPips?: boolean;
  className?: string;
}

/**
 * Visual component to display the current daily streak count and commitment track.
 * Helps players visualize their daily habit, milestones, and streak progression.
 */
export const DailyStreakBadge: React.FC<DailyStreakBadgeProps> = ({
  streak = 1,
  compact = false,
  isCompletedToday = false,
  showPips = true,
  className = '',
}) => {
  const safeStreak = Math.max(0, streak);
  const dayInCycle = safeStreak > 0 ? ((safeStreak - 1) % 7) + 1 : 1;
  const cycleCount = safeStreak > 0 ? Math.floor((safeStreak - 1) / 7) + 1 : 1;

  if (compact) {
    return (
      <div
        className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg border text-[11px] font-semibold tabular-nums transition-all ${
          isCompletedToday
            ? 'bg-amber-500/10 border-amber-500/25 text-amber-700 dark:text-amber-300'
            : 'bg-orange-500/10 border-orange-500/25 text-orange-700 dark:text-orange-300'
        } ${className}`}
        title={`${safeStreak} day streak${isCompletedToday ? ' · Completed today' : ' · Play today to extend'}`}
      >
        <Flame
          className={`w-3.5 h-3.5 ${
            safeStreak > 0
              ? 'fill-orange-500 text-orange-500 animate-pulse'
              : 'text-slate-400'
          }`}
        />
        <span>
          {safeStreak} {safeStreak === 1 ? 'Day' : 'Days'}
        </span>
        {isCompletedToday && (
          <Check className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
        )}
      </div>
    );
  }

  return (
    <div
      className={`rounded-2xl border p-3.5 transition-all ${
        isCompletedToday
          ? 'bg-gradient-to-br from-amber-50/80 via-orange-50/40 to-slate-50 dark:from-amber-950/20 dark:via-orange-950/10 dark:to-slate-900 border-amber-200/70 dark:border-amber-800/50'
          : 'bg-gradient-to-br from-orange-50/60 via-slate-50 to-white dark:from-orange-950/20 dark:via-slate-900 dark:to-slate-900 border-orange-200/70 dark:border-orange-900/40'
      } ${className}`}
    >
      {/* Top Header Row */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center relative shadow-xs ${
              isCompletedToday
                ? 'bg-amber-500 text-white shadow-amber-500/25'
                : 'bg-orange-500 text-white shadow-orange-500/25'
            }`}
          >
            <Flame className="w-5 h-5 fill-white text-white animate-pulse" />
            {isCompletedToday && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-emerald-500 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900">
                <Check className="w-2.5 h-2.5 text-white" />
              </span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-sm font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
                {safeStreak} {safeStreak === 1 ? 'Day Streak' : 'Days Streak'}
              </span>
              {cycleCount > 1 && (
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300">
                  Cycle {cycleCount}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {isCompletedToday
                ? 'Streak secured for today · Commitment active'
                : 'Play today to keep your streak alive!'}
            </p>
          </div>
        </div>

        {/* Commitment status chip */}
        <div className="shrink-0">
          {isCompletedToday ? (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-emerald-100/80 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 text-[11px] font-semibold border border-emerald-200 dark:border-emerald-800/50">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              Safe
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2 py-1 rounded-lg bg-orange-100/80 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300 text-[11px] font-semibold border border-orange-200 dark:border-orange-800/50 animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
              Active
            </span>
          )}
        </div>
      </div>

      {/* 7-Day Cycle Progress Pips */}
      {showPips && (
        <div className="pt-2 border-t border-slate-200/60 dark:border-slate-800/60">
          <div className="flex items-center justify-between text-[10px] font-medium text-slate-500 dark:text-slate-400 mb-1.5">
            <span>7-Day Cycle Progress</span>
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Day {dayInCycle} of 7
            </span>
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7].map((dayNum) => {
              const isPast = dayNum < dayInCycle || (dayNum === dayInCycle && isCompletedToday);
              const isCurrent = dayNum === dayInCycle && !isCompletedToday;
              const isGrandPrizeDay = dayNum === 7;

              return (
                <div
                  key={dayNum}
                  className={`flex flex-col items-center py-1.5 px-0.5 rounded-xl border text-[10px] transition-all relative ${
                    isPast
                      ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                      : isCurrent
                      ? 'bg-white dark:bg-slate-800 text-orange-600 dark:text-orange-400 border-orange-400 dark:border-orange-500 ring-2 ring-orange-400/20 font-bold'
                      : isGrandPrizeDay
                      ? 'bg-indigo-50/50 dark:bg-indigo-950/30 text-indigo-400 dark:text-indigo-400 border-dashed border-indigo-300 dark:border-indigo-800'
                      : 'bg-slate-100/50 dark:bg-slate-800/40 text-slate-400 dark:text-slate-500 border-slate-200/50 dark:border-slate-700/50'
                  }`}
                >
                  <span className="text-[9px] opacity-80 mb-0.5">D{dayNum}</span>
                  {isPast ? (
                    <Check className="w-3 h-3 text-white stroke-[3]" />
                  ) : isGrandPrizeDay ? (
                    <Trophy className="w-3 h-3 text-amber-500" />
                  ) : (
                    <Flame
                      className={`w-3 h-3 ${
                        isCurrent
                          ? 'fill-orange-500 text-orange-500 animate-pulse'
                          : 'text-slate-300 dark:text-slate-600'
                      }`}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
