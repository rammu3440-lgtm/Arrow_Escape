import React, { useState, useEffect } from 'react';
import { Film, CheckCircle2, Sparkles, X } from 'lucide-react';

interface RewardedAdModalProps {
  isOpen: boolean;
  rewardAmount?: number;
  onReward: () => void;
  onClose: () => void;
}

export const RewardedAdModal: React.FC<RewardedAdModalProps> = ({
  isOpen,
  rewardAmount,
  onReward,
  onClose,
}) => {
  const [secondsRemaining, setSecondsRemaining] = useState(3);
  const [canClaim, setCanClaim] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setSecondsRemaining(3);
      setCanClaim(false);
      return;
    }

    setSecondsRemaining(3);
    setCanClaim(false);

    const timer = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCanClaim(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClaim = () => {
    onReward();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-slate-900 text-white rounded-3xl p-6 shadow-2xl border border-slate-800 flex flex-col items-center text-center relative overflow-hidden">
        {/* Ad Sponsor Header */}
        <div className="w-full flex items-center justify-between text-xs text-slate-400 mb-4 pb-2 border-b border-slate-800">
          <span className="flex items-center gap-1.5 font-medium">
            <Film className="w-3.5 h-3.5 text-amber-400" />
            <span>Serene Studios Sponsor</span>
          </span>
          {canClaim && (
            <button
              onClick={handleClaim}
              className="w-6 h-6 rounded-full flex items-center justify-center text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Calm Animated Sponsor Creative */}
        <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-amber-500 to-indigo-600 flex items-center justify-center my-3 shadow-lg shadow-amber-500/20 animate-pulse">
          <Sparkles className="w-10 h-10 text-white" />
        </div>

        <h3 className="text-lg font-bold text-white mb-1">
          Arrow Escape · Serene Puzzles
        </h3>
        <p className="text-xs text-slate-400 max-w-xs leading-relaxed mb-6">
          Thank you for playing and supporting indie puzzle game development!
        </p>

        {/* Progress / Countdown */}
        {!canClaim ? (
          <div className="w-full flex flex-col items-center gap-2">
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-amber-400 h-full transition-all duration-1000 ease-linear rounded-full"
                style={{ width: `${((3 - secondsRemaining) / 3) * 100}%` }}
              />
            </div>
            <span className="text-xs text-slate-400 tabular-nums">
              Reward ready in {secondsRemaining}s...
            </span>
          </div>
        ) : (
          <button
            onClick={handleClaim}
            className="w-full py-3.5 px-4 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-amber-500/25 transition-transform active:scale-95 animate-in zoom-in-95 duration-150"
          >
            <CheckCircle2 className="w-4 h-4 text-slate-950" />
            <span>Claim Reward {rewardAmount ? `(+${rewardAmount} 🪙)` : ''}!</span>
          </button>
        )}
      </div>
    </div>
  );
};
