import React from 'react';
import { X, ArrowRight, CornerDownRight, Heart, Sparkles } from 'lucide-react';

interface HowToPlayModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HowToPlayModal: React.FC<HowToPlayModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-50">How to Play</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col gap-4 overflow-y-auto max-h-[70vh] text-xs leading-relaxed text-slate-600 dark:text-slate-300">
          {/* Rule 1: Free Arrows */}
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/40 text-blue-500 flex items-center justify-center shrink-0">
              <ArrowRight className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm mb-0.5">
                1. Free Escape Path
              </div>
              <p>
                Tap an arrow whose head points directly towards an empty border. If no other arrow blocks its path, it will slide freely off the board!
              </p>
            </div>
          </div>

          {/* Rule 2: Snake Arrows */}
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-500 flex items-center justify-center shrink-0">
              <CornerDownRight className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm mb-0.5">
                2. Snake & Bent Arrows
              </div>
              <p>
                Bent arrows follow their curved track forward through the head cell. As long as the head's outward exit ray is clear, the whole body slithers out smoothly.
              </p>
            </div>
          </div>

          {/* Rule 3: 3 Lives */}
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-xl bg-rose-50 dark:bg-rose-950/40 text-rose-500 flex items-center justify-center shrink-0">
              <Heart className="w-4 h-4 fill-rose-500" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm mb-0.5">
                3. Beware of Obstacles
              </div>
              <p>
                Tapping a blocked arrow costs 1 life and shakes in place. You start with 3 lives per puzzle. Avoid dead-end taps!
              </p>
            </div>
          </div>

          {/* Rule 4: Hints & Undo */}
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-500 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="font-semibold text-slate-900 dark:text-slate-100 text-sm mb-0.5">
                4. Strategic Hints & Undo
              </div>
              <p>
                Use the <strong>Hint</strong> button to spotlight the safe arrow that unblocks the most subsequent arrows. Use <strong>Undo</strong> to recover from accidental taps.
              </p>
            </div>
          </div>

          {/* Dismiss button */}
          <button
            onClick={onClose}
            className="w-full mt-2 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-semibold text-sm transition-transform active:scale-[0.98]"
          >
            Got it, Let's Play!
          </button>
        </div>
      </div>
    </div>
  );
};
