import React, { useState } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  Share2,
  PlusSquare,
  HelpCircle,
  X,
  ExternalLink,
  ShieldCheck,
  Layers,
} from 'lucide-react';
import { usePWAInstall } from '../platform/usePWAInstall';

interface InstallApkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallApkModal: React.FC<InstallApkModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();
  const [installSuccess, setInstallSuccess] = useState(false);
  const [activeTab, setActiveTab] = useState<'apk' | 'ios' | 'desktop'>(
    isAndroid ? 'apk' : isIOS ? 'ios' : 'apk'
  );

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstallSuccess(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="p-5 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800 bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-indigo-500/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-md shadow-emerald-500/20 text-white">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-slate-50 flex items-center gap-1.5">
                Install App / APK
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Play offline with full native experience
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex flex-col gap-4 text-slate-700 dark:text-slate-300">
          {/* Status banner if already installed */}
          {isInstalled && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center gap-3 text-emerald-800 dark:text-emerald-200">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
              <div className="text-xs font-semibold">
                Arrow Escape is already installed on your device in standalone mode!
              </div>
            </div>
          )}

          {/* Primary Action Button (when browser supports direct prompt) */}
          {isInstallable && !isInstalled && (
            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/25 flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold">1-Click Direct Install (Android WebAPK)</h3>
                  <p className="text-xs text-white/80 mt-0.5">
                    Generates and installs official Android app package directly onto your home screen & app drawer.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleInstallClick}
                className="w-full py-2.5 rounded-xl bg-white text-emerald-800 font-bold text-sm shadow-sm hover:bg-emerald-50 transition active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Install App on Device</span>
              </button>
            </div>
          )}

          {/* Platform Guide Tabs */}
          <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-semibold">
            <button
              type="button"
              onClick={() => setActiveTab('apk')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${
                activeTab === 'apk'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Android (APK)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ios')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${
                activeTab === 'ios'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              iOS (iPhone/iPad)
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('desktop')}
              className={`flex-1 py-1.5 rounded-lg transition-all ${
                activeTab === 'desktop'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              PC / Mac
            </button>
          </div>

          {/* Tab Content: Android */}
          {activeTab === 'apk' && (
            <div className="flex flex-col gap-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Android WebAPK & Native Installation:</span>
              </div>
              <ol className="list-decimal pl-4 space-y-2 text-slate-600 dark:text-slate-400 leading-relaxed">
                <li>
                  Open this game in <strong>Google Chrome</strong>, <strong>Brave</strong>, or <strong>Samsung Internet</strong> on your Android phone.
                </li>
                <li>
                  Tap the Chrome menu <strong className="text-slate-900 dark:text-slate-100">(⋮ 3 dots)</strong> in the top-right corner.
                </li>
                <li>
                  Select <strong className="text-slate-900 dark:text-slate-100">"Install app"</strong> or <strong className="text-slate-900 dark:text-slate-100">"Add to Home Screen"</strong>.
                </li>
                <li>
                  Android's package manager will automatically compile and install the <strong>WebAPK</strong> with the official app icon, full-screen canvas, and offline caching.
                </li>
              </ol>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                💡 <strong>Why WebAPK?</strong> It creates a genuine native Android app entry in your app drawer, with zero sideloading warnings, zero unknown source risks, and automatic cloud updates!
              </div>
            </div>
          )}

          {/* Tab Content: iOS */}
          {activeTab === 'ios' && (
            <div className="flex flex-col gap-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100">
                <Share2 className="w-4 h-4 text-indigo-500" />
                <span>iPhone & iPad Safari Installation:</span>
              </div>
              <ol className="list-decimal pl-4 space-y-2 text-slate-600 dark:text-slate-400 leading-relaxed">
                <li>
                  Open the game URL in <strong>Safari</strong> on iOS.
                </li>
                <li>
                  Tap the <strong className="text-slate-900 dark:text-slate-100">Share</strong> button (box with an arrow pointing upward) in the bottom navigation toolbar.
                </li>
                <li>
                  Scroll down and tap <strong className="text-slate-900 dark:text-slate-100">"Add to Home Screen"</strong>.
                </li>
                <li>
                  Tap <strong className="text-slate-900 dark:text-slate-100">"Add"</strong> in the top-right corner.
                </li>
              </ol>
            </div>
          )}

          {/* Tab Content: Desktop */}
          {activeTab === 'desktop' && (
            <div className="flex flex-col gap-3 text-xs">
              <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-slate-100">
                <Layers className="w-4 h-4 text-blue-500" />
                <span>Desktop Chrome / Edge:</span>
              </div>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                Look for the install icon <strong className="text-slate-900 dark:text-slate-100">(⊕ or desktop screen icon)</strong> in the right side of the browser URL address bar, or click Menu <strong className="text-slate-900 dark:text-slate-100">(⋮) &gt; "Install Arrow Escape"</strong>.
              </p>
            </div>
          )}

          {/* Offline & Features check */}
          <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-slate-700 dark:text-slate-300 font-medium">Service Worker Active</span>
            </div>
            <span className="text-emerald-700 dark:text-emerald-300 font-semibold">100% Offline Ready</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-bold transition-all cursor-pointer shadow-xs"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
