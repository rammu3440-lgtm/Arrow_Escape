import React from 'react';
import {
  X,
  Calendar,
  Sparkles,
  Check,
  Coins,
  Lightbulb,
  RotateCcw,
  Trophy,
  Film,
  Flame,
  AlertTriangle,
  Clock,
} from 'lucide-react';
import { EconomyState } from '../game/types';
import {
  DAILY_REWARD_CALENDAR,
  getDailyRewardStatus,
  claimDailyReward,
  restoreStreak,
  DailyRewardDay,
  ECONOMY_CONFIG,
} from '../game/economy';
import { DailyCountdownBadge } from './DailyCountdown';
import { soundManager } from '../game/sound';

interface DailyRewardModalProps {
  isOpen: boolean;
  onClose: () => void;
  economy: EconomyState;
  onUpdateEconomy: (newEconomy: EconomyState) => void;
  onTriggerRewardedAd: (rewardAmount: number, onReward: () => void) => void;
  soundEnabled: boolean;
}

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isOpen,
  onClose,
  economy,
  onUpdateEconomy,
  onTriggerRewardedAd,
  soundEnabled,
}) => {
  if (!isOpen) return null;

  const { status, currentDay, cycleCount } = getDailyRewardStatus(economy);

  const handleClaim = (doubleWithAd: boolean = false) => {
    if (doubleWithAd) {
      onTriggerRewardedAd(100, () => {
        const { state, rewardGranted } = claimDailyReward(economy, true);
        onUpdateEconomy(state);
        soundManager.playWin(soundEnabled);
      });
      return;
    }

    const { state } = claimDailyReward(economy, false);
    onUpdateEconomy(state);
    soundManager.playWin(soundEnabled);
  };

  const handleRestore = (byCoins: boolean) => {
    if (byCoins) {
      const { success, state } = restoreStreak(economy, ECONOMY_CONFIG.STREAK_SAVER_COINS);
      if (success) {
        onUpdateEconomy(state);
        soundManager.playTap(soundEnabled);
      }
    } else {
      onTriggerRewardedAd(0, () => {
        const { state } = restoreStreak(economy, 0);
        onUpdateEconomy(state);
        soundManager.playTap(soundEnabled);
      });
    }
  };

  const cycleMult = Math.min(2.0, 1.0 + (cycleCount - 1) * 0.25);

  const renderRewardIcon = (r: DailyRewardDay) => {
    if (r.type === 'COINS') return <Coins className="w-5 h-5 fill-amber-400 text-amber-500" />;
    if (r.type === 'HINTS') return <Lightbulb className="w-5 h-5 fill-amber-400 text-amber-500" />;
    if (r.type === 'UNDOS') return <RotateCcw className="w-5 h-5 text-indigo-500" />;
    return <Trophy className="w-6 h-6 text-amber-500 fill-amber-300" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col overflow-hidden max-h-[90vh]">
        {/* Header */}
        <div className="p-5 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 text-indigo-500 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                <Flame className="w-3.5 h-3.5 text-orange-500 fill-orange-500" />
                <span>Streak Day {currentDay} · Cycle {cycleCount} ({cycleMult}x)</span>
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-50">
                Daily Rewards
              </h2>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex-1 flex flex-col gap-4">
          {/* Streak Broken Alert */}
          {status === 'STREAK_BROKEN' && (
            <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 rounded-2xl flex flex-col gap-2">
              <div className="flex items-center gap-2 text-rose-700 dark:text-rose-300 font-bold text-xs">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>Streak Broken! You missed yesterday's reward.</span>
              </div>
              <p className="text-[11px] text-rose-600 dark:text-rose-400">
                Restore your previous streak progress or start fresh from Day 1.
              </p>
              <div className="flex gap-2 mt-1">
                <button
                  onClick={() => handleRestore(true)}
                  disabled={economy.coins < ECONOMY_CONFIG.STREAK_SAVER_COINS}
                  className="flex-1 py-1.5 px-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold disabled:opacity-50"
                >
                  Restore ({ECONOMY_CONFIG.STREAK_SAVER_COINS} 🪙)
                </button>
                <button
                  onClick={() => handleRestore(false)}
                  className="flex-1 py-1.5 px-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-semibold"
                >
                  Restore (Watch Ad)
                </button>
              </div>
            </div>
          )}

          {/* 7-Day Calendar Grid */}
          <div className="grid grid-cols-3 gap-2.5">
            {DAILY_REWARD_CALENDAR.map((item) => {
              const isPast = status === 'ALREADY_CLAIMED' ? item.day <= currentDay : item.day < currentDay;
              const isToday = item.day === currentDay;
              const isDay7 = item.day === 7;

              return (
                <div
                  key={item.day}
                  className={`p-3 rounded-2xl border text-center flex flex-col items-center justify-between transition-all ${
                    isDay7 ? 'col-span-3 flex-row py-3.5 px-4 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-transparent' : ''
                  } ${
                    isToday && status === 'CLAIMABLE'
                      ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30 shadow-md ring-2 ring-indigo-500/30'
                      : isPast
                      ? 'border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/40 dark:bg-emerald-950/20'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 opacity-75'
                  }`}
                >
                  <div className={`flex ${isDay7 ? 'items-center gap-3 text-left' : 'flex-col items-center gap-1.5'}`}>
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                      Day {item.day}
                    </span>
                    <div className="p-2 rounded-xl bg-white dark:bg-slate-800 shadow-xs border border-slate-100 dark:border-slate-700/60">
                      {renderRewardIcon(item)}
                    </div>
                    {isDay7 && (
                      <div>
                        <div className="font-bold text-sm text-slate-900 dark:text-slate-100">
                          Day 7 Grand Chest
                        </div>
                        <div className="text-xs text-amber-600 dark:text-amber-400 font-semibold">
                          100 Coins + Free Epic Skin Shard!
                        </div>
                      </div>
                    )}
                  </div>

                  {!isDay7 && (
                    <div className="mt-2 text-xs font-bold text-slate-800 dark:text-slate-200 tabular-nums">
                      {item.title}
                    </div>
                  )}

                  {/* Status Indicator */}
                  <div className={isDay7 ? '' : 'mt-1'}>
                    {isPast ? (
                      <span className="inline-flex items-center gap-0.5 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                        <Check className="w-3.5 h-3.5" /> Claimed
                      </span>
                    ) : isToday && status === 'CLAIMABLE' ? (
                      <span className="inline-block px-2 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold animate-pulse">
                        Ready
                      </span>
                    ) : (
                      <span className="text-[10px] text-slate-400">Locked</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Claim Buttons or Countdown Banner */}
          {status === 'CLAIMABLE' ? (
            <div className="flex flex-col gap-2 mt-2">
              <button
                onClick={() => handleClaim(true)}
                className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-transform active:scale-[0.98]"
              >
                <Film className="w-4 h-4" />
                <span>Claim 2x Reward (Watch 3s Ad)</span>
              </button>

              <button
                onClick={() => handleClaim(false)}
                className="w-full py-3 px-4 rounded-2xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Claim Normal Reward</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-col gap-2 mt-2">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200/60 text-center text-xs text-emerald-800 dark:text-emerald-200 font-medium">
                Today's reward claimed! Come back tomorrow to continue your streak.
              </div>
              <DailyCountdownBadge />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
