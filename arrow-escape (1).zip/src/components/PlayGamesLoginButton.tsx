import React from 'react';
import { AuthState, PlayerProfile } from '../platform/types';
import { Loader2, LogIn, LogOut, Trophy, Award, CheckCircle2, Cloud } from 'lucide-react';
import { platformServices } from '../platform';

export interface PlayGamesLoginButtonProps {
  authState: AuthState;
  player: PlayerProfile | null;
  onSignIn: () => Promise<boolean>;
  onDisconnect?: () => Promise<void>;
  variant?: 'compact' | 'card' | 'chip';
  className?: string;
  onDismiss?: () => void;
}

export const PlayGamesLoginButton: React.FC<PlayGamesLoginButtonProps> = ({
  authState,
  player,
  onSignIn,
  onDisconnect,
  variant = 'card',
  className = '',
  onDismiss,
}) => {
  const isSigningIn = authState === 'SIGNING_IN';
  const isSignedIn = authState === 'SIGNED_IN';

  // --- Chip Variant (used for non-intrusive Home/HUD banner) ---
  if (variant === 'chip') {
    // Only displayed when the user is signed out
    if (isSignedIn) {
      return null;
    }

    return (
      <button
        onClick={() => onSignIn()}
        disabled={isSigningIn}
        className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-xs hover:shadow-md transition-all active:scale-95 disabled:opacity-50 ${className}`}
        title="Sign in with Google Play Games"
      >
        {isSigningIn ? (
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
        ) : (
          <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24">
            <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM19 18H6c-2.21 0-4-1.79-4-4 0-2.05 1.53-3.76 3.56-3.97l1.07-.11.5-.95C8.08 7.14 9.94 6 12 6c2.62 0 4.88 1.86 5.39 4.43l.3 1.5 1.53.11c1.56.1 2.78 1.41 2.78 2.96 0 1.65-1.35 3-3 3z" />
          </svg>
        )}
        <span>{isSigningIn ? 'Connecting…' : 'Sign in to save progress'}</span>
      </button>
    );
  }

  // --- Compact Variant (e.g. within quick bars) ---
  if (variant === 'compact') {
    return (
      <button
        onClick={() => onSignIn()}
        disabled={isSigningIn}
        className={`flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs active:scale-95 disabled:opacity-60 ${className}`}
      >
        {isSigningIn ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <LogIn className="w-4 h-4" />
        )}
        <span>{isSigningIn ? 'Connecting…' : 'Play Games Login'}</span>
      </button>
    );
  }

  // --- Full Card Variant (used in SettingsModal) ---
  return (
    <div
      className={`rounded-2xl p-4 border transition-all ${
        isSignedIn
          ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/40'
          : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200/80 dark:border-slate-800'
      } ${className}`}
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shrink-0 shadow-xs">
            {isSignedIn ? (
              <CheckCircle2 className="w-5 h-5" />
            ) : (
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z" />
              </svg>
            )}
          </div>
          <div className="min-w-0">
            <div className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5 truncate">
              <span>Google Play Games</span>
              {isSignedIn && (
                <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300">
                  Connected
                </span>
              )}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
              {isSignedIn
                ? player?.displayName || 'Player Account'
                : 'Cloud saves & global leaderboards'}
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div>
          {isSignedIn ? (
            <button
              onClick={onDisconnect}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors flex items-center gap-1"
              title="Disconnect Play Games account"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Disconnect</span>
            </button>
          ) : (
            <button
              onClick={() => onSignIn()}
              disabled={isSigningIn}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs hover:shadow-md transition-all active:scale-95 disabled:opacity-60"
            >
              {isSigningIn ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Connecting…</span>
                </>
              ) : (
                <>
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Extra actions when signed in: Leaderboards & Achievements */}
      {isSignedIn && (
        <div className="mt-3 pt-3 border-t border-emerald-200/60 dark:border-emerald-900/40 flex items-center gap-2">
          <button
            onClick={() => platformServices.showLeaderboard()}
            className="flex-1 py-1.5 px-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            <span>Leaderboards</span>
          </button>
          <button
            onClick={() => platformServices.showAchievements()}
            className="flex-1 py-1.5 px-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 font-semibold text-xs flex items-center justify-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
          >
            <Award className="w-3.5 h-3.5 text-indigo-500" />
            <span>Achievements</span>
          </button>
        </div>
      )}
    </div>
  );
};
