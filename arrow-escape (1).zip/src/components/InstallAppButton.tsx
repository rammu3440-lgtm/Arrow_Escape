import React, { useState } from 'react';
import { Download, Smartphone } from 'lucide-react';
import { usePWAInstall } from '../platform/usePWAInstall';

interface InstallButtonProps {
  onOpenModal: () => void;
  className?: string;
  variant?: 'hud' | 'banner' | 'settings';
}

export const InstallAppButton: React.FC<InstallButtonProps> = ({
  onOpenModal,
  className = '',
  variant = 'hud',
}) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  // If already running in standalone mode, keep available in settings or minimal in HUD
  if (variant === 'hud') {
    return (
      <button
        onClick={async () => {
          if (isInstallable) {
            const success = await install();
            if (!success) onOpenModal();
          } else {
            onOpenModal();
          }
        }}
        className={`h-9 px-2.5 rounded-xl flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-950/70 border border-emerald-200/80 dark:border-emerald-800/60 text-emerald-700 dark:text-emerald-300 font-bold text-xs shadow-xs transition-all active:scale-95 cursor-pointer ${className}`}
        title="Install Android App / APK"
        aria-label="Install App"
      >
        <Download className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
        <span className="tracking-wider uppercase text-[11px] font-extrabold hidden sm:inline">
          Install APK
        </span>
        <span className="tracking-wider uppercase text-[11px] font-extrabold sm:hidden">
          APK
        </span>
      </button>
    );
  }

  return (
    <button
      onClick={onOpenModal}
      className={`w-full py-2.5 px-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:hover:bg-emerald-950/70 border border-emerald-200/60 dark:border-emerald-800/50 text-emerald-800 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${className}`}
    >
      <div className="flex items-center gap-2.5">
        <Smartphone className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
        <span>Install Android APK / App</span>
      </div>
      <Download className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
    </button>
  );
};
