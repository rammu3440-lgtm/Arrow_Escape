import React, { useState, useEffect } from 'react';
import { X, Star, Lock, Trophy, Infinity as InfinityIcon, Calendar, Flame, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { BASE_CAMPAIGN_LEVELS, getCampaignTier } from '../game/levels';
import { GameMode, LevelProgress } from '../game/types';
import { DailyCountdownBadge } from './DailyCountdown';
import { DailyStreakBadge } from './DailyStreakBadge';

interface LevelSelectModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentLevel: number;
  gameMode: GameMode;
  progress: Record<number, LevelProgress>;
  infiniteStreak: number;
  dailyCompletedToday: boolean;
  dailyStreak?: number;
  onSelectCampaignLevel: (level: number) => void;
  onSelectInfiniteMode: () => void;
  onSelectDailyMode: () => void;
}

export const LevelSelectModal: React.FC<LevelSelectModalProps> = ({
  isOpen,
  onClose,
  currentLevel,
  gameMode,
  progress,
  infiniteStreak,
  dailyCompletedToday,
  dailyStreak = 1,
  onSelectCampaignLevel,
  onSelectInfiniteMode,
  onSelectDailyMode,
}) => {
  const [activeTab, setActiveTab] = useState<'CAMPAIGN' | 'MODES'>('CAMPAIGN');
  const [page, setPage] = useState<number>(() => Math.floor(Math.max(0, currentLevel - 1) / 20));

  const pageSize = 20;

  // Highest level currently unlocked or played
  const highestUnlocked = Math.max(
    1,
    currentLevel,
    ...Object.keys(progress)
      .map(Number)
      .filter((lvl) => !isNaN(lvl) && (progress[lvl]?.unlocked || (progress[lvl]?.stars || 0) > 0))
  );

  // Dynamically expand available level pages as player progresses infinitely
  const maxAvailableLevel = Math.max(
    BASE_CAMPAIGN_LEVELS,
    Math.ceil((highestUnlocked + 1) / pageSize) * pageSize
  );
  const totalPages = Math.ceil(maxAvailableLevel / pageSize);
  const currentTier = getCampaignTier(highestUnlocked);
  const highestPage = Math.floor(Math.max(0, highestUnlocked - 1) / pageSize);

  // Sync page when modal opens to show current level
  useEffect(() => {
    if (isOpen) {
      setPage(Math.floor(Math.max(0, currentLevel - 1) / pageSize));
    }
  }, [isOpen, currentLevel]);

  if (!isOpen) return null;

  const currentPage = Math.max(0, Math.min(totalPages - 1, page));
  const startLevel = currentPage * pageSize + 1;
  const endLevel = Math.min(maxAvailableLevel, (currentPage + 1) * pageSize);

  const totalStarsEarned = Object.values(progress).reduce(
    (sum, p) => sum + (p.stars || 0),
    0
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col max-h-[85vh] overflow-hidden">
        {/* Header */}
        <div className="p-5 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900 dark:text-slate-50">Select Puzzle</h2>
              <DailyStreakBadge streak={dailyStreak} compact isCompletedToday={dailyCompletedToday} />
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1 flex-wrap">
              <span className="flex items-center gap-1 font-semibold text-amber-500">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-500" /> {totalStarsEarned} Stars · Level {highestUnlocked}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-semibold text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                <span>{currentTier.badge}</span> {currentTier.name}
              </span>
              <span aria-hidden="true">·</span>
              <DailyCountdownBadge compact />
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-3 pb-2 flex gap-2 border-b border-slate-100 dark:border-slate-800">
          <button
            onClick={() => setActiveTab('CAMPAIGN')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-colors ${
              activeTab === 'CAMPAIGN'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Campaign ({highestUnlocked} Unlocked · Endless)
          </button>
          <button
            onClick={() => setActiveTab('MODES')}
            className={`flex-1 py-2 text-xs font-semibold rounded-xl transition-colors ${
              activeTab === 'MODES'
                ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Special Modes
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex-1">
          {activeTab === 'CAMPAIGN' ? (
            <div>
              {/* Pagination Subtabs with navigation controls */}
              <div className="flex items-center justify-between gap-1.5 mb-4">
                <button
                  disabled={currentPage <= 0}
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                  aria-label="Previous Page"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                <div className="flex gap-1.5 overflow-x-auto py-0.5 px-1 scrollbar-none flex-1 justify-center">
                  {Array.from({ length: totalPages }).map((_, pIdx) => (
                    <button
                      key={pIdx}
                      onClick={() => setPage(pIdx)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
                        currentPage === pIdx
                          ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-xs'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                      }`}
                    >
                      {pIdx * pageSize + 1}-{Math.min(maxAvailableLevel, (pIdx + 1) * pageSize)}
                    </button>
                  ))}
                </div>

                <button
                  disabled={currentPage >= totalPages - 1}
                  onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30 disabled:pointer-events-none transition-colors"
                  aria-label="Next Page"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>

                {currentPage !== highestPage && (
                  <button
                    onClick={() => setPage(highestPage)}
                    className="px-2 py-1 rounded-lg text-2xs font-bold bg-amber-100 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 hover:bg-amber-200 transition-colors shrink-0"
                    title="Jump to latest unlocked level"
                  >
                    Frontier
                  </button>
                )}
              </div>

              {/* Levels Grid (4 columns) */}
              <div className="grid grid-cols-4 gap-2.5">
                {Array.from({ length: endLevel - startLevel + 1 }).map((_, i) => {
                  const lvl = startLevel + i;
                  const lvlData = progress[lvl];
                  const isUnlocked = lvl === 1 || lvlData?.unlocked;
                  const isCurrent = gameMode === 'CAMPAIGN' && currentLevel === lvl;
                  const stars = lvlData?.stars || 0;
                  const isBoss = lvl % 10 === 0;
                  const isApex = lvl % 100 === 0;
                  const isGrand = lvl % 50 === 0;

                  return (
                    <button
                      key={lvl}
                      disabled={!isUnlocked}
                      onClick={() => {
                        onSelectCampaignLevel(lvl);
                        onClose();
                      }}
                      className={`h-16 rounded-2xl flex flex-col items-center justify-center relative transition-all ${
                        !isUnlocked
                          ? 'bg-slate-100/60 dark:bg-slate-800/40 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                          : isCurrent
                          ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-md scale-102 font-bold'
                          : isApex
                          ? 'bg-purple-50 dark:bg-purple-950/40 border border-purple-300 dark:border-purple-700 text-slate-800 dark:text-slate-200 hover:border-purple-500'
                          : isGrand
                          ? 'bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-300 dark:border-indigo-700 text-slate-800 dark:text-slate-200 hover:border-indigo-400'
                          : isBoss
                          ? 'bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 text-slate-800 dark:text-slate-200 hover:border-amber-400'
                          : 'bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200/70 dark:border-slate-700/60'
                      }`}
                    >
                      {isBoss && isUnlocked && (
                        <Trophy className={`w-3 h-3 absolute top-1.5 right-1.5 ${isApex ? 'text-purple-500' : isGrand ? 'text-indigo-500' : 'text-amber-500'}`} />
                      )}

                      {!isUnlocked ? (
                        <Lock className="w-4 h-4 text-slate-400 dark:text-slate-600" />
                      ) : (
                        <>
                          <span className="text-sm font-semibold">{lvl}</span>
                          <div className="flex gap-0.5 mt-0.5">
                            {[1, 2, 3].map((s) => (
                              <Star
                                key={s}
                                className={`w-2.5 h-2.5 ${
                                  s <= stars
                                    ? 'fill-amber-400 text-amber-500'
                                    : isCurrent
                                    ? 'text-slate-400/50'
                                    : 'text-slate-300 dark:text-slate-600'
                                }`}
                              />
                            ))}
                          </div>
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Special Modes Tab */
            <div className="flex flex-col gap-3">
              {/* Daily Challenge Card */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-500 flex items-center justify-center shrink-0">
                      <Calendar className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-xs font-semibold uppercase text-indigo-600 dark:text-indigo-400">
                        Daily Challenge
                      </div>
                      <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                        Today's Puzzle
                      </div>
                      <div className="text-xs text-slate-500">
                        {dailyCompletedToday ? 'Completed today · 3 Stars' : 'Fresh procedural seed'}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      onSelectDailyMode();
                      onClose();
                    }}
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors shrink-0"
                  >
                    {dailyCompletedToday ? 'Replay' : 'Play'}
                  </button>
                </div>

                {/* Daily Streak Commitment Tracker */}
                <DailyStreakBadge
                  streak={dailyStreak}
                  isCompletedToday={dailyCompletedToday}
                />

                {/* Animated Countdown Banner */}
                <DailyCountdownBadge />
              </div>

              {/* Endless Mode Card */}
              <div className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-500 flex items-center justify-center">
                    <InfinityIcon className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold uppercase text-emerald-600 dark:text-emerald-400">
                      Endless Mode
                    </div>
                    <div className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      Continuous Escape
                    </div>
                    <div className="text-xs text-slate-500 flex items-center gap-1">
                      <Flame className="w-3.5 h-3.5 text-orange-500" />
                      Current streak: {infiniteStreak}
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    onSelectInfiniteMode();
                    onClose();
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors"
                >
                  Play
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
