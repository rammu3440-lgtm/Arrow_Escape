import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Arrow, Board, Cell, Direction, PaletteName, SkinName } from '../game/types';
import { cellKey, getDelta, isBlocked } from '../game/core';
import { THEME_PALETTES, ThemeColors } from '../game/palettes';

interface ActiveSlideAnimation {
  arrow: Arrow;
  startTime: number;
  duration: number;
  particles: { x: number; y: number; vx: number; vy: number; alpha: number; color: string }[];
}

interface ActiveShakeAnimation {
  arrowId: string;
  startTime: number;
  duration: number;
}

interface BoardCanvasProps {
  board: Board;
  hintArrowId?: string | null;
  onTapArrow: (arrow: Arrow) => void;
  palette: PaletteName;
  skin?: SkinName;
  darkMode: boolean;
  reduceMotion: boolean;
  slidingArrow?: Arrow | null;
  shakingArrowId?: string | null;
}

export const BoardCanvas: React.FC<BoardCanvasProps> = ({
  board,
  hintArrowId,
  onTapArrow,
  palette,
  skin = 'ribbon',
  darkMode,
  reduceMotion,
  slidingArrow,
  shakingArrowId,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [boardSizePx, setBoardSizePx] = useState<{ width: number; height: number; cellSize: number }>({
    width: 360,
    height: 360,
    cellSize: 60,
  });

  const slideAnimRef = useRef<ActiveSlideAnimation | null>(null);
  const shakeAnimRef = useRef<ActiveShakeAnimation | null>(null);
  const requestFrameRef = useRef<number | 0>(0);

  const theme: ThemeColors = darkMode
    ? THEME_PALETTES[palette].dark
    : THEME_PALETTES[palette].light;

  // Handle external trigger for slide
  useEffect(() => {
    if (slidingArrow) {
      const colors = theme.arrowPalette[slidingArrow.colorIndex % theme.arrowPalette.length];
      const particles = [];
      if (!reduceMotion) {
        for (let i = 0; i < 14; i++) {
          particles.push({
            x: slidingArrow.head.x,
            y: slidingArrow.head.y,
            vx: (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 2,
            alpha: 1,
            color: colors.fill,
          });
        }
      }
      slideAnimRef.current = {
        arrow: slidingArrow,
        startTime: performance.now(),
        duration: reduceMotion ? 120 : 320,
        particles,
      };
    }
  }, [slidingArrow, reduceMotion, theme]);

  // Handle external trigger for shake
  useEffect(() => {
    if (shakingArrowId) {
      shakeAnimRef.current = {
        arrowId: shakingArrowId,
        startTime: performance.now(),
        duration: reduceMotion ? 80 : 260,
      };
    }
  }, [shakingArrowId, reduceMotion]);

  // Measure container and set responsive cell size
  useEffect(() => {
    const handleResize = () => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const availableW = Math.max(260, rect.width - 24);
      const availableH = Math.max(260, rect.height - 24);

      // Desired cell size
      const maxCols = board.width;
      const maxRows = board.height;

      const cellSizeW = Math.floor(availableW / maxCols);
      const cellSizeH = Math.floor(availableH / maxRows);
      const cellSize = Math.min(cellSizeW, cellSizeH, 84); // Cap max size for aesthetics

      const totalW = cellSize * maxCols;
      const totalH = cellSize * maxRows;

      setBoardSizePx({
        width: totalW,
        height: totalH,
        cellSize,
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [board.width, board.height]);

  // Path interpolation for sliding snake/straight arrows
  // Moves each point along the snake sequence and then out through the head's escape ray
  const getSlidingPoint = useCallback(
    (
      cellIndex: number,
      arrow: Arrow,
      progress: number,
      cellSize: number,
      padding: number
    ): { x: number; y: number } => {
      const { dx, dy } = getDelta(arrow.direction);
      const speedMultiplier = board.width + board.height;
      const distance = progress * speedMultiplier;

      // Effective position along the chain
      // Head is at index 0, tail is at index body.length - 1
      // Moving forward means index shifts towards head (or past head into void)
      const virtualIndex = cellIndex - distance;

      if (virtualIndex <= 0) {
        // Beyond the head: moving in head.direction
        const extraDist = -virtualIndex;
        const hx = arrow.head.x + dx * extraDist;
        const hy = arrow.head.y + dy * extraDist;
        return {
          x: (hx + 0.5) * cellSize + padding,
          y: (hy + 0.5) * cellSize + padding,
        };
      } else {
        // Still within body track: interpolate between body[floor] and body[ceil]
        const floorIdx = Math.floor(virtualIndex);
        const ceilIdx = Math.min(arrow.body.length - 1, Math.ceil(virtualIndex));
        const fraction = virtualIndex - floorIdx;

        const c1 = arrow.body[floorIdx] || arrow.body[0];
        const c2 = arrow.body[ceilIdx] || arrow.body[arrow.body.length - 1];

        const ix = c1.x + (c2.x - c1.x) * fraction;
        const iy = c1.y + (c2.y - c1.y) * fraction;

        return {
          x: (ix + 0.5) * cellSize + padding,
          y: (iy + 0.5) * cellSize + padding,
        };
      }
    },
    [board.width, board.height]
  );

  // Main Canvas Rendering Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;
    const dpr = window.devicePixelRatio || 1;
    const padding = 20;

    const render = (now: number) => {
      if (!isRunning) return;

      const { width, height, cellSize } = boardSizePx;
      const totalWidthWithPad = width + padding * 2;
      const totalHeightWithPad = height + padding * 2;

      // Handle DPR scaling
      if (
        canvas.width !== Math.round(totalWidthWithPad * dpr) ||
        canvas.height !== Math.round(totalHeightWithPad * dpr)
      ) {
        canvas.width = Math.round(totalWidthWithPad * dpr);
        canvas.height = Math.round(totalHeightWithPad * dpr);
      }

      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.clearRect(0, 0, totalWidthWithPad, totalHeightWithPad);

      // Draw Grid Background Plate
      ctx.fillStyle = theme.bgBoard;
      ctx.beginPath();
      ctx.roundRect(padding - 4, padding - 4, width + 8, height + 8, 16);
      ctx.fill();

      // Subtle shadow under board
      ctx.strokeStyle = theme.gridLine;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Draw individual cell recessed pockets
      for (let x = 0; x < board.width; x++) {
        for (let y = 0; y < board.height; y++) {
          const cx = padding + x * cellSize;
          const cy = padding + y * cellSize;
          const inset = 3;

          ctx.fillStyle = theme.cellEmpty;
          ctx.beginPath();
          ctx.roundRect(
            cx + inset,
            cy + inset,
            cellSize - inset * 2,
            cellSize - inset * 2,
            Math.max(6, cellSize * 0.16)
          );
          ctx.fill();

          ctx.strokeStyle = theme.gridLine;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }

      // Check active shake animation
      let shakeDx = 0;
      let shakeDy = 0;
      let shakingArrowIdCurrent: string | null = null;
      if (shakeAnimRef.current) {
        const elapsed = now - shakeAnimRef.current.startTime;
        const progress = Math.min(1, elapsed / shakeAnimRef.current.duration);
        if (progress >= 1) {
          shakeAnimRef.current = null;
        } else {
          shakingArrowIdCurrent = shakeAnimRef.current.arrowId;
          const amp = (1 - progress) * 8;
          shakeDx = Math.sin(elapsed * 0.08) * amp;
          shakeDy = Math.cos(elapsed * 0.08) * (amp * 0.5);
        }
      }

      // Check active slide animation
      let activeSlide = slideAnimRef.current;
      let slideProgress = 0;
      if (activeSlide) {
        const elapsed = now - activeSlide.startTime;
        slideProgress = Math.min(1, elapsed / activeSlide.duration);
        if (slideProgress >= 1) {
          slideAnimRef.current = null;
          activeSlide = null;
        }
      }

      // Draw Arrows
      const arrowsToDraw = [...board.arrows];
      // If there's an active sliding arrow, draw it on top
      if (activeSlide) {
        // filter out from static if present
        const sIndex = arrowsToDraw.findIndex((a) => a.id === activeSlide!.arrow.id);
        if (sIndex !== -1) {
          arrowsToDraw.splice(sIndex, 1);
        }
      }

      // Draw normal arrows
      for (const arrow of arrowsToDraw) {
        const isShaking = shakingArrowIdCurrent === arrow.id;
        const isHinted = hintArrowId === arrow.id;
        const colors = theme.arrowPalette[arrow.colorIndex % theme.arrowPalette.length];

        ctx.save();
        if (isShaking) {
          ctx.translate(shakeDx, shakeDy);
        }

        drawArrow(ctx, arrow, colors, cellSize, padding, isHinted, now, isShaking);
        ctx.restore();
      }

      // Draw sliding arrow if active
      if (activeSlide) {
        const arrow = activeSlide.arrow;
        const colors = theme.arrowPalette[arrow.colorIndex % theme.arrowPalette.length];
        const easedProgress = Math.pow(slideProgress, 1.8); // Smooth ease-in slide

        ctx.save();
        ctx.globalAlpha = Math.max(0, 1 - Math.pow(slideProgress, 3));
        drawSlidingArrow(ctx, arrow, colors, cellSize, padding, easedProgress);

        // Draw slide particles
        if (activeSlide.particles.length > 0) {
          for (const p of activeSlide.particles) {
            p.x += p.vx * 0.02;
            p.y += p.vy * 0.02;
            p.alpha = Math.max(0, 1 - slideProgress * 1.3);

            const px = (p.x + 0.5) * cellSize + padding;
            const py = (p.y + 0.5) * cellSize + padding;

            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha;
            ctx.beginPath();
            ctx.arc(px, py, cellSize * 0.07, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
      }

      ctx.restore();
      requestFrameRef.current = requestAnimationFrame(render);
    };

    // Helper: Draw an Arrow
    function drawArrow(
      c: CanvasRenderingContext2D,
      arrow: Arrow,
      colors: typeof theme.arrowPalette[0],
      cellSize: number,
      padding: number,
      isHinted: boolean,
      now: number,
      isShaking: boolean
    ) {
      let bodyWidth = cellSize * 0.56;
      if (skin === 'minimal') bodyWidth = cellSize * 0.36;
      else if (skin === 'neon') bodyWidth = cellSize * 0.52;

      // Hint pulse glow
      if (isHinted) {
        const pulse = 0.5 + 0.5 * Math.sin(now * 0.008);
        c.save();
        c.shadowColor = '#F59E0B';
        c.shadowBlur = 12 + pulse * 10;
        c.strokeStyle = '#F59E0B';
        c.lineWidth = bodyWidth + 8 + pulse * 4;
        c.lineCap = 'round';
        c.lineJoin = 'round';

        c.beginPath();
        arrow.body.forEach((pt, i) => {
          const px = (pt.x + 0.5) * cellSize + padding;
          const py = (pt.y + 0.5) * cellSize + padding;
          if (i === 0) c.moveTo(px, py);
          else c.lineTo(px, py);
        });
        c.stroke();
        c.restore();
      }

      // Shaking red highlight
      if (isShaking) {
        c.save();
        c.shadowColor = '#EF4444';
        c.shadowBlur = 14;
        c.restore();
      }

      // Arrow Body Capsule / Tube
      c.save();
      // Drop shadow for tactile depth
      if (skin === 'neon') {
        c.shadowColor = colors.head;
        c.shadowBlur = 14;
      } else if (skin === 'minimal') {
        c.shadowColor = 'transparent';
        c.shadowBlur = 0;
      } else {
        c.shadowColor = theme.shadow;
        c.shadowBlur = 6;
        c.shadowOffsetY = 3;
      }

      // Draw body ribbon
      c.strokeStyle = colors.fill;
      c.lineWidth = bodyWidth;
      c.lineCap = 'round';
      c.lineJoin = 'round';

      c.beginPath();
      arrow.body.forEach((pt, i) => {
        const px = (pt.x + 0.5) * cellSize + padding;
        const py = (pt.y + 0.5) * cellSize + padding;
        if (i === 0) c.moveTo(px, py);
        else c.lineTo(px, py);
      });
      c.stroke();

      // Border outline for clarity
      c.shadowColor = 'transparent';
      c.shadowBlur = 0;
      c.shadowOffsetY = 0;
      c.strokeStyle = colors.stroke;
      c.lineWidth = skin === 'minimal' ? 2 : 3;
      c.stroke();

      // Neon core highlight
      if (skin === 'neon') {
        c.strokeStyle = 'rgba(255, 255, 255, 0.85)';
        c.lineWidth = bodyWidth * 0.28;
        c.stroke();
      }

      // Bamboo nodes
      if (skin === 'bamboo') {
        c.fillStyle = colors.head;
        arrow.body.forEach((pt) => {
          const px = (pt.x + 0.5) * cellSize + padding;
          const py = (pt.y + 0.5) * cellSize + padding;
          c.beginPath();
          c.arc(px, py, cellSize * 0.08, 0, Math.PI * 2);
          c.fill();
        });
      }

      c.restore();

      // Tail round cap dot accent
      if (arrow.body.length > 1 && skin !== 'minimal') {
        const tail = arrow.body[arrow.body.length - 1];
        const tx = (tail.x + 0.5) * cellSize + padding;
        const ty = (tail.y + 0.5) * cellSize + padding;
        c.fillStyle = colors.stroke;
        c.beginPath();
        c.arc(tx, ty, cellSize * 0.12, 0, Math.PI * 2);
        c.fill();
      }

      // Directional Arrow Head
      const head = arrow.head;
      const hx = (head.x + 0.5) * cellSize + padding;
      const hy = (head.y + 0.5) * cellSize + padding;

      c.save();
      c.translate(hx, hy);

      let rotation = 0;
      if (arrow.direction === 'UP') rotation = -Math.PI / 2;
      else if (arrow.direction === 'DOWN') rotation = Math.PI / 2;
      else if (arrow.direction === 'LEFT') rotation = Math.PI;
      else if (arrow.direction === 'RIGHT') rotation = 0;

      c.rotate(rotation);

      // Sleek Triangle Arrow Tip
      const arrowLength = cellSize * 0.44;
      const arrowHalfWidth = cellSize * 0.32;

      c.fillStyle = colors.head;
      c.beginPath();
      c.moveTo(arrowLength * 0.65, 0);
      c.lineTo(-arrowLength * 0.35, -arrowHalfWidth);
      c.lineTo(-arrowLength * 0.1, 0);
      c.lineTo(-arrowLength * 0.35, arrowHalfWidth);
      c.closePath();
      c.fill();

      // Subtle bright reflection accent on arrowhead
      c.strokeStyle = 'rgba(255, 255, 255, 0.6)';
      c.lineWidth = 1.5;
      c.lineCap = 'round';
      c.beginPath();
      c.moveTo(arrowLength * 0.5, 0);
      c.lineTo(-arrowLength * 0.2, -arrowHalfWidth * 0.6);
      c.stroke();

      c.restore();

      // If it's a snake arrow, draw subtle bend indicators
      if (arrow.isSnake && arrow.body.length >= 3) {
        for (let i = 1; i < arrow.body.length - 1; i++) {
          const prev = arrow.body[i - 1];
          const curr = arrow.body[i];
          const next = arrow.body[i + 1];

          // Check if this cell is a turn
          const isTurn = prev.x !== next.x && prev.y !== next.y;
          if (isTurn) {
            const bx = (curr.x + 0.5) * cellSize + padding;
            const by = (curr.y + 0.5) * cellSize + padding;
            c.fillStyle = 'rgba(255, 255, 255, 0.45)';
            c.beginPath();
            c.arc(bx, by, cellSize * 0.08, 0, Math.PI * 2);
            c.fill();
          }
        }
      }
    }

    // Helper: Draw Sliding Arrow during Escape
    function drawSlidingArrow(
      c: CanvasRenderingContext2D,
      arrow: Arrow,
      colors: typeof theme.arrowPalette[0],
      cellSize: number,
      padding: number,
      progress: number
    ) {
      const bodyWidth = cellSize * 0.56;

      // Compute sliding points for each cell of the body
      const points: { x: number; y: number }[] = [];
      for (let i = 0; i < arrow.body.length; i++) {
        points.push(getSlidingPoint(i, arrow, progress, cellSize, padding));
      }

      // Draw sliding body
      c.save();
      c.strokeStyle = colors.fill;
      c.lineWidth = bodyWidth;
      c.lineCap = 'round';
      c.lineJoin = 'round';

      c.beginPath();
      points.forEach((pt, idx) => {
        if (idx === 0) c.moveTo(pt.x, pt.y);
        else c.lineTo(pt.x, pt.y);
      });
      c.stroke();

      c.strokeStyle = colors.stroke;
      c.lineWidth = 3;
      c.stroke();
      c.restore();

      // Draw sliding arrowhead
      const headPt = points[0];
      c.save();
      c.translate(headPt.x, headPt.y);

      let rotation = 0;
      if (arrow.direction === 'UP') rotation = -Math.PI / 2;
      else if (arrow.direction === 'DOWN') rotation = Math.PI / 2;
      else if (arrow.direction === 'LEFT') rotation = Math.PI;
      else if (arrow.direction === 'RIGHT') rotation = 0;

      c.rotate(rotation);

      const arrowLength = cellSize * 0.44;
      const arrowHalfWidth = cellSize * 0.32;

      c.fillStyle = colors.head;
      c.beginPath();
      c.moveTo(arrowLength * 0.65, 0);
      c.lineTo(-arrowLength * 0.35, -arrowHalfWidth);
      c.lineTo(-arrowLength * 0.1, 0);
      c.lineTo(-arrowLength * 0.35, arrowHalfWidth);
      c.closePath();
      c.fill();
      c.restore();
    }

    requestFrameRef.current = requestAnimationFrame(render);

    return () => {
      isRunning = false;
      if (requestFrameRef.current) {
        cancelAnimationFrame(requestFrameRef.current);
      }
    };
  }, [board, boardSizePx, theme, hintArrowId, getSlidingPoint]);

  // Handle pointer tap on canvas
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const clientY = e.clientY - rect.top;

    const padding = 20;
    const { cellSize } = boardSizePx;

    const gridX = Math.floor((clientX - padding) / cellSize);
    const gridY = Math.floor((clientY - padding) / cellSize);

    if (gridX < 0 || gridX >= board.width || gridY < 0 || gridY >= board.height) {
      return;
    }

    const key = cellKey(gridX, gridY);
    const arrowId = board.grid.get(key);

    if (arrowId) {
      const arrow = board.arrows.find((a) => a.id === arrowId);
      if (arrow) {
        onTapArrow(arrow);
      }
    }
  };

  return (
    <div
      ref={containerRef}
      className="w-full h-full flex items-center justify-center p-2 relative touch-none select-none"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        style={{
          width: boardSizePx.width + 40,
          height: boardSizePx.height + 40,
          cursor: 'pointer',
        }}
        className="max-w-full max-h-full transition-transform active:scale-[0.99]"
      />
    </div>
  );
};
