import React, { useState } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Smartphone,
  Eye,
  Moon,
  Sun,
  ShoppingBag,
  Trash2,
  Check,
  Trees,
  Waves,
  Building2,
  Music,
  Sparkles,
} from 'lucide-react';
import { GameSettings, AmbientSoundscape } from '../game/types';
import { PlayGamesLoginButton } from './PlayGamesLoginButton';
import { InstallAppButton } from './InstallAppButton';
import { AuthState, PlayerProfile } from '../platform/types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: GameSettings;
  onUpdateSettings: (newSettings: Partial<GameSettings>) => void;
  onResetProgress: () => void;
  onReplayIntro?: () => void;
  onOpenShop?: (tab?: 'BOOSTER' | 'THEME' | 'SKIN' | 'COIN_PACK') => void;
  onOpenInstallApk?: () => void;
  playGamesAuth?: {
    authState: AuthState;
    player: PlayerProfile | null;
    signIn: () => Promise<boolean>;
    disconnect: () => Promise<void>;
  };
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetProgress,
  onReplayIntro,
  onOpenShop,
  onOpenInstallApk,
  playGamesAuth,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const soundscapesList: {
    id: AmbientSoundscape;
    label: string;
    desc: string;
    icon: React.ComponentType<{ className?: string }>;
  }[] = [
    { id: 'none', label: 'Off', desc: 'Silent focus', icon: VolumeX },
    { id: 'forest', label: 'Forest', desc: 'Breeze & birdsong', icon: Trees },
    { id: 'ocean', label: 'Ocean', desc: 'Rolling surf', icon: Waves },
    { id: 'city', label: 'City', desc: 'Warm rain & hum', icon: Building2 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="w-full max-w-sm bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-5 pb-3 flex items-center justify-between border-b border-slate-100 dark:border-slate-800">
          <h2 className="text-xl font-bold text-slate-900 dark:text-slate-50">Settings</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full flex items-center justify-center text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-5 flex flex-col gap-4 overflow-y-auto max-h-[75vh]">
          {/* Google Play Games Account & Cloud Save */}
          {playGamesAuth && (
            <PlayGamesLoginButton
              authState={playGamesAuth.authState}
              player={playGamesAuth.player}
              onSignIn={playGamesAuth.signIn}
              onDisconnect={playGamesAuth.disconnect}
              variant="card"
            />
          )}
          {/* Sound FX */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200">
                {settings.soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Sound Effects</div>
                <div className="text-xs text-slate-500">Subtle ambient chimes and whooshes</div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ soundEnabled: !settings.soundEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.soundEnabled ? 'bg-slate-900 dark:bg-slate-100' : 'bg-slate-200 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white dark:bg-slate-900 transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Ambient Soundscapes */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 uppercase">
                <Music className="w-3.5 h-3.5" />
                <span>Ambient Soundscape</span>
              </div>
              {settings.ambientSoundscape !== 'none' && (
                <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400">
                  Active
                </span>
              )}
            </div>

            {/* Soundscape Options Grid */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              {soundscapesList.map((item) => {
                const isSelected = settings.ambientSoundscape === item.id;
                const IconComponent = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => onUpdateSettings({ ambientSoundscape: item.id })}
                    className={`p-2.5 rounded-xl border text-left flex items-start gap-2.5 transition-all ${
                      isSelected
                        ? 'border-slate-900 dark:border-slate-100 bg-slate-50 dark:bg-slate-800/80 shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                    }`}
                  >
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <IconComponent className="w-3.5 h-3.5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                          {item.label}
                        </span>
                        {isSelected && <Check className="w-3 h-3 text-slate-900 dark:text-slate-100 ml-1 shrink-0" />}
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">
                        {item.desc}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Ambient Volume Slider (if soundscape is active) */}
            {settings.ambientSoundscape !== 'none' && (
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-100 dark:border-slate-800 flex flex-col gap-1.5 animate-in fade-in duration-150">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400 font-medium">Ambient Volume</span>
                  <span className="text-slate-900 dark:text-slate-100 font-semibold tabular-nums">
                    {Math.round(settings.ambientVolume * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={settings.ambientVolume}
                  onChange={(e) => onUpdateSettings({ ambientVolume: parseFloat(e.target.value) })}
                  className="w-full accent-slate-900 dark:accent-slate-100 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
                />
              </div>
            )}
          </div>

          {/* Haptic Feedback */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Haptics</div>
                <div className="text-xs text-slate-500">Tactile vibration on tap and error</div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ hapticsEnabled: !settings.hapticsEnabled })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.hapticsEnabled ? 'bg-slate-900 dark:bg-slate-100' : 'bg-slate-200 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white dark:bg-slate-900 transition-transform ${
                  settings.hapticsEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Dark Mode */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200">
                {settings.darkMode ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Dark Theme</div>
                <div className="text-xs text-slate-500">Softer for night sessions</div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ darkMode: !settings.darkMode })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.darkMode ? 'bg-slate-900 dark:bg-slate-100' : 'bg-slate-200 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white dark:bg-slate-900 transition-transform ${
                  settings.darkMode ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Reduce Motion */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <div className="text-sm font-semibold text-slate-900 dark:text-slate-100">Reduce Motion</div>
                <div className="text-xs text-slate-500">Faster, minimal animations</div>
              </div>
            </div>
            <button
              onClick={() => onUpdateSettings({ reduceMotion: !settings.reduceMotion })}
              className={`w-12 h-6 rounded-full transition-colors relative p-0.5 ${
                settings.reduceMotion ? 'bg-slate-900 dark:bg-slate-100' : 'bg-slate-200 dark:bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white dark:bg-slate-900 transition-transform ${
                  settings.reduceMotion ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Themes & Skins - Managed in Shop */}
          {onOpenShop && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                    <ShoppingBag className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">Themes & Skins</div>
                    <div className="text-[11px] text-slate-500">Customize board in Shop</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenShop('THEME');
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-semibold transition-all active:scale-95 cursor-pointer shadow-xs"
                >
                  Open Shop
                </button>
              </div>
            </div>
          )}

          {/* Replay Cinematic Intro */}
          {onReplayIntro && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => {
                  onClose();
                  onReplayIntro();
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                <span>Replay Cinematic Intro</span>
              </button>
            </div>
          )}

          {/* Install APK / Native App */}
          {onOpenInstallApk && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
              <InstallAppButton
                variant="settings"
                onOpenModal={() => {
                  onClose();
                  onOpenInstallApk();
                }}
              />
            </div>
          )}

          {/* Danger Zone: Reset Progress */}
          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            {!confirmReset ? (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full py-2.5 text-xs font-medium text-rose-600 hover:text-rose-700 flex items-center justify-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Reset All Progress</span>
              </button>
            ) : (
              <div className="flex flex-col gap-2 p-3 bg-rose-50 dark:bg-rose-950/30 rounded-2xl border border-rose-100 dark:border-rose-900/40 text-center">
                <span className="text-xs font-semibold text-rose-700 dark:text-rose-300">
                  Are you sure? This erases stars and unlocks.
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      onResetProgress();
                      setConfirmReset(false);
                      onClose();
                    }}
                    className="flex-1 py-1.5 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-700"
                  >
                    Confirm Reset
                  </button>
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="flex-1 py-1.5 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
