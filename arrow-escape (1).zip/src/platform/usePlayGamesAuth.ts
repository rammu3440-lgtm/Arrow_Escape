import { useState, useEffect, useCallback, useRef } from 'react';
import { platformServices, AuthState, PlayerProfile, PlayGamesIds } from './index';

export interface UsePlayGamesAuthReturn {
  authState: AuthState;
  status: AuthState;
  player: PlayerProfile | null;
  errorMessage: string | null;
  signIn: () => Promise<boolean>;
  disconnect: () => Promise<void>;
  isDismissed: boolean;
  dismissForWeek: () => void;
}

const getCachedProfile = (): PlayerProfile | null => {
  try {
    const raw =
      localStorage.getItem(PlayGamesIds.STORAGE_AUTH_STATE_KEY) ||
      localStorage.getItem('pgs_web_player_profile');
    if (raw) return JSON.parse(raw);
  } catch {
    // Ignore
  }
  return null;
};

export function usePlayGamesAuth(): UsePlayGamesAuthReturn {
  const [player, setPlayer] = useState<PlayerProfile | null>(getCachedProfile);
  const [authState, setAuthState] = useState<AuthState>(() => {
    const cached = getCachedProfile();
    return cached ? 'SIGNED_IN' : 'SIGNED_OUT';
  });
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDismissed, setIsDismissed] = useState<boolean>(() => {
    try {
      const until = localStorage.getItem(PlayGamesIds.STORAGE_DISMISS_KEY);
      return until ? Number(until) > Date.now() : false;
    } catch {
      return false;
    }
  });

  const isMountedRef = useRef(true);
  const cachedProfileRef = useRef<PlayerProfile | null>(player);
  cachedProfileRef.current = player;

  // Silent automatic sign-in on launch (non-blocking with 8s timeout)
  useEffect(() => {
    isMountedRef.current = true;
    let timer: any = null;

    const performSilentSignIn = async () => {
      try {
        const timeoutPromise = new Promise<{ timeout: true }>((resolve) => {
          timer = setTimeout(() => resolve({ timeout: true }), PlayGamesIds.AUTH_TIMEOUT_MS);
        });

        const authPromise = (async () => {
          const signedIn = await platformServices.isSignedIn();
          if (signedIn) {
            const p = await platformServices.getPlayer();
            return { timeout: false, signedIn: true, player: p };
          }
          return { timeout: false, signedIn: false, player: null };
        })();

        const result: any = await Promise.race([authPromise, timeoutPromise]);
        if (!isMountedRef.current) return;

        if (result.timeout) {
          // If we had a cached profile, keep offline signed in rather than forcing signed out on network timeout
          if (!cachedProfileRef.current) {
            setAuthState('SIGNED_OUT');
          }
        } else if (result.signedIn && result.player) {
          setPlayer(result.player);
          setAuthState('SIGNED_IN');
          try {
            localStorage.setItem(
              PlayGamesIds.STORAGE_AUTH_STATE_KEY,
              JSON.stringify(result.player)
            );
          } catch {
            // ignore
          }
        } else {
          setPlayer(null);
          setAuthState('SIGNED_OUT');
          try {
            localStorage.removeItem(PlayGamesIds.STORAGE_AUTH_STATE_KEY);
          } catch {
            // ignore
          }
        }
      } catch (err: unknown) {
        if (!isMountedRef.current) return;
        if (!cachedProfileRef.current) {
          setAuthState('SIGNED_OUT');
        }
        setErrorMessage(String(err));
      } finally {
        if (timer) clearTimeout(timer);
      }
    };

    performSilentSignIn();

    return () => {
      isMountedRef.current = false;
      if (timer) clearTimeout(timer);
    };
  }, []);

  const signIn = useCallback(async (): Promise<boolean> => {
    setAuthState('SIGNING_IN');
    setErrorMessage(null);
    try {
      const res = await platformServices.signIn();
      if (res.success && res.player) {
        setPlayer(res.player);
        setAuthState('SIGNED_IN');
        setIsDismissed(false);
        try {
          localStorage.removeItem(PlayGamesIds.STORAGE_DISMISS_KEY);
          localStorage.setItem(
            PlayGamesIds.STORAGE_AUTH_STATE_KEY,
            JSON.stringify(res.player)
          );
        } catch {
          // ignore
        }
        return true;
      } else {
        setAuthState('SIGNED_OUT');
        setErrorMessage(res.error || 'Sign-in cancelled or failed');
        return false;
      }
    } catch (err: unknown) {
      setAuthState('SIGNED_OUT');
      setErrorMessage(String(err));
      return false;
    }
  }, []);

  const disconnect = useCallback(async (): Promise<void> => {
    try {
      await platformServices.disconnect();
      setPlayer(null);
      setAuthState('SIGNED_OUT');
      try {
        localStorage.removeItem(PlayGamesIds.STORAGE_AUTH_STATE_KEY);
        localStorage.removeItem('pgs_web_player_profile');
      } catch {
        // ignore
      }
    } catch {
      // ignore
    }
  }, []);

  const dismissForWeek = useCallback(() => {
    setIsDismissed(true);
    try {
      localStorage.setItem(
        PlayGamesIds.STORAGE_DISMISS_KEY,
        String(Date.now() + PlayGamesIds.DISMISS_DURATION_MS)
      );
    } catch {
      // ignore
    }
  }, []);

  return {
    authState,
    status: authState,
    player,
    errorMessage,
    signIn,
    disconnect,
    isDismissed,
    dismissForWeek,
  };
}
