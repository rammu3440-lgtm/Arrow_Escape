import {
  PlatformServices,
  PlayerProfile,
  SignInResult,
  SnapshotSaveResult,
  SnapshotLoadResult,
} from './types';
import { PlayGamesIds } from './PlayGamesIds';

const WEB_STORAGE_PREFIX = 'pgs_web_snapshot_';
const WEB_PROFILE_KEY = 'pgs_web_player_profile';

export class WebPlatformServices implements PlatformServices {
  readonly isNative = false;
  private cachedPlayer: PlayerProfile | null = null;

  constructor() {
    try {
      const saved = localStorage.getItem(WEB_PROFILE_KEY);
      if (saved) {
        this.cachedPlayer = JSON.parse(saved);
      }
    } catch {
      this.cachedPlayer = null;
    }
  }

  async signIn(): Promise<SignInResult> {
    // Simulated web sign-in
    await new Promise((res) => setTimeout(res, 400));
    const mockPlayer: PlayerProfile = {
      playerId: 'web_player_local',
      displayName: 'Web Explorer',
      avatarUri: '',
    };
    this.cachedPlayer = mockPlayer;
    try {
      localStorage.setItem(WEB_PROFILE_KEY, JSON.stringify(mockPlayer));
      localStorage.setItem(PlayGamesIds.STORAGE_AUTH_STATE_KEY, JSON.stringify(mockPlayer));
    } catch {
      // storage quota or private browsing
    }
    return { success: true, player: mockPlayer };
  }

  async isSignedIn(): Promise<boolean> {
    return this.cachedPlayer !== null;
  }

  async getPlayer(): Promise<PlayerProfile | null> {
    return this.cachedPlayer;
  }

  async disconnect(): Promise<void> {
    this.cachedPlayer = null;
    try {
      localStorage.removeItem(WEB_PROFILE_KEY);
      localStorage.removeItem(PlayGamesIds.STORAGE_AUTH_STATE_KEY);
      localStorage.setItem(
        PlayGamesIds.STORAGE_DISMISS_KEY,
        String(Date.now() + PlayGamesIds.DISMISS_DURATION_MS)
      );
    } catch {
      // Ignore
    }
  }

  async saveSnapshot(name: string, json: string): Promise<SnapshotSaveResult> {
    const timestamp = Date.now();
    try {
      localStorage.setItem(`${WEB_STORAGE_PREFIX}${name}`, json);
      localStorage.setItem(`${WEB_STORAGE_PREFIX}${name}_time`, String(timestamp));
      return { success: true, timestamp };
    } catch (err: unknown) {
      return { success: false, timestamp, error: String(err) };
    }
  }

  async loadSnapshot(name: string): Promise<SnapshotLoadResult> {
    try {
      const data = localStorage.getItem(`${WEB_STORAGE_PREFIX}${name}`);
      const timeStr = localStorage.getItem(`${WEB_STORAGE_PREFIX}${name}_time`);
      const timestamp = timeStr ? Number(timeStr) : Date.now();
      if (!data) return { success: false, error: 'Snapshot not found' };
      return { success: true, data, timestamp };
    } catch (err: unknown) {
      return { success: false, error: String(err) };
    }
  }

  async submitScore(leaderboardId: string, value: number): Promise<boolean> {
    try {
      localStorage.setItem(`pgs_score_${leaderboardId}`, String(value));
      return true;
    } catch {
      return false;
    }
  }

  async unlockAchievement(achievementId: string): Promise<boolean> {
    try {
      localStorage.setItem(`pgs_ach_${achievementId}`, 'unlocked');
      return true;
    } catch {
      return false;
    }
  }

  async incrementAchievement(achievementId: string, steps: number): Promise<boolean> {
    try {
      const key = `pgs_ach_steps_${achievementId}`;
      const current = Number(localStorage.getItem(key) || '0');
      localStorage.setItem(key, String(current + steps));
      return true;
    } catch {
      return false;
    }
  }

  async showLeaderboard(): Promise<void> {
    // Web no-op / non-blocking
  }

  async showAchievements(): Promise<void> {
    // Web no-op / non-blocking
  }
}
