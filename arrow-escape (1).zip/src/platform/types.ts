export type AuthState = 'SIGNED_OUT' | 'SIGNING_IN' | 'SIGNED_IN' | 'UNAVAILABLE';

export interface PlayerProfile {
  playerId: string;
  displayName: string;
  avatarUri?: string;
  bannerUri?: string;
}

export interface SignInResult {
  success: boolean;
  player?: PlayerProfile;
  error?: string;
}

export interface SnapshotSaveResult {
  success: boolean;
  timestamp: number;
  error?: string;
}

export interface SnapshotLoadResult {
  success: boolean;
  data?: string;
  timestamp?: number;
  error?: string;
}

/**
 * Universal Platform Services facade.
 * Backed by either Android native Google Play Games v2 or browser localStorage fallback.
 */
export interface PlatformServices {
  readonly isNative: boolean;

  signIn(): Promise<SignInResult>;
  isSignedIn(): Promise<boolean>;
  getPlayer(): Promise<PlayerProfile | null>;
  disconnect(): Promise<void>;

  saveSnapshot(name: string, json: string): Promise<SnapshotSaveResult>;
  loadSnapshot(name: string): Promise<SnapshotLoadResult>;

  submitScore(leaderboardId: string, value: number): Promise<boolean>;
  unlockAchievement(achievementId: string): Promise<boolean>;
  incrementAchievement(achievementId: string, steps: number): Promise<boolean>;

  showLeaderboard(leaderboardId?: string): Promise<void>;
  showAchievements(): Promise<void>;
}
