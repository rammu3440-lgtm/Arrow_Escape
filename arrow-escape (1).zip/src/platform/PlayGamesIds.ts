/**
 * Centralized Google Play Games identifiers and configuration constants.
 */
export const PlayGamesIds = {
  // Replace with the numeric Google Play Console App ID (meta-data com.google.android.gms.games.APP_ID)
  APP_ID: '123456789012',
  PACKAGE_NAME: 'com.arrowescape.game',

  // Cloud Save Snapshot Names
  SNAPSHOT_MAIN: 'arrow_escape_main',

  // Leaderboard IDs (configured in Google Play Console)
  LEADERBOARDS: {
    TOTAL_STARS: 'CgkI_total_stars_placeholder',
    ENDLESS_STREAK: 'CgkI_endless_streak_placeholder',
    DAILY_FASTEST_TIME: 'CgkI_daily_fastest_time_placeholder',
  },

  // Achievement IDs (configured in Google Play Console)
  ACHIEVEMENTS: {
    FIRST_WIN: 'CgkI_first_win_placeholder',
    LEVELS_10: 'CgkI_levels_10_placeholder',
    STAR_MASTER_3: 'CgkI_star_master_3_placeholder',
    NO_HINTS_10: 'CgkI_no_hints_10_placeholder',
    BOSS_SLAYER: 'CgkI_boss_slayer_placeholder',
    STREAK_7_DAILY: 'CgkI_streak_7_daily_placeholder',
    ENDLESS_25: 'CgkI_endless_25_placeholder',
  },

  // Timing & Storage constants
  STORAGE_DISMISS_KEY: 'arrow_escape_pgs_dismissed_until',
  STORAGE_AUTH_STATE_KEY: 'arrow_escape_pgs_cached_user',
  DISMISS_DURATION_MS: 7 * 24 * 60 * 60 * 1000, // 7 days
  AUTH_TIMEOUT_MS: 8000, // 8 s timeout for silent login
} as const;
