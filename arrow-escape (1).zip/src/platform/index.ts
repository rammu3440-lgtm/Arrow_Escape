import { PlatformServices } from './types';
import { WebPlatformServices } from './webPlatform';

declare global {
  interface Window {
    Capacitor?: {
      isNativePlatform?: () => boolean;
      Plugins?: {
        PlayGames?: {
          signIn: () => Promise<{ success: boolean; player?: any; error?: string }>;
          isSignedIn: () => Promise<{ value: boolean }>;
          getPlayer: () => Promise<{ player: any | null }>;
          disconnect: () => Promise<void>;
          saveSnapshot: (opts: { name: string; json: string }) => Promise<{ success: boolean; timestamp: number; error?: string }>;
          loadSnapshot: (opts: { name: string }) => Promise<{ success: boolean; data?: string; timestamp?: number; error?: string }>;
          submitScore: (opts: { leaderboardId: string; value: number }) => Promise<{ success: boolean }>;
          unlockAchievement: (opts: { achievementId: string }) => Promise<{ success: boolean }>;
          incrementAchievement: (opts: { achievementId: string; steps: number }) => Promise<{ success: boolean }>;
          showLeaderboard: (opts?: { leaderboardId?: string }) => Promise<void>;
          showAchievements: () => Promise<void>;
        };
      };
    };
  }
}

/**
 * Checks if running inside native Capacitor environment with PlayGames plugin loaded.
 */
function isNativePlayGamesAvailable(): boolean {
  if (typeof window === 'undefined') return false;
  return Boolean(
    window.Capacitor?.isNativePlatform?.() &&
    window.Capacitor?.Plugins?.PlayGames
  );
}

class NativePlatformServices implements PlatformServices {
  readonly isNative = true;

  private get plugin() {
    return window.Capacitor?.Plugins?.PlayGames;
  }

  async signIn() {
    if (!this.plugin) return { success: false, error: 'PlayGames plugin not loaded' };
    return this.plugin.signIn();
  }

  async isSignedIn(): Promise<boolean> {
    if (!this.plugin) return false;
    const res = await this.plugin.isSignedIn();
    return res.value;
  }

  async getPlayer() {
    if (!this.plugin) return null;
    const res = await this.plugin.getPlayer();
    return res.player || null;
  }

  async disconnect(): Promise<void> {
    if (this.plugin) {
      await this.plugin.disconnect();
    }
  }

  async saveSnapshot(name: string, json: string) {
    if (!this.plugin) return { success: false, timestamp: Date.now(), error: 'Plugin missing' };
    return this.plugin.saveSnapshot({ name, json });
  }

  async loadSnapshot(name: string) {
    if (!this.plugin) return { success: false, error: 'Plugin missing' };
    return this.plugin.loadSnapshot({ name });
  }

  async submitScore(leaderboardId: string, value: number): Promise<boolean> {
    if (!this.plugin) return false;
    const res = await this.plugin.submitScore({ leaderboardId, value });
    return res.success;
  }

  async unlockAchievement(achievementId: string): Promise<boolean> {
    if (!this.plugin) return false;
    const res = await this.plugin.unlockAchievement({ achievementId });
    return res.success;
  }

  async incrementAchievement(achievementId: string, steps: number): Promise<boolean> {
    if (!this.plugin) return false;
    const res = await this.plugin.incrementAchievement({ achievementId, steps });
    return res.success;
  }

  async showLeaderboard(leaderboardId?: string): Promise<void> {
    if (this.plugin) {
      await this.plugin.showLeaderboard({ leaderboardId });
    }
  }

  async showAchievements(): Promise<void> {
    if (this.plugin) {
      await this.plugin.showAchievements();
    }
  }
}

export const platformServices: PlatformServices = isNativePlayGamesAvailable()
  ? new NativePlatformServices()
  : new WebPlatformServices();

export * from './types';
export * from './PlayGamesIds';
