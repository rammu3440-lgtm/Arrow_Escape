import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Board,
  Arrow,
  GameMode,
  LevelConfig,
  LevelProgress,
  GameSettings,
  BoardSnapshot,
  EconomyState,
} from './game/types';
import { cloneBoard, createSnapshot, isBlocked, isCleared, removeArrow } from './game/core';
import { generateLevel } from './game/generator';
import { findBestHint } from './game/solver';
import {
  getCampaignLevelConfig,
  getDailyLevelConfig,
  getInfiniteLevelConfig,
} from './game/levels';
import { soundManager } from './game/sound';
import {
  loadEconomy,
  saveEconomy,
  computeWinEarnings,
  getDailyRewardStatus,
  ECONOMY_CONFIG,
} from './game/economy';
import { BoardCanvas } from './components/BoardCanvas';
import { HUD, ActionBar } from './components/HUD';
import { WinModal } from './components/WinModal';
import { LoseModal } from './components/LoseModal';
import { LevelSelectModal } from './components/LevelSelectModal';
import { SettingsModal } from './components/SettingsModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { ShopModal } from './components/ShopModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { RewardedAdModal } from './components/RewardedAdModal';
import { InstallApkModal } from './components/InstallApkModal';
import { CinematicLoadingScreen } from './components/CinematicLoadingScreen';
import { LevelTransitionLoader } from './components/LevelTransitionLoader';
import { usePlayGamesAuth } from './platform/usePlayGamesAuth';
import { PlayGamesLoginButton } from './components/PlayGamesLoginButton';
import { Info } from 'lucide-react';

const STORAGE_KEY_PROGRESS = 'arrow_escape_progress_v1';
const STORAGE_KEY_SETTINGS = 'arrow_escape_settings_v1';
const STORAGE_KEY_INFINITE = 'arrow_escape_infinite_v1';
const STORAGE_KEY_DAILY = 'arrow_escape_daily_v1';

const DEFAULT_SETTINGS: GameSettings = {
  soundEnabled: true,
  hapticsEnabled: true,
  reduceMotion: false,
  darkMode: false,
  palette: 'pastel',
  skin: 'ribbon',
  ambientSoundscape: 'none',
  ambientVolume: 0.35,
};

export default function App() {
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // --- Persistent Storage State ---
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // Ignore
    }
    const prefersDark =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-color-scheme: dark)').matches;
    return { ...DEFAULT_SETTINGS, darkMode: prefersDark };
  });

  const [economy, setEconomy] = useState<EconomyState>(loadEconomy);

  const [progress, setProgress] = useState<Record<number, LevelProgress>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PROGRESS);
      if (saved) return JSON.parse(saved);
    } catch {
      // Ignore
    }
    return { 1: { unlocked: true, stars: 0 } };
  });

  const [infiniteStreak, setInfiniteStreak] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_INFINITE);
      if (saved) return Number(saved) || 0;
    } catch {
      // Ignore
    }
    return 0;
  });

  const [dailyCompletedDate, setDailyCompletedDate] = useState<string>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_DAILY) || '';
    } catch {
      return '';
    }
  });

  // --- Active Game Session State ---
  const [gameMode, setGameMode] = useState<GameMode>('CAMPAIGN');
  const [currentLevelNumber, setCurrentLevelNumber] = useState<number>(1);
  const [levelConfig, setLevelConfig] = useState<LevelConfig>(() =>
    getCampaignLevelConfig(1)
  );

  const [board, setBoard] = useState<Board>(() =>
    generateLevel(getCampaignLevelConfig(1)).board
  );
  const [totalArrowsInLevel, setTotalArrowsInLevel] = useState<number>(
    board.arrows.length
  );

  const [lives, setLives] = useState<number>(3);
  const [hintsUsedInLevel, setHintsUsedInLevel] = useState<number>(0);
  const [undoStack, setUndoStack] = useState<BoardSnapshot[]>([]);

  const [movesCount, setMovesCount] = useState<number>(0);
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [timeElapsed, setTimeElapsed] = useState<number>(0);

  // Win stats
  const [coinsEarnedInWin, setCoinsEarnedInWin] = useState<number>(0);
  const [hasDoubledWinCoins, setHasDoubledWinCoins] = useState<boolean>(false);

  // Animations & Visual highlights
  const [hintArrowId, setHintArrowId] = useState<string | null>(null);
  const [slidingArrow, setSlidingArrow] = useState<Arrow | null>(null);
  const [shakingArrowId, setShakingArrowId] = useState<string | null>(null);

  // Modals
  const [isWinOpen, setIsWinOpen] = useState(false);
  const [isLoseOpen, setIsLoseOpen] = useState(false);
  const [isLevelSelectOpen, setIsLevelSelectOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [shopInitialTab, setShopInitialTab] = useState<'BOOSTER' | 'THEME' | 'SKIN' | 'COIN_PACK'>('BOOSTER');
  const [isDailyRewardOpen, setIsDailyRewardOpen] = useState(false);
  const [isInstallApkOpen, setIsInstallApkOpen] = useState(false);
  const [isRewardedAdOpen, setIsRewardedAdOpen] = useState(false);
  const [rewardedAdConfig, setRewardedAdConfig] = useState<{
    amount?: number;
    callback: () => void;
  }>({ callback: () => {} });

  const [winStars, setWinStars] = useState(3);

  // Google Play Games Services Auth
  const playGamesAuth = usePlayGamesAuth();

  const timerRef = useRef<number | null>(null);

  // Sync dark mode class on document HTML root
  useEffect(() => {
    if (settings.darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.darkMode]);

  // Ambient Soundscape Sync
  useEffect(() => {
    soundManager.setAmbientSoundscape(
      settings.ambientSoundscape,
      settings.ambientVolume,
      settings.soundEnabled
    );
  }, [settings.ambientSoundscape, settings.ambientVolume, settings.soundEnabled]);

  // Persist settings
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch {
      // Ignore
    }
  }, [settings]);

  // Persist progress
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PROGRESS, JSON.stringify(progress));
    } catch {
      // Ignore
    }
  }, [progress]);

  // Save infinite streak
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_INFINITE, infiniteStreak.toString());
    } catch {
      // Ignore
    }
  }, [infiniteStreak]);

  // Check daily reward status on mount and auto-prompt if ready (after loading screen)
  useEffect(() => {
    if (isLoading) return;
    const dailyStatus = getDailyRewardStatus(economy);
    if (dailyStatus.status === 'CLAIMABLE') {
      const timer = setTimeout(() => {
        setIsDailyRewardOpen(true);
      }, 600);
      return () => clearTimeout(timer);
    }
  }, [isLoading, economy]);

  // Timer interval
  useEffect(() => {
    if (isWinOpen || isLoseOpen) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = window.setInterval(() => {
      setTimeElapsed(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [startTime, isWinOpen, isLoseOpen]);

  const initialBoardRef = useRef<Board>(board);

  // Load level helper
  const loadLevel = useCallback((config: LevelConfig, mode: GameMode) => {
    const { board: generatedBoard } = generateLevel(config);
    initialBoardRef.current = cloneBoard(generatedBoard);
    setLevelConfig(config);
    setBoard(generatedBoard);
    setTotalArrowsInLevel(generatedBoard.arrows.length);
    setGameMode(mode);
    setLives(3);
    setHintsUsedInLevel(0);
    setUndoStack([]);
    setMovesCount(0);
    setStartTime(Date.now());
    setTimeElapsed(0);
    setHintArrowId(null);
    setSlidingArrow(null);
    setShakingArrowId(null);
    setIsWinOpen(false);
    setIsLoseOpen(false);
  }, []);

  // Trigger Rewarded Ad
  const triggerRewardedAd = (amount: number, callback: () => void) => {
    setRewardedAdConfig({ amount, callback });
    setIsRewardedAdOpen(true);
  };

  // Switch to specific campaign level
  const handleSelectCampaignLevel = (level: number) => {
    setCurrentLevelNumber(level);
    const config = getCampaignLevelConfig(level);
    loadLevel(config, 'CAMPAIGN');
  };

  // Switch to Endless mode
  const handleSelectInfiniteMode = () => {
    const streak = infiniteStreak;
    const config = getInfiniteLevelConfig(streak + 1);
    loadLevel(config, 'INFINITE');
  };

  // Switch to Daily mode
  const handleSelectDailyMode = () => {
    const config = getDailyLevelConfig();
    loadLevel(config, 'DAILY');
  };

  // Handle arrow tap
  const handleTapArrow = (arrow: Arrow) => {
    if (isWinOpen || isLoseOpen || slidingArrow) return;

    const blocked = isBlocked(board, arrow);

    if (blocked) {
      soundManager.playBlocked(settings.soundEnabled);
      soundManager.triggerHaptic('error', settings.hapticsEnabled);
      setShakingArrowId(arrow.id);

      const nextLives = lives - 1;
      setLives(nextLives);

      if (nextLives <= 0) {
        setTimeout(() => {
          soundManager.playLose(settings.soundEnabled);
          setIsLoseOpen(true);
        }, 300);
      }
    } else {
      soundManager.playWhoosh(settings.soundEnabled);
      soundManager.triggerHaptic('light', settings.hapticsEnabled);

      setUndoStack((prev) => [
        ...prev,
        createSnapshot(board, lives, [arrow.id]),
      ]);

      if (hintArrowId === arrow.id) {
        setHintArrowId(null);
      }

      setSlidingArrow(arrow);

      const slideDuration = settings.reduceMotion ? 120 : 320;
      setTimeout(() => {
        const nextBoard = removeArrow(board, arrow.id);
        setBoard(nextBoard);
        setSlidingArrow(null);
        setMovesCount((m) => m + 1);

        if (isCleared(nextBoard)) {
          handleWin();
        }
      }, slideDuration);
    }
  };

  // Handle victory
  const handleWin = () => {
    let stars = 1;
    if (lives === 3 && hintsUsedInLevel === 0) {
      stars = 3;
    } else if (lives >= 2 && hintsUsedInLevel <= 1) {
      stars = 2;
    }

    setWinStars(stars);
    soundManager.playWin(settings.soundEnabled);
    soundManager.triggerHaptic('success', settings.hapticsEnabled);

    const prevLevelData = progress[currentLevelNumber];
    const isReplay = !!prevLevelData?.stars;
    const isFirstTime3Stars = stars === 3 && (prevLevelData?.stars || 0) < 3;

    // Calculate coin earnings
    const earnings = computeWinEarnings(
      stars,
      levelConfig.isBoss || false,
      isFirstTime3Stars,
      isReplay
    );
    setCoinsEarnedInWin(earnings.total);
    setHasDoubledWinCoins(false);

    // Grant coins to wallet
    const updatedEconomy: EconomyState = {
      ...economy,
      coins: economy.coins + earnings.total,
    };
    setEconomy(updatedEconomy);
    saveEconomy(updatedEconomy);

    if (gameMode === 'CAMPAIGN') {
      const currentStars = prevLevelData?.stars || 0;
      const nextLvl = currentLevelNumber + 1;
      setProgress((prev) => ({
        ...prev,
        [currentLevelNumber]: {
          unlocked: true,
          stars: Math.max(currentStars, stars),
          bestTimeSec: Math.min(
            prev[currentLevelNumber]?.bestTimeSec || 9999,
            timeElapsed
          ),
          completedAt: Date.now(),
        },
        [nextLvl]: {
          unlocked: true,
          stars: prev[nextLvl]?.stars || 0,
        },
      }));
    } else if (gameMode === 'INFINITE') {
      setInfiniteStreak((prev) => prev + 1);
    } else if (gameMode === 'DAILY') {
      const today = new Date().toISOString().slice(0, 10);
      setDailyCompletedDate(today);
      try {
        localStorage.setItem(STORAGE_KEY_DAILY, today);
      } catch {
        // Ignore
      }
    }

    setIsWinOpen(true);
  };

  // Double win coins with ad
  const handleDoubleCoinsWithAd = () => {
    triggerRewardedAd(coinsEarnedInWin, () => {
      const updated: EconomyState = {
        ...economy,
        coins: economy.coins + coinsEarnedInWin,
      };
      setEconomy(updated);
      saveEconomy(updated);
      setHasDoubledWinCoins(true);
      soundManager.playWin(settings.soundEnabled);
    });
  };

  // Undo last move
  const handleUndo = () => {
    if (undoStack.length === 0 || slidingArrow) return;

    if (economy.undos <= 0) {
      setShopInitialTab('BOOSTER');
      setIsShopOpen(true);
      return;
    }

    const lastSnapshot = undoStack[undoStack.length - 1];
    setBoard(lastSnapshot.board);
    // Explicitly preserve current lives count and existing star progression rules
    setUndoStack((prev) => prev.slice(0, -1));

    const updatedEco: EconomyState = {
      ...economy,
      undos: Math.max(0, economy.undos - 1),
    };
    setEconomy(updatedEco);
    saveEconomy(updatedEco);

    setHintArrowId(null);
    soundManager.playUndo(settings.soundEnabled);
    soundManager.triggerHaptic('light', settings.hapticsEnabled);
  };

  // Show smart hint
  const handleHint = () => {
    if (slidingArrow) return;

    if (economy.hints <= 0) {
      setShopInitialTab('BOOSTER');
      setIsShopOpen(true);
      return;
    }

    const bestArrow = findBestHint(board);
    if (bestArrow) {
      setHintArrowId(bestArrow.id);
      setHintsUsedInLevel((u) => u + 1);

      const updatedEco: EconomyState = {
        ...economy,
        hints: Math.max(0, economy.hints - 1),
      };
      setEconomy(updatedEco);
      saveEconomy(updatedEco);

      soundManager.playHint(settings.soundEnabled);
      soundManager.triggerHaptic('light', settings.hapticsEnabled);
    }
  };

  // Restart current level
  const handleRestart = useCallback(() => {
    setBoard(cloneBoard(initialBoardRef.current));
    setTotalArrowsInLevel(initialBoardRef.current.arrows.length);
    setLives(3);
    setHintsUsedInLevel(0);
    setUndoStack([]);
    setMovesCount(0);
    setStartTime(Date.now());
    setTimeElapsed(0);
    setHintArrowId(null);
    setSlidingArrow(null);
    setShakingArrowId(null);
    setIsWinOpen(false);
    setIsLoseOpen(false);
    soundManager.playTap(settings.soundEnabled);
  }, [settings.soundEnabled]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      )
        return;

      if (e.key === 'u' || e.key === 'U' || (e.key === 'z' && (e.ctrlKey || e.metaKey))) {
        e.preventDefault();
        handleUndo();
      } else if (e.key === 'h' || e.key === 'H') {
        e.preventDefault();
        handleHint();
      } else if (e.key === 'r' || e.key === 'R') {
        e.preventDefault();
        handleRestart();
      } else if (e.key === 'Escape') {
        setIsLevelSelectOpen(false);
        setIsSettingsOpen(false);
        setIsHelpOpen(false);
        setIsShopOpen(false);
        setIsDailyRewardOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleUndo, handleHint, handleRestart]);

  // Advance to next level
  const handleNextLevel = () => {
    if (gameMode === 'CAMPAIGN') {
      const nextLvl = currentLevelNumber + 1;
      handleSelectCampaignLevel(nextLvl);
    } else if (gameMode === 'INFINITE') {
      handleSelectInfiniteMode();
    } else {
      handleSelectCampaignLevel(1);
    }
  };

  // Revive with Coins
  const handleReviveCoins = () => {
    if (economy.coins < ECONOMY_CONFIG.SPEND_REVIVE_PRICE) return;
    const updated: EconomyState = {
      ...economy,
      coins: economy.coins - ECONOMY_CONFIG.SPEND_REVIVE_PRICE,
    };
    setEconomy(updated);
    saveEconomy(updated);
    setLives(2);
    setIsLoseOpen(false);
    soundManager.playTap(settings.soundEnabled);
    soundManager.triggerHaptic('success', settings.hapticsEnabled);
  };

  // Revive with Ad
  const handleReviveAd = () => {
    triggerRewardedAd(0, () => {
      setLives(2);
      setIsLoseOpen(false);
      soundManager.playTap(settings.soundEnabled);
      soundManager.triggerHaptic('success', settings.hapticsEnabled);
    });
  };

  // Reset entire game progress
  const handleResetProgress = () => {
    const freshProgress = { 1: { unlocked: true, stars: 0 } };
    setProgress(freshProgress);
    setInfiniteStreak(0);
    setDailyCompletedDate('');
    try {
      localStorage.setItem(STORAGE_KEY_PROGRESS, JSON.stringify(freshProgress));
      localStorage.setItem(STORAGE_KEY_INFINITE, '0');
      localStorage.removeItem(STORAGE_KEY_DAILY);
    } catch {
      // Ignore
    }
    handleSelectCampaignLevel(1);
  };

  const todayStr = new Date().toISOString().slice(0, 10);
  const isDailyCompletedToday = dailyCompletedDate === todayStr;
  const hasUnclaimedDailyReward = getDailyRewardStatus(economy).status === 'CLAIMABLE';

  return (
    <div className="w-full h-screen flex flex-col justify-between bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden font-sans">
      {/* Cinematic Loading Screen on Initial Boot & App Reopen */}
      {isLoading && (
        <CinematicLoadingScreen
          palette={economy.equippedTheme}
          skin={economy.equippedSkin}
          darkMode={settings.darkMode}
          reduceMotion={settings.reduceMotion}
          soundEnabled={settings.soundEnabled}
          hapticsEnabled={settings.hapticsEnabled}
          authState={playGamesAuth.authState}
          player={playGamesAuth.player}
          onSignIn={playGamesAuth.signIn}
          onComplete={() => setIsLoading(false)}
        />
      )}

      {/* Top HUD */}
      <HUD
        levelConfig={levelConfig}
        gameMode={gameMode}
        lives={lives}
        maxLives={3}
        remainingArrows={board.arrows.length}
        totalArrows={totalArrowsInLevel}
        hintsRemaining={economy.hints}
        undoRemaining={economy.undos}
        canUndo={undoStack.length > 0}
        coins={economy.coins}
        hasUnclaimedDailyReward={hasUnclaimedDailyReward}
        playGamesAuth={playGamesAuth}
        onUndo={handleUndo}
        onHint={handleHint}
        onRestart={handleRestart}
        onOpenLevelSelect={() => setIsLevelSelectOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenHelp={() => setIsHelpOpen(true)}
        onOpenShop={() => {
          setShopInitialTab('BOOSTER');
          setIsShopOpen(true);
        }}
        onOpenDailyRewards={() => setIsDailyRewardOpen(true)}
        onOpenInstallApk={() => setIsInstallApkOpen(true)}
      />

      {/* Main Board Container */}
      <main className="flex-1 w-full max-w-xl mx-auto flex flex-col items-center justify-center relative overflow-hidden px-2">
        {/* Play Games Save Progress Chip for Signed-Out Users */}
        {playGamesAuth.status === 'SIGNED_OUT' && (
          <div className="absolute top-2 z-20 animate-in fade-in slide-in-from-top-1 duration-200">
            <PlayGamesLoginButton
              authState={playGamesAuth.authState}
              player={playGamesAuth.player}
              onSignIn={playGamesAuth.signIn}
              variant="chip"
              className="shadow-sm"
            />
          </div>
        )}

        {/* Level 1 Tutorial Gentle Tip */}
        {levelConfig.tutorialTip && board.arrows.length === totalArrowsInLevel && (
          <div className={`absolute ${playGamesAuth.status === 'SIGNED_OUT' ? 'top-10' : 'top-2'} z-10 px-4 py-2 rounded-2xl bg-slate-900/90 text-white dark:bg-slate-100/95 dark:text-slate-900 text-xs font-medium shadow-lg backdrop-blur-xs flex items-center gap-2 max-w-xs text-center animate-in fade-in slide-in-from-top-2 duration-300`}>
            <Info className="w-4 h-4 shrink-0 text-amber-400" />
            <span>{levelConfig.tutorialTip}</span>
          </div>
        )}

        {/* Board Canvas with Equipped Theme and Skin */}
        <BoardCanvas
          board={board}
          hintArrowId={hintArrowId}
          onTapArrow={handleTapArrow}
          palette={economy.equippedTheme}
          skin={economy.equippedSkin}
          darkMode={settings.darkMode}
          reduceMotion={settings.reduceMotion}
          slidingArrow={slidingArrow}
          shakingArrowId={shakingArrowId}
        />
      </main>

      {/* Bottom Action Bar */}
      <ActionBar
        onUndo={handleUndo}
        onHint={handleHint}
        onRestart={handleRestart}
        onOpenShopForBoosters={() => {
          setShopInitialTab('BOOSTER');
          setIsShopOpen(true);
        }}
        undoRemaining={economy.undos}
        hintsRemaining={economy.hints}
        canUndo={undoStack.length > 0}
      />

      {/* Modals */}
      <WinModal
        isOpen={isWinOpen}
        stars={winStars}
        timeSeconds={timeElapsed}
        moveCount={movesCount}
        coinsEarned={coinsEarnedInWin}
        hasDoubledCoins={hasDoubledWinCoins}
        onDoubleCoinsWithAd={handleDoubleCoinsWithAd}
        isBoss={levelConfig.isBoss}
        isDaily={gameMode === 'DAILY'}
        levelTitle={levelConfig.title}
        hasNextLevel={true}
        onNextLevel={handleNextLevel}
        onReplay={handleRestart}
        onLevelSelect={() => {
          setIsWinOpen(false);
          setIsLevelSelectOpen(true);
        }}
      />

      <LoseModal
        isOpen={isLoseOpen}
        coins={economy.coins}
        onRestart={handleRestart}
        onReviveCoins={handleReviveCoins}
        onReviveAd={handleReviveAd}
        onLevelSelect={() => {
          setIsLoseOpen(false);
          setIsLevelSelectOpen(true);
        }}
      />

      <LevelSelectModal
        isOpen={isLevelSelectOpen}
        onClose={() => setIsLevelSelectOpen(false)}
        currentLevel={currentLevelNumber}
        gameMode={gameMode}
        progress={progress}
        infiniteStreak={infiniteStreak}
        dailyCompletedToday={isDailyCompletedToday}
        dailyStreak={economy.loginStreak}
        onSelectCampaignLevel={handleSelectCampaignLevel}
        onSelectInfiniteMode={handleSelectInfiniteMode}
        onSelectDailyMode={handleSelectDailyMode}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => {
          setSettings((prev) => ({ ...prev, ...newSettings }));
        }}
        onResetProgress={handleResetProgress}
        onReplayIntro={() => setIsLoading(true)}
        onOpenShop={(tab) => {
          setShopInitialTab(tab || 'THEME');
          setIsShopOpen(true);
        }}
        onOpenInstallApk={() => setIsInstallApkOpen(true)}
        playGamesAuth={playGamesAuth}
      />

      <InstallApkModal
        isOpen={isInstallApkOpen}
        onClose={() => setIsInstallApkOpen(false)}
      />

      <HowToPlayModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
      />

      <ShopModal
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        economy={economy}
        onUpdateEconomy={(updated) => setEconomy(updated)}
        onTriggerRewardedAd={triggerRewardedAd}
        soundEnabled={settings.soundEnabled}
        initialTab={shopInitialTab}
      />

      <DailyRewardModal
        isOpen={isDailyRewardOpen}
        onClose={() => setIsDailyRewardOpen(false)}
        economy={economy}
        onUpdateEconomy={(updated) => setEconomy(updated)}
        onTriggerRewardedAd={triggerRewardedAd}
        soundEnabled={settings.soundEnabled}
      />

      <RewardedAdModal
        isOpen={isRewardedAdOpen}
        rewardAmount={rewardedAdConfig.amount}
        onReward={rewardedAdConfig.callback}
        onClose={() => setIsRewardedAdOpen(false)}
      />
    </div>
  );
}
