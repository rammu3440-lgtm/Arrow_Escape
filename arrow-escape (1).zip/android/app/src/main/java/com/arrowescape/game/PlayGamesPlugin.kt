package com.arrowescape.game

import android.content.Intent
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.google.android.gms.games.PlayGames
import com.google.android.gms.games.PlayGamesSdk
import com.google.android.gms.games.SnapshotsClient
import com.google.android.gms.games.snapshot.SnapshotMetadataChange

@CapacitorPlugin(name = "PlayGames")
class PlayGamesPlugin : Plugin() {

    override fun load() {
        super.load()
        // Initialize Google Play Games Services v2 SDK
        PlayGamesSdk.initialize(context)
    }

    @PluginMethod
    fun signIn(call: PluginCall) {
        val gamesSignInClient = PlayGames.getGamesSignInClient(activity)
        gamesSignInClient.signIn().addOnCompleteListener { task ->
            if (task.isSuccessful && task.result.isAuthenticated) {
                val playersClient = PlayGames.getPlayersClient(activity)
                playersClient.currentPlayer.addOnSuccessListener { player ->
                    val ret = JSObject().apply {
                        put("success", true)
                        put("player", JSObject().apply {
                            put("playerId", player.playerId)
                            put("displayName", player.displayName)
                            put("avatarUri", player.iconImageUri?.toString() ?: "")
                            put("bannerUri", player.bannerImageLandscapeUri?.toString() ?: "")
                        })
                    }
                    call.resolve(ret)
                }.addOnFailureListener { e ->
                    val ret = JSObject().apply {
                        put("success", true)
                        put("player", JSObject().apply {
                            put("playerId", "anonymous_player")
                            put("displayName", "Play Games Player")
                        })
                    }
                    call.resolve(ret)
                }
            } else {
                val ret = JSObject().apply {
                    put("success", false)
                    put("error", task.exception?.message ?: "Sign-in cancelled or unauthenticated")
                }
                call.resolve(ret)
            }
        }
    }

    @PluginMethod
    fun isSignedIn(call: PluginCall) {
        val gamesSignInClient = PlayGames.getGamesSignInClient(activity)
        gamesSignInClient.isAuthenticated.addOnCompleteListener { task ->
            val ret = JSObject().apply {
                put("value", task.isSuccessful && task.result.isAuthenticated)
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun getPlayer(call: PluginCall) {
        val playersClient = PlayGames.getPlayersClient(activity)
        playersClient.currentPlayer.addOnSuccessListener { player ->
            val ret = JSObject().apply {
                put("player", JSObject().apply {
                    put("playerId", player.playerId)
                    put("displayName", player.displayName)
                    put("avatarUri", player.iconImageUri?.toString() ?: "")
                })
            }
            call.resolve(ret)
        }.addOnFailureListener {
            val ret = JSObject().apply {
                put("player", null)
            }
            call.resolve(ret)
        }
    }

    @PluginMethod
    fun disconnect(call: PluginCall) {
        // PGS v2 does not have an explicit sign-out method; app-level state is cleared
        call.resolve()
    }

    @PluginMethod
    fun showLeaderboard(call: PluginCall) {
        val leaderboardId = call.getString("leaderboardId")
        val leaderboardsClient = PlayGames.getLeaderboardsClient(activity)
        val task = if (leaderboardId.isNullOrEmpty()) {
            leaderboardsClient.allLeaderboardsIntent
        } else {
            leaderboardsClient.getLeaderboardIntent(leaderboardId)
        }
        task.addOnSuccessListener { intent ->
            activity.startActivityForResult(intent, RC_LEADERBOARD_UI)
            call.resolve()
        }.addOnFailureListener { e ->
            call.reject("Could not display leaderboard", e)
        }
    }

    @PluginMethod
    fun showAchievements(call: PluginCall) {
        val achievementsClient = PlayGames.getAchievementsClient(activity)
        achievementsClient.achievementsIntent.addOnSuccessListener { intent ->
            activity.startActivityForResult(intent, RC_ACHIEVEMENTS_UI)
            call.resolve()
        }.addOnFailureListener { e ->
            call.reject("Could not display achievements", e)
        }
    }

    companion object {
        private const val RC_LEADERBOARD_UI = 9002
        private const val RC_ACHIEVEMENTS_UI = 9003
    }
}
